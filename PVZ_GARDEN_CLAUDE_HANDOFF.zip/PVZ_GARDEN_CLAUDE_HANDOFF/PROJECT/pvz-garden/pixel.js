// pixel.js — shared pixel-art engine for the Sprig Hollow prototypes.
// Sprites are built from shapes on a small grid, auto-outlined in ink, and cached as tiny canvases.
// Style matches the "My Inventory" app: DawnBringer-32 colours, 1px #222034 outline, 3-tone shading.
(function () {
  'use strict';
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, k) => a + (b - a) * k;
  const INK = '#29243d'; // the outline colour: a soft warm dark brown (chibi sticker style), not black

  const PAL = {
    k: INK, w: '#ffffff', W: '#cbdbfc', l: '#9badb7', D: '#847e87', g: '#696a6a', G: '#595652', x: '#323c39',
    d: '#45283c', n: '#663931', b: '#8f563b', o: '#df7126', t: '#d9a066', s: '#eec39a', y: '#fbf236', L: '#99e550',
    e: '#6abe30', E: '#37946e', f: '#4b692f', v: '#524b24', h: '#8f974a', H: '#8a6f30', i: '#3f3f74', c: '#306082',
    B: '#5b6ee1', u: '#639bff', a: '#5fcde4', p: '#76428a', r: '#ac3232', R: '#d95763', m: '#d77bba',
  };
  // [light, mid, dark]
  const RAMPS = {
    leaf: ['#99e550', '#6abe30', '#37946e'],
    mint: ['#a6f2d3', '#52c7a8', '#2f8078'],
    sky: ['#9fd8ff', '#639bff', '#3f55b8'],
    peach: ['#f6d2ad', '#e0a672', '#a8653a'],
    rose: ['#f7b6c8', '#e07ba0', '#a2477a'],
    sun: ['#fff27a', '#f6c83a', '#c7861c'],
    berry: ['#f07a84', '#d24552', '#8a2433'],
    plum: ['#c9a2f0', '#9a6ad0', '#5e3a8e'],
    cloud: ['#ffffff', '#dfe8fb', '#9badb7'],
    slate: ['#b7c2cc', '#8c93a8', '#595a70'],
    night: ['#7d8cf0', '#4a4aa0', '#2c2c66'],
    clay: ['#f5a86a', '#df7126', '#96461c'],
    moss: ['#c3d66a', '#8f974a', '#4b692f'],
    cocoa: ['#c48a5c', '#8f563b', '#5a3322'],
    lilac: ['#f0e2ff', '#c8aaf0', '#8c6cc4'],
    teal: ['#7ee4d4', '#2aa8a0', '#1a6670'],
    coral: ['#ffc4ac', '#f7806a', '#c04a4c'],
    lemon: ['#fffcd0', '#f6ee6a', '#bcb030'],
    lime: ['#e2ff96', '#aee034', '#62961c'],
    ocean: ['#6ea4ec', '#2e5cb4', '#1c3272'],
    cherry: ['#ff8080', '#e42a2e', '#901630'],
    cream: ['#fffdf2', '#f6e8c6', '#ccb28a'],
    charcoal: ['#80808e', '#4e4e5c', '#33333f'],
    tangerine: ['#ffd488', '#ff9a22', '#c45c0c'],
    bubblegum: ['#ffd4f2', '#ff86d2', '#c4489a'],
    aqua: ['#ccfcff', '#5ee2f2', '#2896b8'],
    // newer colours, each picked to stay clearly apart from the ones above (checked side by side)
    sand: ['#f8ecc4', '#dcc690', '#a08a58'],
    forest: ['#86c46a', '#3e8948', '#21523a'],
    periwinkle: ['#d8dcff', '#9ca6f6', '#5e66c4'],
    orchid: ['#f6b4e8', '#d44cb4', '#8a2478'],
    blush: ['#fff0ec', '#f8c6c0', '#d08c96'],
    raspberry: ['#e87aa8', '#b0386e', '#6a1e48'],
  };
  const BELLY = '#fbf3dc';

  // ---------------- Grid raster ----------------
  function inEll(px, py, cx, cy, rx, ry, rot) {
    let dx = px - cx, dy = py - cy;
    if (rot) { const c = Math.cos(-rot), s = Math.sin(-rot); const x = dx * c - dy * s, y = dx * s + dy * c; dx = x; dy = y; }
    return { in: (dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) <= 1, nx: dx / rx, ny: dy / ry };
  }
  function shadeOf(ramp, nx, ny) { const d = nx * 0.55 + ny * 0.85; return d < -0.42 ? ramp[0] : d > 0.55 ? ramp[2] : ramp[1]; }
  // Same 3-tone shading, but with a 1px checker dither where two tones meet (only on shapes big enough to carry it).
  function shadeDith(ramp, nx, ny, x, y, w) {
    const d = nx * 0.55 + ny * 0.85, odd = (x + y) & 1;
    if (Math.abs(d + 0.42) < w) return odd ? ramp[0] : ramp[1];
    if (Math.abs(d - 0.55) < w) return odd ? ramp[1] : ramp[2];
    return d < -0.42 ? ramp[0] : d > 0.55 ? ramp[2] : ramp[1];
  }
  const specCache = new Map();
  const specOf = c => { let s = specCache.get(c); if (!s) { s = mixHex(c, '#ffffff', 0.6); specCache.set(c, s); } return s; };
  // Grid: w x h "art pixels". k > 1 makes a hi-res grid: each art pixel is k x k fine pixels, so the same drawing code
  // gives smoother curves (ell / poly / stroke are rasterised at fine resolution) and a thinner 1-fine-pixel outline, while
  // set / px / rect / str / get keep working in art pixels (a set colours the whole k x k block, but leaves the ink outline
  // inside a block alone). Fine detail: dot(x, y, col) at fractional art coordinates, or fset / fget in fine pixels.
  // New grids take k from Grid.K (1 by default; the plant/zombie builders raise it while they draw).
  class Grid {
    // dither: soften tone steps on big ramp ellipses. spec: add a small glossy highlight to big ramp ellipses (opt-in).
    constructor(w, h, k) {
      this.w = w; this.h = h; this.k = k || Grid.K || 1; this.fw = w * this.k; this.fh = h * this.k;
      this.a = new Array(this.fw * this.fh).fill(null); this.dither = this.k === 1; this.spec = false; // (hi-res art is flat and clean: no dither)
    }
    get(x, y) {
      const k = this.k;
      if (k === 1) return x < 0 || y < 0 || x >= this.w || y >= this.h ? null : this.a[y * this.w + x];
      const fx = Math.floor(x * k), fy = Math.floor(y * k);
      return fx < 0 || fy < 0 || fx >= this.fw || fy >= this.fh ? null : this.a[fy * this.fw + fx];
    }
    set(x, y, c) {
      x |= 0; y |= 0; if (x < 0 || y < 0 || x >= this.w || y >= this.h) return;
      const k = this.k; if (k === 1) { this.a[y * this.w + x] = c; return; }
      const fw = this.fw, i0 = y * k * fw + x * k;
      let keep = false; // colouring a block that holds part of a shape: paint the shape's fine pixels, keep its outline
      if (c !== null && c !== INK) for (let j = 0; j < k && !keep; j++) for (let i = 0; i < k; i++) { const v = this.a[i0 + j * fw + i]; if (v !== null && v !== INK) { keep = true; break; } }
      for (let j = 0; j < k; j++) for (let i = 0; i < k; i++) { const n = i0 + j * fw + i; if (!keep || (this.a[n] !== null && this.a[n] !== INK)) this.a[n] = c; }
    }
    // fine-pixel access (fine coordinates)
    fget(fx, fy) { return fx < 0 || fy < 0 || fx >= this.fw || fy >= this.fh ? null : this.a[fy * this.fw + fx]; }
    fset(fx, fy, c) { fx |= 0; fy |= 0; if (fx < 0 || fy < 0 || fx >= this.fw || fy >= this.fh) return; this.a[fy * this.fw + fx] = c; }
    // one fine pixel at art coordinates (x, y may be fractional: on a k=2 grid, (10.5, 7) is the right half of art pixel 10)
    dot(x, y, c) { this.fset(Math.floor(x * this.k), Math.floor(y * this.k), c); return this; }
    dots(list, c) { for (const [x, y] of list) this.dot(x, y, c); return this; }
    ffilled(fx, fy) { const c = this.fget(fx, fy); return c !== null && c !== INK; }
    ell(cx, cy, rx, ry, col, rot, mask) {
      const r = Math.max(rx, ry) + 1, ramp = Array.isArray(col), mn = Math.min(rx, ry), k = this.k;
      const dw = ramp && this.dither && mn >= 3.2 ? Math.min(0.1, 0.55 / mn) / (k > 1 ? 1.4 : 1) : 0;
      const sp = ramp && this.spec && mn >= 2.6 && col[0][0] === '#' && col !== SKIN_SENT ? specOf(col[0]) : null, sr = sp ? Math.max(0.12, 0.75 / mn) : 0;
      for (let fy = Math.floor((cy - r) * k); fy <= Math.ceil((cy + r) * k); fy++) for (let fx = Math.floor((cx - r) * k); fx <= Math.ceil((cx + r) * k); fx++) {
        const q = inEll((fx + 0.5) / k, (fy + 0.5) / k, cx, cy, rx, ry, rot);
        if (!q.in) continue;
        if (mask && !(mask.fine ? mask(fx / k, fy / k) : mask(Math.floor(fx / k), Math.floor(fy / k)))) continue;
        if (!ramp) { this.fset(fx, fy, col); continue; }
        if (sp && Math.hypot(q.nx + 0.42, q.ny + 0.5) < sr) { this.fset(fx, fy, sp); continue; }
        this.fset(fx, fy, dw ? shadeDith(col, q.nx, q.ny, fx, fy, dw) : shadeOf(col, q.nx, q.ny));
      }
      return this;
    }
    rect(x, y, w, h, col) { for (let j = y; j < y + h; j++) for (let i = x; i < x + w; i++) this.set(i, j, col); return this; }
    poly(pts, col) {
      const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]), k = this.k;
      for (let fy = Math.floor(Math.min(...ys) * k); fy <= Math.ceil(Math.max(...ys) * k); fy++) for (let fx = Math.floor(Math.min(...xs) * k); fx <= Math.ceil(Math.max(...xs) * k); fx++) {
        const px = (fx + 0.5) / k, py = (fy + 0.5) / k; let inside = false;
        for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
          const [xi, yi] = pts[i], [xj, yj] = pts[j];
          if ((yi > py) !== (yj > py) && px < ((xj - xi) * (py - yi)) / (yj - yi) + xi) inside = !inside;
        }
        if (inside) this.fset(fx, fy, col);
      }
      return this;
    }
    px(list, col) { for (const [x, y] of list) this.set(x, y, col); return this; }
    str(rows, x0, y0, map) { rows.forEach((row, y) => { for (let x = 0; x < row.length; x++) { const ch = row[x]; if (ch === '.') continue; this.set(x0 + x, y0 + y, (map && map[ch]) || PAL[ch] || ch); } }); return this; }
    outline(col) {
      col = col || INK; const add = [], W = this.fw, H = this.fh, a = this.a;
      // hi-res: a pixel only counts if it isn't ink already, so an outline drawn earlier (PX.piece) isn't doubled up
      const on = this.k > 1 ? i => { const v = a[i]; return !!v && v !== INK; } : i => !!a[i];
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        if (a[y * W + x] !== null) continue;
        if ((x > 0 && on(y * W + x - 1)) || (x < W - 1 && on(y * W + x + 1)) || (y > 0 && on((y - 1) * W + x)) || (y < H - 1 && on((y + 1) * W + x))) add.push(y * W + x);
      }
      for (const i of add) a[i] = col;
      return this;
    }
    // a bold sticker edge: one more ring of ink round the whole silhouette (inner lines stay thin)
    outerLine(col) { // (see-through pixels, any 'rgba(...)' colour such as a soft glow, don't get the edge)
      col = col || INK; const add = [], W = this.fw, H = this.fh, a = this.a;
      const on = i => { const v = a[i]; return !!v && v[0] !== 'r'; };
      for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
        const v = a[y * W + x]; if (v !== null && v[0] !== 'r') continue;
        if ((x > 0 && on(y * W + x - 1)) || (x < W - 1 && on(y * W + x + 1)) || (y > 0 && on((y - 1) * W + x)) || (y < H - 1 && on((y + 1) * W + x))) add.push(y * W + x);
      }
      for (const i of add) a[i] = col;
      return this;
    }
    merge(o) { for (let i = 0; i < this.a.length; i++) if (o.a[i] !== null) this.a[i] = o.a[i]; return this; }
    filled(x, y) { const c = this.get(x, y); return c !== null && c !== INK; }
    canvas() {
      const c = document.createElement('canvas'); c.width = this.fw; c.height = this.fh;
      const x = c.getContext('2d');
      for (let y = 0; y < this.fh; y++) for (let i = 0; i < this.fw; i++) { const col = this.a[y * this.fw + i]; if (col) { x.fillStyle = col; x.fillRect(i, y, 1, 1); } }
      if (this.k > 1) c.k = this.k; // screens draw it at (width / k) x (height / k) art pixels: see blit / PX.artW
      return c;
    }
  }
  // The whole game is drawn at 2 fine pixels per art pixel (smoother shapes, thin outlines, room for detail). The old Solunar
  // sprite builder below still works on 1x grids (it indexes raw pixels) and switches itself back to 1x while it runs.
  Grid.K = 2;
  function fromStrings(rows, map) { const g = new Grid(rows[0].length, rows.length); g.str(rows, 0, 0, map); return g; }

  // ---------------- Shape helpers ----------------
  // thick line through points; radius eases r0 -> r1 along the path
  function stroke(g, pts, r0, r1, col) {
    let len = 0; const seg = [];
    for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push(d); len += d; }
    let acc = 0;
    for (let i = 1; i < pts.length; i++) {
      const [x0, y0] = pts[i - 1], [x1, y1] = pts[i], d = seg[i - 1], n = Math.max(1, Math.ceil(d / 0.3));
      for (let s = 0; s <= n; s++) { const t = s / n, r = r0 + (r1 - r0) * ((acc + d * t) / (len || 1)); g.ell(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t, r, r, col); }
      acc += d;
    }
    return g;
  }
  // 1px line (Bresenham), no outline intended
  function line(g, x0, y0, x1, y1, col) {
    x0 |= 0; y0 |= 0; x1 |= 0; y1 |= 0;
    const dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1; let e = dx + dy;
    for (;;) { g.set(x0, y0, col); if (x0 === x1 && y0 === y1) break; const e2 = 2 * e; if (e2 >= dy) { e += dy; x0 += sx; } if (e2 <= dx) { e += dx; y0 += sy; } }
    return g;
  }
  function starPts(cx, cy, ro, ri, n, rot) { const p = []; for (let i = 0; i < n * 2; i++) { const r = i % 2 ? ri : ro, a = (rot || -Math.PI / 2) + i * Math.PI / n; p.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); } return p; }
  const mirX = (pts, W) => pts.map(([x, y]) => [W - x, y]);
  // draw a shape on its own, ink-outline it, then lay it over G (gives separation lines between overlapping pieces)
  function piece(G, draw) { const t = new Grid(G.w, G.h, G.k); draw(t); t.outline(); G.merge(t); return G; }
  const inside = g => { const f = (x, y) => g.filled(x, y); f.fine = true; return f; }; // (checked at fine-pixel precision on hi-res grids)
  // recolour every filled (non-ink) pixel inside an ellipse with ramp shading — gives 3-tone to poly shapes
  function shade(g, cx, cy, rx, ry, ramp, rot) { return g.ell(cx, cy, rx, ry, ramp, rot || 0, inside(g)); }
  // copy b under a (only where a is empty); returns set of indices that came from b
  function under(a, b) { const s = new Set(); for (let i = 0; i < a.a.length; i++) if (a.a[i] === null && b.a[i] !== null) { a.a[i] = b.a[i]; s.add(i); } return s; }
  const RAMP_X = {
    cream: ['#fffbf0', '#f4e6c8', '#c8b08a'],
    crab: ['#ff9a7a', '#e8543a', '#a02c2a'],
    gold: ['#fffbd0', '#f6c83a', '#b87818'],
    glowY: ['#fffbd0', '#fbf236', '#c8b020'],
    bark: ['#c48a5c', '#8f563b', '#5a3322'],
  };
  // gumball colours (red, orange, yellow, green, aqua, blue, purple, pink) as [light, mid, dark]
  const GUM = [
    ['#ffb0b0', '#ec3a48', '#9a1c30'], ['#ffd098', '#ff8e1e', '#bc5410'], ['#fffab0', '#fcd82c', '#c49c14'], ['#c8f494', '#5cc83a', '#2c8434'],
    ['#b4f6ff', '#34cce2', '#1a84a4'], ['#b4ccff', '#4a78f0', '#2a44ac'], ['#e4c4ff', '#a45ee2', '#6a34a6'], ['#ffd0f0', '#ff6cc0', '#bc3888'],
  ];

  // ---------------- Flowers (shared by bloom crowns and flower icons; art fits within ±5 of centre) ----------------
  const FLO = {
    sunflower(g, x, y) {
      for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5; g.ell(x + Math.cos(a) * 3, y + Math.sin(a) * 3, 2, 1.25, RAMPS.sun, a); }
      g.ell(x, y, 2.3, 2.3, RAMP_X.bark);
    },
    sunflowerD(g, x, y) { g.px([[x - 1, y - 1], [x + 1, y], [x - 1, y + 1], [x, y - 2 + 1]].filter(([a, b]) => g.filled(a, b)), '#c48a5c'); g.set(x - 1, y - 2, '#fff27a'); },
    bluebell(g, x, y) {
      const S = '#37946e', BR = ['#c0ccff', '#6b82e8', '#3f45a8'];
      g.ell(x - 1.8, y + 3.8, 1.8, 0.8, RAMPS.leaf, 0.5); g.ell(x + 1.8, y + 3.8, 1.8, 0.8, RAMPS.leaf, -0.5);
      stroke(g, [[x, y + 5], [x, y - 1]], 0.6, 0.6, S);
      stroke(g, [[x, y], [x - 2.6, y - 1.4]], 0.5, 0.5, S); stroke(g, [[x, y], [x + 2.6, y - 1.4]], 0.5, 0.5, S);
      const bell = (bx, by) => { g.ell(bx, by, 1.8, 1.9, BR); g.poly([[bx - 1.8, by + 0.4], [bx + 1.8, by + 0.4], [bx + 2.2, by + 2.3], [bx - 2.2, by + 2.3]], BR[1]); };
      bell(x - 2.8, y + 0.2); bell(x + 2.8, y + 0.2); bell(x, y - 3.2);
    },
    bluebellD(g, x, y) {
      for (const [bx, by] of [[x - 3, y + 2], [x + 2, y + 2], [x - 1, y - 1]]) { g.px([[bx, by], [bx + 1, by]].filter(([a, b]) => g.filled(a, b)), '#3f45a8'); g.px([[bx - 1, by], [bx + 2, by]].filter(([a, b]) => g.filled(a, b)), '#c0ccff'); }
      g.px([[x - 4, y - 1], [x + 1, y - 1], [x - 2, y - 4]].filter(([a, b]) => g.filled(a, b)), '#eef2ff');
    },
    daisy(g, x, y) {
      for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6; g.ell(x + Math.cos(a) * 3, y + Math.sin(a) * 3, 2, 0.95, ['#ffffff', '#f4f4fb', '#b8c0d8'], a); }
      g.ell(x, y, 1.7, 1.7, RAMPS.sun);
    },
    daisyD(g, x, y) { for (let i = 0; i < 12; i++) { const a = (i + 0.5) * Math.PI / 6, px = Math.floor(x + Math.cos(a) * 3.9), py = Math.floor(y + Math.sin(a) * 3.9); if (g.filled(px, py) && g.get(px, py) !== '#f6c83a') g.set(px, py, '#cbd3e8'); } },
    hibiscus(g, x, y) {
      const HR = ['#ffb0bc', '#ec4c64', '#a0223a'];
      for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; g.ell(x + Math.cos(a) * 2.3, y + Math.sin(a) * 2.3, 2.55, 2.4, HR); }
      g.ell(x, y, 1.3, 1.3, '#8a2433');
    },
    hibiscusD(g, x, y) {
      for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; for (const r of [1.6, 2.6]) { const px = Math.floor(x + Math.cos(a) * r), py = Math.floor(y + Math.sin(a) * r); if (g.filled(px, py)) g.set(px, py, '#c02a4a'); } }
      g.px([[x, y - 1], [x + 1, y - 2], [x + 2, y - 3]], '#fbf3dc'); g.px([[x + 2, y - 4], [x + 3, y - 3]], '#fbf236');
    },
    sealily(g, x, y) {
      const AQ = ['#d8fff8', '#8ee0d8', '#4a9aa8'], WH = ['#ffffff', '#eafcff', '#a8d8e0'];
      g.ell(x, y + 3.7, 4.6, 1.1, ['#6abe30', '#37946e', '#2f6048']);
      const pet = (ang, R) => { const a = ang * Math.PI / 180; g.ell(x + Math.cos(a) * 2.4, y + 2.3 + Math.sin(a) * 2.4, 2.6, 1.3, R, a); };
      pet(-165, AQ); pet(-15, AQ); pet(-128, WH); pet(-52, WH); pet(-90, WH);
    },
    sealilyD(g, x, y) { g.px([[x, y - 2], [x - 4, y + 1], [x + 3, y + 1]].filter(([a, b]) => g.filled(a, b)), '#5fcde4'); g.set(x - 1, y + 2, '#fbf236'); g.set(x, y + 2, '#fbf236'); },
    beachrose(g, x, y) {
      g.ell(x - 3.4, y + 3, 2.1, 1, RAMPS.leaf, 0.5); g.ell(x + 3.4, y + 3, 2.1, 1, RAMPS.leaf, -0.5);
      g.ell(x, y, 4.1, 3.7, ['#ffc4b0', '#f47e68', '#b8483e']);
    },
    beachroseD(g, x, y) {
      g.px([[x, y - 1], [x - 1, y - 1], [x - 2, y], [x - 2, y + 1], [x - 1, y + 2], [x, y + 2], [x + 1, y + 2], [x + 2, y + 1], [x + 2, y], [x + 2, y - 1], [x + 1, y - 2], [x, y - 3], [x - 1, y - 3], [x - 2, y - 3]].filter(([a, b]) => g.filled(a, b)), '#c4524a');
      g.px([[x, y], [x + 1, y]], '#ffd8c8'); g.px([[x - 3, y - 2], [x - 3, y - 1]].filter(([a, b]) => g.filled(a, b)), '#ffe4d8');
    },
    primrose(g, x, y) {
      for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; g.ell(x + Math.cos(a) * 2.5, y + Math.sin(a) * 2.5, 2.2, 2.2, ['#fffde8', '#fbf09a', '#d4b84a']); }
      g.ell(x, y, 1.2, 1.2, '#f6a83a');
    },
    primroseD(g, x, y) {
      for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5, px = Math.floor(x + Math.cos(a) * 4.4), py = Math.floor(y + Math.sin(a) * 4.4); g.set(px, py, INK); }
      g.set(x, y, '#6abe30');
    },
    moonflower(g, x, y) { g.ell(x, y, 4.5, 4.3, ['#ffffff', '#ece6ff', '#b8a8e8']); },
    moonflowerD(g, x, y) {
      for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; for (const r of [1.5, 2.5, 3.4]) { const px = Math.floor(x + 0.5 + Math.cos(a) * r), py = Math.floor(y + 0.5 + Math.sin(a) * r); if (g.filled(px, py)) g.set(px, py, '#c9b4f0'); } }
      g.px([[x - 1, y - 1], [x, y - 1], [x - 1, y], [x, y]], '#fff6b0');
      g.px([[x - 6, y - 3], [x + 5, y - 4], [x + 5, y + 3], [x - 6, y + 3]], '#fff27a');
    },
    nightshade(g, x, y) {
      g.poly(starPts(x, y, 5, 2.2, 5), '#7a44b8'); shade(g, x, y, 5.2, 5.2, ['#b58ae8', '#7a44b8', '#4a2478']);
    },
    nightshadeD(g, x, y) {
      for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; for (const r of [1.6, 2.6]) { const px = Math.floor(x + Math.cos(a) * r), py = Math.floor(y + Math.sin(a) * r); if (g.filled(px, py)) g.set(px, py, '#3a1c60'); } }
      g.px([[x - 1, y - 1], [x, y - 1]], '#fff27a'); g.px([[x - 1, y], [x, y]], '#f6c83a');
    },
    candytulip(g, x, y) {
      const T = new Grid(g.w, g.h);
      T.ell(x, y + 0.9, 3.6, 3.3, '#fff'); T.poly([[x - 3.6, y + 1], [x - 3.4, y - 3.6], [x - 1.5, y - 1.2], [x, y - 4.4], [x + 1.5, y - 1.2], [x + 3.4, y - 3.6], [x + 3.6, y + 1]], '#fff');
      for (let j = 0; j < T.h; j++) for (let i = 0; i < T.w; i++) if (T.get(i, j)) {
        const st = ((i - j) % 4 + 4) % 4, dx = (i + 0.5 - x) / 3.6;
        g.set(i, j, st < 2 ? (dx > 0.45 ? '#b8304a' : '#e8445a') : (dx > 0.45 ? '#f0c8d8' : dx < -0.4 ? '#ffffff' : '#fff0f4'));
      }
    },
    cottonrose(g, x, y) {
      const P = ['#fff0f8', '#ffc8e0', '#e090b8'], V = ['#faf2ff', '#dcc8f8', '#a890d8'];
      g.ell(x - 2.4, y + 0.6, 2.3, 2.2, P); g.ell(x + 2.4, y + 0.6, 2.3, 2.2, P); g.ell(x, y + 2.3, 2.4, 2, V);
      g.ell(x - 1.4, y - 2.1, 2.2, 2.1, V); g.ell(x + 1.5, y - 2.2, 2.2, 2.1, P); g.ell(x, y, 2, 1.8, P);
    },
    cottonroseD(g, x, y) { g.px([[x - 1, y], [x, y - 1], [x + 1, y]], '#e090b8'); g.px([[x - 3, y - 3], [x + 1, y - 4], [x - 4, y]].filter(([a, b]) => g.filled(a, b)), '#ffffff'); },
    sugarblossom(g, x, y) {
      g.ell(x + 0.5, y + 0.5, 3.4, 0.7, '#8f563b', -0.5);
      const bl = (bx, by) => { for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; g.ell(bx + Math.cos(a) * 1.35, by + Math.sin(a) * 1.35, 1.2, 1.2, ['#fff0f6', '#ffb8d4', '#e07ba0']); } };
      bl(x - 2.3, y - 1.6); bl(x + 2.5, y - 2.1); bl(x + 0.3, y + 2.3);
    },
    sugarblossomD(g, x, y) { for (const [bx, by] of [[x - 2.3, y - 1.6], [x + 2.5, y - 2.1], [x + 0.3, y + 2.3]]) { g.set(Math.floor(bx), Math.floor(by), '#d24552'); } g.px([[x - 6, y - 4], [x + 5, y + 2]], '#ffd6e8'); },
  };
  function flowerArt(g, id, x, y) { (FLO[id] || FLO.primrose)(g, x, y); }
  function flowerDetail(g, id, x, y) { const d = FLO[(FLO[id] ? id : 'primrose') + 'D']; if (d) d(g, Math.floor(x), Math.floor(y)); }

  // ---------------- The Sprig ----------------
  const DEFAULT_LOOK = {
    body: 'mint', leaf: 'leaf', belly: BELLY, cheek: '#f4a3b8',
    pattern: 'plain', patternColor: '#fbf3dc', eyes: 'round', eyeColor: '#5b6ee1',
    hat: 'none', extra: 'none',
    parts: { wings: 0, ears: 0, fins: 0, horns: 0, tail: 0, shell: 0 },
  };
  function cloneLook(l) { return JSON.parse(JSON.stringify(l || DEFAULT_LOOK)); }
  const BUD_RAMP = { sun: RAMPS.sun, moon: ['#b8a8ff', '#7a5ad8', '#43308e'], wild: RAMPS.leaf };
  // PX.RIM (default on): a little more volume on Sprout bodies. Toggle with PX.RIM = false (clears the sprite cache).
  let RIM = true;

  // blend two #rrggbb colours (k=0 -> a, k=1 -> b)
  function mixHex(a, b, k) {
    try {
      const p = s => [1, 3, 5].map(i => parseInt(s.slice(i, i + 2), 16)), A = p(a), B = p(b);
      return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * k).toString(16).padStart(2, '0')).join('');
    } catch (e) { return a; }
  }

  // ---------------- Special skins ----------------
  // A skinned body is drawn with this sentinel ramp, then every sentinel pixel is repainted by position + tone.
  const SKIN_SENT = ['#0b0a01', '#0b0a02', '#0b0a03'];
  const RBW = [
    ['#ffd4dc', '#ffe0bc', '#fff8c4', '#dcf8c4', '#cceeff', '#e8d8ff'],
    ['#ff9aaa', '#ffbc78', '#fbe46a', '#a4e27a', '#7ccff4', '#bc9cf0'],
    ['#d0607a', '#d88a40', '#c8a632', '#5aa84c', '#4a90c8', '#8062c0'],
  ];
  const CRY = [
    ['#f6feff', '#eaf8ff', '#f6f0ff', '#eefaff', '#fcf8ff', '#e2f2ff'],
    ['#c8ecfa', '#bfe2f8', '#d8ccf8', '#a8d4f2', '#e2d8ff', '#a2c8ee'],
    ['#8ab8e0', '#94a8e8', '#a898e0', '#7aa8d8', '#b0a0e8', '#6a98d0'],
  ];
  const GOLD = ['#ffffff', '#fff6a8', '#fcd850', '#e8a42a', '#a8680e'];
  const PUMPKIN = ['#ffc47a', '#f7922e', '#c8581c'], GHOST = ['#ffffff', '#efeaff', '#c9bdf0'], WRAP = ['#fffaf0', '#ece0c4', '#c4ae88'];
  const CORN = [['#ffffff', '#fff4e2', '#dccab0'], ['#ffc27a', '#ff9a22', '#d0660c'], ['#fff3a0', '#ffd23a', '#d8a018']];
  const VAMP = [['#6e5a96', '#4a3a6c', '#2e2448'], ['#fbf8ff', '#ebe4f6', '#c4b8d8']], WITCH = [['#c89af0', '#8e56c8', '#5a2e8a'], ['#d8f6a8', '#a2dc6a', '#62a848']];
  // ---- special-egg skins (eclipse, galaxy, frost, blossom, pearl) ----
  const ECL = { sun: ['#fff2a0', '#fcc43e', '#ec982c'], dusk: ['#fbb442', '#f5922e', '#e27a26'], seam: '#fff4c8', night: ['#5a66cc', '#3a3f9c', '#262a6a'] };
  const ECL_STARS = [[6.5, -3.5, '#ffffff'], [5.5, 3.5, '#fff27a'], [4.5, 5.5, '#ffffff']];
  const eclSide = (dx, dy) => Math.hypot(dx + 4, dy + 0.5) - 8.3; // < 0: sunny side; >= 0: the night crescent on the right
  const GAL = ['#5c4cb8', '#3a2e88', '#231a56'], NEB = ['#b86ad8', '#8a44b8', '#5a2a86'];
  const GAL_TWINKLE = [[-4.5, -4.5], [5.5, 3.5]];
  const FROST = ['#dcf2ff', '#aad6f4', '#6f9fd8'];
  const FROST_FLAKES = [[5.5, -2.5], [-5.5, 2.5], [5.5, 4.5]];
  const BLOS = ['#ffdcea', '#f7aecb', '#d97ca6'], BLOS_AT = [[4.5, -4.5], [-4.5, -5.5], [6.5, 3.5], [-6.5, 3.5]], BLOS_ORB = [[-3.2, -2.4], [3.6, 3.4]];
  const PEARL = [['#fff8fc', '#f9e2ee', '#d4b8d8'], ['#f8fbff', '#e2e8fb', '#b8c2e4'], ['#f8fffc', '#dff3ec', '#b4d2cc'], ['#fffbf4', '#fae8d8', '#d8c0b4']];
  // f(x, y, tone, dx, dy, toneAt) -> colour. dx/dy = offset from the body centre in sprig-body units.
  const SKINS = {
    gold(x, y, t, dx, dy) {
      if (t === 2) return GOLD[4];
      if (t === 0) return Math.abs(dx + dy + 8.6) < 0.75 || Math.abs(dx + dy + 11.2) < 0.5 ? GOLD[0] : GOLD[1];
      return dy > 1.2 && dy < 4.6 ? GOLD[3] : GOLD[2];
    },
    rainbow(x, y, t, dx, dy) { const b = Math.floor((dy + dx * 0.45 + 60) / 2.6) % 6; return RBW[t][b]; },
    crystal(x, y, t, dx, dy, at, k) {
      const facet = (ax, ay) => { const a = Math.atan2(ay, ax), r = Math.hypot(ax / 7.2, ay / 6.8), o = r > 0.58; return (Math.floor((a + Math.PI) / (Math.PI / 3) + (o ? 0.5 : 0)) % 6) + (o ? 6 : 0); };
      const f = facet(dx, dy);
      for (const [ox, oy] of [[1, 0], [0, 1]]) if (at(x + ox, y + oy) >= 0 && facet(dx + ox / k, dy + oy / k) !== f) return '#ffffff';
      return CRY[t][(f * 5) % 6];
    },
    ember(x, y, t) {
      if (t === 2) return RAMPS.berry[2];
      const row = Math.floor(y / 3);
      if (y % 3 === 2 && (x + (row % 2) * 2) % 4 !== 0) return '#9a2c3c';
      return RAMPS.berry[t];
    },
    // ---- Halloween skins (cute, not scary) ----
    pumpkin(x, y, t, dx, dy) {
      const w = Math.sqrt(Math.max(0.15, 1 - (dy / 8.4) * (dy / 8.4))), u = Math.abs(dx / w);
      if (Math.abs(u - 3.3) < 0.5 || Math.abs(u - 6.7) < 0.45) return t === 0 ? PUMPKIN[1] : PUMPKIN[2];
      return PUMPKIN[t];
    },
    ghost(x, y, t) { return GHOST[t]; },
    mummy(x, y, t, dx, dy, at, k, base) {
      if (faceZone(dx, dy, -0.35)) return mixHex(base[Math.min(1, t)], '#5a4030', 0.14);
      if (faceZone(dx, dy, 0.3)) return WRAP[2];
      const f = ((((x >> 1) - y) % 3) + 3) % 3;
      if (f === 0) return mixHex(base[Math.min(2, t + 1)], '#5a4030', 0.3);
      if (t === 2) return WRAP[2];
      return f === 1 ? WRAP[1] : WRAP[0];
    },
    candycorn(x, y, t, dx, dy) { const e = dy + ((x + y) & 1 ? 0.3 : -0.3); return (e < -3.4 ? CORN[0] : e < 2.4 ? CORN[1] : CORN[2])[t]; },
    vampire(x, y, t, dx, dy) {
      if (faceZone(dx, dy, 0) && dy > -4.4 + Math.max(0, 1.3 - Math.abs(dx) * 0.7)) return VAMP[1][t];
      const ax = Math.abs(dx);
      if (dy > 1.1 && dy < 4.2 && ax > 3.4 && ax < 3.4 + (4.2 - dy) * 1.1) return ax < 4.4 + (4.2 - dy) * 0.3 ? '#e8506a' : '#b02846';
      return VAMP[0][t];
    },
    witch(x, y, t, dx, dy) {
      if (faceZone(dx, dy, 0)) return WITCH[1][t];
      const h = (x * 73 + y * 151) % 23;
      if (h === 0 || (h === 11 && t < 2)) return t === 2 ? '#f6c83a' : '#fff27a';
      return WITCH[0][t];
    },
    // ---- special-egg skins ----
    // Eclipse: a sunny-gold side and a night-blue crescent with tiny stars, meeting at a thin glowing seam (the face stays on the sunny side)
    eclipse(x, y, t, dx, dy, at, k) {
      const u = 1 / k;
      if (eclSide(dx, dy) < 0) return eclSide(dx + u, dy) >= 0 ? ECL.dusk[t] : ECL.sun[t];
      if (eclSide(dx - u, dy) < 0 || eclSide(dx, dy - u) < 0 || eclSide(dx, dy + u) < 0) return ECL.seam;
      for (const [sx, sy, c] of ECL_STARS) if (Math.abs(dx - sx) < 0.5 * u && Math.abs(dy - sy) < 0.5 * u) return c;
      if (eclSide(dx - 2 * u, dy) < 0) return ECL.night[0];
      return ECL.night[Math.max(1, t)];
    },
    // Galaxy: deep indigo with a soft nebula band and twinkly stars
    galaxy(x, y, t, dx, dy, at, k) {
      for (const [sx, sy] of GAL_TWINKLE) {
        const ox = Math.round((dx - sx) * k), oy = Math.round((dy - sy) * k);
        if (!ox && !oy) return '#ffffff';
        if (k >= 1 && Math.abs(ox) + Math.abs(oy) === 1) return '#aab4ff';
      }
      if (Math.abs(dx) < 2 && dy > -4.6 && dy < 2.6) return GAL[t]; // calm between the eye patches
      if (!faceZone(dx, dy, 0.4) && (x * 37 + y * 23 + ((x * y) % 5) * 7) % 19 === 0) return ['#ffffff', '#fff6b0', '#b8f0ff'][(x + y) % 3];
      const v = dy - dx * 0.8;
      if (Math.abs(v) < 1.1) return NEB[t];
      if (Math.abs(v) < 2.3 && (x + y) & 1) return NEB[Math.min(2, t + 1)];
      return GAL[t];
    },
    // Frost: icy white-blue with a snowy cap, little snowflakes and frosty glints
    frost(x, y, t, dx, dy, at, k) {
      const u = 1 / k, cap = -5 + Math.sin(dx * 1.1 + 0.6) * 0.75;
      if (dy < cap) return '#ffffff';
      if (dy < cap + u) return (x + y) & 1 ? '#ffffff' : FROST[0];
      for (const [sx, sy] of FROST_FLAKES) {
        const ox = Math.round((dx - sx) * k), oy = Math.round((dy - sy) * k);
        if (!ox && !oy) return '#ffffff';
        if (k >= 1 && Math.abs(ox) === 1 && Math.abs(oy) === 1) return '#ffffff';
      }
      if (t > 0 && !faceZone(dx, dy, 0.4) && (x * 29 + y * 47) % 31 === 0) return '#f0faff'; // frosty glints
      return FROST[t];
    },
    // Blossom: soft spring pink with tiny 5-petal flowers (white petals, yellow middle)
    blossom(x, y, t, dx, dy, at, k) {
      for (const [sx, sy] of k >= 1 ? BLOS_AT : BLOS_ORB) {
        const ox = Math.round((dx - sx) * k), oy = Math.round((dy - sy) * k);
        if (Math.abs(ox) > 1 || Math.abs(oy) > 1) continue;
        if (!ox && !oy) return '#fbf236';
        if (oy === -1 && !ox) return '#ffffff';
        if (oy === 0) return '#ffffff';
        if (oy === 1 && ox) return '#fff4f8';
      }
      return BLOS[t];
    },
    // Pearl: pearly white with a gentle pastel sheen in soft rings round the highlight
    pearl(x, y, t, dx, dy) {
      const r = Math.hypot(dx + 3.5, dy + 4.2), band = Math.floor(r / 2.6) % 4;
      return PEARL[band][t];
    },
  };
  // the face stays readable on patterned skins: an oval around the eyes and mouth (sprig-body units)
  const faceZone = (dx, dy, grow) => (dx / (6.2 + grow)) ** 2 + ((dy + 0.9) / (3.5 + grow)) ** 2 < 1;
  const SKIN_IDS = Object.keys(SKINS);
  // sparkle colours per special skin (and 'shiny'), for the garden's twinkles: PX.SKIN_FX[id] -> ['#hex', ...]
  const SKIN_FX = {
    gold: ['#fff27a', '#ffffff'], rainbow: ['#f07a84', '#f6a83a', '#fbf236', '#99e550', '#5fcde4', '#c9a2f0'], crystal: ['#ffffff', '#c8ecfa', '#d8ccf8'], ember: ['#f6a83a', '#fff27a'],
    pumpkin: ['#ffb040', '#fff27a'], ghost: ['#ffffff', '#e0d8ff'], mummy: ['#fffaf0', '#e8dcc0'], candycorn: ['#ffffff', '#ff9a22', '#ffd23a'],
    vampire: ['#4a3a6c', '#e8506a', '#c9a2f0'], witch: ['#8e56c8', '#9ad862', '#fff27a'],
    eclipse: ['#fff27a', '#f6a83a', '#ffffff', '#9aa6f4'], galaxy: ['#ffffff', '#fff6b0', '#c9a2f0', '#b8f0ff'], frost: ['#ffffff', '#c8ecfa', '#e8f6ff'],
    blossom: ['#ffffff', '#f7b6c8', '#fbf236'], pearl: ['#ffffff', '#fce8f0', '#e4ecfc', '#ece4fc'],
    shiny: ['#ffffff', '#fff6c8'],
  };
  const SPOOKY_SKINS = ['pumpkin', 'ghost', 'mummy', 'candycorn', 'vampire', 'witch'];
  const SKIN_BELLY = { ember: '#fff0c4', pumpkin: '#ffe2b0', ghost: '#ffffff', candycorn: '#fff8e0', vampire: '#f4eeff', witch: '#f0e2ff', mummy: null,
    eclipse: '#fff4d6', galaxy: '#e6dcff', frost: '#f6fbff', blossom: '#fff6fa', pearl: '#fffaf6' };
  const SKIN_BELLY_SHADE = { eclipse: '#c89060', galaxy: '#8a78c8', frost: '#8cb4dc', blossom: '#d890b0', pearl: '#b8aed0' }; // newer skins (older ones keep the brown)
  const SKIN_DARK = { galaxy: 1 }; // dark skins get the pale eye patches that dark bodies have
  // [mid, dark] of each skin, so the newer pattern stickers can pick a colour that shows up on it
  const SKIN_TONE = { gold: ['#fcd850', '#a8680e'], rainbow: ['#fbe46a', '#8062c0'], crystal: ['#c8ecfa', '#8ab8e0'], ember: ['#d24552', '#8a2433'], pumpkin: ['#f7922e', '#c8581c'],
    ghost: ['#efeaff', '#c9bdf0'], mummy: ['#ece0c4', '#8a7456'], candycorn: ['#ff9a22', '#d0660c'], vampire: ['#4a3a6c', '#2e2448'], witch: ['#8e56c8', '#5a2e8a'],
    eclipse: ['#fcc43e', '#c86a1c'], galaxy: ['#3a2e88', '#231a56'], frost: ['#c4e4f8', '#8cbae2'], blossom: ['#fbc2da', '#e690b8'], pearl: ['#ecf0fc', '#c8cfe8'] };
  function applySkin(g, skin, cx, cy, k, base) {
    const f = SKINS[skin]; if (!f) return;
    base = base || RAMPS.cream;
    const tone = new Map();
    for (let i = 0; i < g.a.length; i++) { const t = SKIN_SENT.indexOf(g.a[i]); if (t >= 0) tone.set(i, t); }
    const at = (x, y) => (x < 0 || y < 0 || x >= g.w || y >= g.h ? -1 : tone.has(y * g.w + x) ? tone.get(y * g.w + x) : -1);
    const out = [];
    for (const [i, t] of tone) { const x = i % g.w, y = (i / g.w) | 0; out.push([i, f(x, y, t, (x + 0.5 - cx) / k, (y + 0.5 - cy) / k, at, k, base)]); }
    for (const [i, c] of out) g.a[i] = c;
  }

  // ---------------- Hats & extras (shared by buildSprig and the hat icons; sprig 32x32 coordinates) ----------------
  const HAT_IDS = ['crown', 'beanie', 'tophat', 'flower', 'bow', 'leafcap', 'party', 'wizard', 'sunhat', 'cap', 'witch', 'flowercrown', 'bandana', 'headphones', 'propeller'];
  const EXTRA_IDS = ['halo', 'star', 'moon', 'heart'];
  const HIDES_LEAVES = { beanie: 1, tophat: 1, wizard: 1, sunhat: 1, cap: 1, witch: 1, propeller: 1 };
  // striped cone from base-left / base-right to tip; stripes spiral a little, 3-tone across the cone
  function cone(h, bl, br, tp, ramps, n) {
    const T = new Grid(h.w, h.h); T.poly([bl, br, tp], '#fff');
    const mx = (bl[0] + br[0]) / 2, my = (bl[1] + br[1]) / 2, ax = tp[0] - mx, ay = tp[1] - my, al2 = ax * ax + ay * ay, sx = br[0] - bl[0], sy = br[1] - bl[1], sl2 = sx * sx + sy * sy;
    for (let y = 0; y < T.h; y++) for (let x = 0; x < T.w; x++) if (T.get(x, y)) {
      const px = x + 0.5 - mx, py = y + 0.5 - my, u = clamp((px * ax + py * ay) / al2, 0, 1), rel = ((px * sx + py * sy) / sl2) / Math.max(0.1, (1 - u) * 0.5);
      const R2 = ramps[((Math.floor(u * n + rel * 0.3 + 8) % ramps.length) + ramps.length) % ramps.length];
      h.set(x, y, R2[rel < -0.4 ? 0 : rel > 0.4 ? 2 : 1]);
    }
    return h;
  }
  function hatArt(h, hat, crowned, bloom, icon) { // icon: the closet icon version (wide hats kept within 16 px)
    switch (hat) {
      case 'crown': h.poly([[11, 14.5], [11, 9], [13.5, 11.5], [16, 8], [18.5, 11.5], [21, 9], [21, 14.5]], '#f6c83a').rect(11, 13, 10, 1, '#c7861c'); h.px([[15, 12], [16, 12]], '#d95763'); h.px([[12, 11], [16, 9]], '#fff27a'); if (crowned) h.poly([[13.5, 12], [16, 9.5], [18.5, 12]], null); break;
      case 'beanie': h.ell(16, 16.2, 7.8, 4.6, RAMPS.berry, 0, (x, y) => y <= 15).rect(9, 15, 14, 2, '#fbf3dc'); h.ell(16, 10.2, 1.8, 1.8, '#ffffff'); break;
      case 'tophat': h.rect(10, 14, 12, 2, '#3f3f74').rect(12, 7, 8, 7, '#4a4aa0').rect(12, 12, 8, 1, '#d95763').px([[13, 8], [13, 9]], '#7d8cf0'); break;
      case 'flower': if (!bloom) h.px([[22, 13], [21, 14], [23, 14], [22, 15]], '#f7b6c8').px([[22, 14]], '#fbf236'); break;
      case 'bow': h.poly([[16.5, 14], [21, 11.5], [21, 16.5]], '#9a6ad0').poly([[15.5, 14], [11, 11.5], [11, 16.5]], '#9a6ad0').px([[15, 13], [16, 13], [15, 14], [16, 14]], '#c9a2f0'); break;
      case 'leafcap': h.ell(16, 15.5, 8, 3.2, RAMPS.leaf, 0, (x, y) => y <= 15).px([[16, 11], [16, 12]], '#37946e'); break;
      case 'party': {
        // centred cone on a Seedling; tipped over to the left of a bud/bloom (like the crown, it leaves the flower visible)
        const [bl, br, tp, pp] = crowned ? [[7.8, 17], [15, 14.4], [7.2, 5.4], [8, 6]] : [[11.6, 15.2], [20.4, 15.2], [16, 5.2], [16, 6]];
        cone(h, bl, br, tp, [['#ffb8dc', '#f26aa8', '#b83a78'], ['#fffab0', '#fbe036', '#c8a018']], 4.4);
        piece(h, t => t.ell(pp[0], pp[1], 1.8, 1.8, ['#d8fcff', '#5fdcf0', '#2a98b8']));
        h.set(pp[0] - 1, pp[1] - 1, '#ffffff');
        break;
      }
      case 'witch': {
        const WT = ['#a47ae0', '#6c3eb0', '#43206e'];
        piece(h, t => { t.poly([[11.2, 14.6], [20.8, 14.6], [19, 9.6], [18.2, 6], [21.8, 3.2], [16.4, 4.2], [13.6, 9.6]], WT[1]); shade(t, 14.4, 10.4, 6.6, 6.6, WT); });
        for (let x = 0; x < 32; x++) for (const y of [12, 13]) if (WT.includes(h.get(x, y))) h.set(x, y, y === 12 ? '#ff9a22' : '#d0660c');
        h.px([[15, 12], [16, 12], [17, 12], [15, 13], [17, 13]], '#fbf236'); h.set(16, 13, '#6c3eb0');
        piece(h, t => t.ell(16, 15.4, 8.4, 1.7, WT));
        h.px([[14, 9], [14, 10], [15, 7]].filter(([x, y]) => WT.includes(h.get(x, y))), '#c8a8f4');
        break;
      }
      case 'wizard': {
        const WZ = ['#8aa8ff', '#4a5ed8', '#2c3490'];
        piece(h, t => { t.poly([[11.2, 14.6], [20.8, 14.6], [19.4, 9.2], [22.6, 5], [16.8, 7], [13.4, 10.4]], WZ[1]); shade(t, 14.6, 11.6, 6.6, 6, WZ); });
        piece(h, t => t.ell(16, 15.4, 7.1, 1.55, WZ));
        h.px([[15, 11], [14, 12], [16, 12], [15, 13], [19, 9], [18, 13], [20, 6]], '#fbf236'); h.set(15, 12, '#ffffff');
        break;
      }
      case 'sunhat': {
        const ST = ['#fff6c8', '#f0d284', '#c8a050'];
        piece(h, t => t.ell(16, 15.3, 7.1, 1.9, ST));
        piece(h, t => t.ell(16, 13.8, 4.4, 3.8, ST, 0, (x, y) => y <= 14));
        for (let y = 9; y < 18; y++) for (let x = 8; x < 24; x++) if (h.get(x, y) === ST[1] && (x + y * 2) % 4 === 0) h.set(x, y, '#e0bc6a');
        h.rect(12, 13, 8, 1, '#e8445a'); h.px([[19, 12], [20, 12], [20, 13], [21, 13]], '#f07a8a'); h.set(19, 13, '#b8304a');
        h.px([[12, 11], [13, 10]], '#ffffff');
        break;
      }
      case 'cap': {
        const CP = ['#9fd8ff', '#639bff', '#3f55b8'];
        piece(h, t => t.poly([[16, 14.2], [23, 14.8], [23, 16.6], [16, 16.6]], CP[2]));
        piece(h, t => t.ell(14.6, 16.2, 6, 5, CP, 0, (x, y) => y <= 15));
        h.px([[14, 11], [14, 12], [14, 13], [14, 14]].filter(([x, y]) => h.get(x, y) && h.get(x, y) !== INK), CP[2]);
        h.px([[12, 13], [11, 13], [12, 14], [11, 14], [13, 14]].filter(([x, y]) => h.get(x, y) && h.get(x, y) !== INK), '#ffffff');
        h.set(18, 15, '#9fd8ff'); h.set(19, 15, '#9fd8ff');
        break;
      }
      // ---- newer hats ----
      case 'flowercrown': { // a leafy wreath round the top of the head with little flowers (leaves, buds and blooms stay visible)
        const LF = ['#99e550', '#6abe30', '#37946e'];
        for (const [x, y0] of [[9, 16], [10, 16], [11, 15], [12, 15], [13, 14], [14, 14], [17, 14], [18, 14], [19, 15], [20, 15], [21, 16], [22, 16]]) { h.set(x, y0, LF[0]); h.set(x, y0 + 1, LF[1]); }
        h.px([[15, 14], [16, 14]], LF[1]); h.px([[15, 15], [16, 15]], LF[2]);
        for (const [x, y, p, c] of [[10, 15, '#f7a6c8', '#fbf236'], [13, 13, '#ffffff', '#fbf236'], [18, 13, '#c9a2f0', '#fbf236'], [21, 15, '#fff27a', '#f6a83a']]) { h.px([[x, y - 1], [x - 1, y], [x + 1, y], [x, y + 1]], p); h.set(x, y, c); }
        h.px([[12, 15], [19, 15]], LF[2]); h.set(9, 15, '#ffd6e8'); h.set(18, 12, '#ece0ff'); // petal highlights
        break;
      }
      case 'bandana': { // a red spotty headband with a knot and two flappy tails on the right
        const RD = ['#ff8a8a', '#e0303c', '#961c30'], x0 = icon ? 11 : 9, x1 = icon ? 20 : 22;
        for (let x = x0; x <= x1; x++) { h.set(x, 16, x < x0 + 3 ? RD[0] : RD[1]); h.set(x, 17, x > x1 - 3 ? RD[2] : RD[1]); }
        for (let x = x0 + 1; x <= x1 - 1; x++) h.set(x, 15, x < x0 + 3 || x > x1 - 3 ? RD[1] : RD[0]);
        const k = x1 + 1; // knot, then the tails
        h.px([[k, 15], [k, 16], [k, 17], [k - 1, 18]], RD[1]); h.set(k, 16, RD[0]);
        if (icon) { h.px([[k + 1, 14], [k + 2, 14]], RD[1]); h.px([[k + 1, 18], [k + 2, 18]], RD[2]); }
        else { h.px([[k + 1, 14], [k + 2, 13], [k + 2, 14], [k + 3, 13]], RD[1]); h.px([[k + 1, 18], [k + 2, 18], [k + 2, 19], [k + 3, 19]], RD[2]); h.set(k + 1, 16, RD[2]); h.set(k + 1, 17, RD[2]); }
        h.px([[x0 + 2, 16], [x0 + 6, 15], [x0 + 9, 17], [x0 + 5, 17], [x1 - 1, 16]], '#ffffff');
        break;
      }
      case 'headphones': { // a band hugging the top of the head (under the leaves) and round ear cups
        const CUP = ['#ffb0c8', '#f0588c', '#a82a5c'], BD = ['#eef0f6', '#b4bccc', '#6e7690'], sp = icon ? 2.4 : 0;
        h.px([[10, 15], [11, 14], [12, 14], [13, 14], [14, 14], [15, 14], [16, 14], [17, 14], [18, 14], [19, 14], [20, 14], [21, 15]], BD[1]); h.px([[12, 14], [13, 14], [14, 14]], BD[0]); h.px([[19, 14], [20, 14]], BD[2]);
        for (const s of [-1, 1]) { const cx = 16 + s * (7.6 - sp); h.ell(cx, 17.8, 1.8, 2.5, CUP); h.set(Math.floor(cx - 0.9), 16, '#ffe0ec'); }
        break;
      }
      case 'propeller': { // a four-colour beanie with a little propeller on top
        const P4 = [['#ff8a8a', '#e0303c', '#961c30'], ['#fffab0', '#fcd82c', '#c49c14'], ['#b4ccff', '#4a78f0', '#2a44ac'], ['#c8f494', '#5cc83a', '#2c8434']];
        const T = new Grid(h.w, h.h); T.ell(16, 16.2, 7.8, 4.9, '#fff', 0, (x, y) => y <= 15);
        for (let y = 0; y < 32; y++) for (let x = 0; x < 32; x++) if (T.get(x, y)) {
          const a = Math.atan2(y + 0.5 - 11, x + 0.5 - 16), R2 = P4[Math.max(0, Math.min(3, Math.floor((Math.PI - a) / (Math.PI / 4))))];
          const d = (x + 0.5 - 16) / 7.8; h.set(x, y, R2[d < -0.5 ? 0 : d > 0.5 ? 2 : 1]);
        }
        h.rect(9, 15, 14, 2, '#3f55b8'); h.rect(9, 15, 4, 1, '#639bff');
        h.px([[16, 9], [16, 10]], '#8c93a8'); // post
        h.ell(13.2, 7.9, 2.7, 0.95, P4[0], -0.22).ell(18.8, 7.9, 2.7, 0.95, P4[1], -0.22).ell(16, 8, 0.9, 0.9, '#fbf236');
        h.px([[11, 12], [12, 11]], '#ffffff');
        break;
      }
    }
    return h;
  }
  function extraArt(h, extra, crowned) {
    const ey = crowned ? -4 : 0;
    switch (extra) {
      case 'halo': h.ell(16, 6.5 + ey, 5, 1.6, '#fbf236').ell(16, 6.5 + ey, 3.3, 0.7, null); break;
      case 'star': h.px([[16, 5], [15, 6], [16, 6], [17, 6], [16, 7]].map(([x, y]) => [x + (crowned ? 7 : 0), y + (crowned ? 1 : 0)]), '#fbf236'); break;
      case 'moon': h.px([[15, 5], [14, 6], [14, 7], [15, 8], [16, 8]].map(([x, y]) => [x + (crowned ? 9 : 0), y + (crowned ? 1 : 0)]), '#c9a2f0'); break;
      case 'heart': { // a little floating heart (off to the side of a bud or bloom, like the star)
        const ox = crowned ? 7 : 0, oy = crowned ? 1 : 0;
        h.px([[15, 4], [17, 4], [14, 5], [15, 5], [16, 5], [17, 5], [18, 5], [15, 6], [16, 6], [17, 6], [16, 7]].map(([x, y]) => [x + ox, y + oy]), '#f7608a');
        h.px([[14, 5], [15, 4]].map(([x, y]) => [x + ox, y + oy]), '#ffb4cc');
        break;
      }
    }
    return h;
  }

  // RIM: plain body-ramp pixels on the body's silhouette edge. Facing the light (upper-left) -> [x, y, tone, +1] rim light;
  // facing away (lower-right) -> [x, y, tone, -1] soft core shade. Patterns, belly, face, outline and silhouette are never touched.
  function rimPixels(g, body, R) { // body: Uint8Array(w*h), 1 = inside the body ellipse
    const out = [], W = g.w, edge = (x, y) => g.get(x, y) === INK && !body[y * W + x]; // outline outside the body, not a part's inner outline
    for (let i = 0; i < body.length; i++) {
      if (!body[i]) continue;
      const x = i % W, y = (i / W) | 0, t = R.indexOf(g.a[i]);
      if (t < 0) continue;
      const d = ((x + 0.5 - 16) / 8.3) * 0.55 + ((y + 0.5 - 22) / 7.7) * 0.85;
      if (d < -0.3 && (edge(x, y - 1) || edge(x - 1, y))) out.push([x, y, t, 1]);
      else if (d > 0.45 && (edge(x, y + 1) || edge(x + 1, y))) out.push([x, y, t, -1]);
    }
    return out;
  }
  // rim colours: step one tone up/down the body ramp (past the ends: blend toward white / ink); skins blend their own colours
  const rimMemo = new Map();
  function rimColor(c, t, s, R) {
    if (R) { if (s > 0 && t > 0) return R[t - 1]; if (s < 0 && t < 2) return R[t + 1]; c = R[t]; }
    const key = c + (s > 0 ? '+' : '-') + (R ? 'r' : 's');
    let v = rimMemo.get(key);
    if (v === undefined) {
      v = s > 0 ? mixHex(c, '#ffffff', R ? 0.35 : 0.3) : mixHex(c, INK, 0.2);
      if (rimMemo.size > 2000) rimMemo.clear();
      rimMemo.set(key, v);
    }
    return v;
  }

  // ---------------- Newer pattern stickers (pixel lists on the 32x32 Sprout, kept off the eyes, cheeks and mouth) ----------------
  const mirPts = pts => pts.concat(pts.map(([x, y]) => [31 - x, y]));
  const PAT_PTS = {
    zigzag: mirPts([[15, 16], [14, 17], [13, 16], [12, 15], [11, 16], [10, 17], [9, 18]]), // across the forehead, under the leaves
    patches: [[12, 16], [13, 16], [10, 17], [11, 17], [12, 17], [13, 17], [14, 17], [9, 18], [10, 18], [11, 18], [12, 18], [13, 18], [14, 18], [9, 19], [10, 19], [11, 19], [14, 19], [10, 20], [11, 20], [14, 20], [10, 21], [11, 21],
      [17, 14], [17, 15], [18, 15], [19, 15], [18, 16], [19, 16], [20, 16], [19, 17], [20, 17],
      [21, 25], [22, 25], [21, 26], [22, 26], [20, 27], [21, 27]],
    tiger: mirPts([[9, 17], [10, 17], [11, 17], [9, 18], [8, 20], [9, 20], [10, 20], [9, 25], [10, 25], [9, 26], [13, 15], [14, 16]]),
    moonmark: [[15, 15], [16, 15], [14, 16], [15, 16], [14, 17], [15, 17], [15, 18], [16, 18]],
  };
  const SHINY_BAND = [[18, 15], [19, 16], [20, 17], [21, 18], [19, 15], [20, 16], [21, 17], [22, 18]], SHINY_GLINTS = [[19, 15], [9, 24]];
  const rgbOf = h => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
  const lumOf = h => { const [r, g, b] = rgbOf(h); return (r * 0.3 + g * 0.59 + b * 0.11) / 255; };
  // a sticker colour that shows: the chosen colour, or (when it would vanish on a pale body) mostly the body's own dark tone
  function patternInk(pc, mid, dark) {
    if (!mid || !/^#[0-9a-f]{6}$/i.test(pc || '')) return pc;
    return Math.abs(lumOf(pc) - lumOf(mid)) >= 0.15 ? pc : mixHex(pc, dark, 0.85);
  }

  // pose: { frame:0|1 (idle bob / walk step), walk, flap, arms:'down'|'up'|'out'|'paddle'|'hold', eyes:'blink'|'happy'|'closed'|'sad'|..., mouth:'smile'|'open'|'o'|'flat'|'grin' }
  // part values 0..1: <0.5 small, <0.9 medium, >=0.9 big
  function buildSprig(L, P) {
    L = L || DEFAULT_LOOK; P = P || {};
    const g = new Grid(32, 32), B = new Grid(32, 32); // B = layer behind everything
    const skin = L.skin && SKINS[L.skin] ? L.skin : null; // skinned bodies draw with a sentinel ramp, repainted after outline
    const R = skin ? SKIN_SENT : (RAMPS[L.body] || RAMPS.mint), LR = RAMPS[L.leaf] || RAMPS.leaf, pt = L.parts || {};
    const pc2 = L.patternColor || '#fbf3dc';
    const sz = v => (v >= 0.9 ? 1.15 : v >= 0.5 ? 0.97 : 0.8);
    const hatHidesLeaves = !!HIDES_LEAVES[L.hat];
    const flap = P.flap ? (P.frame ? -1.6 : 1.2) : 0;
    const W = (ox, oy, kx, ky, pts) => pts.map(([x, y]) => [ox + x * kx, oy + y * ky + (y < -5 ? flap : 0)]);
    const both = (G, pts, col) => { G.poly(pts, col); G.poly(mirX(pts, 32), col); };
    // --- far behind (layer B): big wings, fan tails, back spikes, fluff collar ---
    if (pt.dragonwings > 0) {
      const k = sz(pt.dragonwings), w = W(9.5, 17.5, Math.min(k, 1), k * 0.95, [[0, -1.5], [-2.6, -8], [-6, -12.6], [-8.4, -12], [-8.6, -8], [-6.8, -7], [-8.6, -3.4], [-6.4, -3], [-7, 1.2], [-4.6, 0], [-3.4, 3.4], [0, 2]]);
      const D = new Grid(32, 32); both(D, w, '#d24552');
      for (let y = 0; y < 32; y++) for (let x = 0; x < 32; x++) if (D.get(x, y) && (x < 5 || x > 26) && (x + y) % 2) D.set(x, y, '#e05a6a');
      for (const i of [4, 6, 8]) { line(D, 9, 16, w[i][0], w[i][1], '#8a2433'); line(D, 22, 16, 31 - w[i][0], w[i][1], '#8a2433'); }
      for (const [a, b] of [[0, 1], [1, 2], [2, 3]]) { line(D, w[a][0], w[a][1], w[b][0], w[b][1], '#f07a84'); line(D, 31 - w[a][0], w[a][1], 31 - w[b][0], w[b][1], '#f07a84'); }
      under(B, D);
    }
    if (pt.batwings > 0) {
      const k = sz(pt.batwings), w = W(9.5, 18.5, Math.min(k, 1), k, [[0, -1], [-2.5, -5], [-7.8, -7.6], [-8.2, -4], [-7, -1], [-6.6, 2], [-5, 0.8], [-3.6, 3.6], [-2.2, 1.8], [0, 3]]);
      const D = new Grid(32, 32); both(D, w, '#4f4270'); shade(D, 16, 12, 16, 12, ['#76669e', '#4f4270', '#342a52']);
      for (const i of [2, 4, 7]) { line(D, 9, 18, w[i][0], w[i][1], '#2a2040'); line(D, 22, 18, 32 - w[i][0], w[i][1], '#2a2040'); }
      under(B, D);
    }
    if (pt.flamewings > 0) {
      const k = sz(pt.flamewings);
      for (const s of [-1, 1]) {
        [[168, 6, RAMPS.clay], [198, 8, RAMPS.clay], [228, 8.6, RAMPS.sun], [252, 6.4, RAMPS.sun]].forEach(([deg, len, ramp]) => {
          let a = deg * Math.PI / 180 + (flap ? flap * 0.07 : 0); const L2 = len * k;
          let dx = Math.cos(a), dy = Math.sin(a); if (s > 0) dx = -dx;
          piece(B, t => t.ell(16 + s * 6.5 + dx * L2 * 0.55, 19 + dy * L2 * 0.55, L2 * 0.55, 1.7 * k, ramp, Math.atan2(dy, dx)));
        });
      }
    }
    if (pt.fairywings > 0) {
      const k = sz(pt.fairywings), FR = ['#ffffff', '#dcefff', '#b4c8f4'];
      for (const s of [-1, 1]) {
        B.ell(16 + s * (6.6 + 3.3 * k), 15.5 - 2.2 * k + flap * 0.6, 2.5 * k, 4.3 * k, FR, s * -0.8);
        B.ell(16 + s * (6.8 + 2.6 * k), 22.4, 1.9 * k, 2.8 * k, FR, s * -0.3);
      }
    }
    if (pt.multitail > 0) {
      const k = sz(pt.multitail);
      const km = Math.min(k, 1);
      for (const [deg, len] of [[-82, 13], [-48, 12.4], [-14, 11]]) { const a = deg * Math.PI / 180, l2 = len * km; piece(B, t => t.ell(19.5 + Math.cos(a) * l2 * 0.52, 25 + Math.sin(a) * l2 * 0.52, l2 * 0.5, 2.5 * k, RAMP_X.cream, a)); }
    }
    if (pt.spikes > 0) {
      const k = sz(pt.spikes);
      for (const deg of [-160, -134, -108, -72, -46, -20]) {
        const a = deg * Math.PI / 180, rim = t => [16 + 8 * Math.cos(t), 22 + 7.4 * Math.sin(t)];
        B.poly([rim(a - 0.26), rim(a + 0.26), [16 + (8.3 + 4.4 * k) * Math.cos(a), 22 + (7.7 + 4.4 * k) * Math.sin(a)]], R[2]);
      }
    }
    if (pt.fluff > 0) {
      const k = sz(pt.fluff);
      for (const deg of [-170, -138, -106, -74, -42, -10, 20, 160]) { const a = deg * Math.PI / 180; B.ell(16 + (8.4 + 1.2 * k) * Math.cos(a), 22 + (7.8 + 1.2 * k) * Math.sin(a), 2.7 * k, 2.5 * k, RAMPS.cloud); }
    }
    // plant parts behind: a petal collar round the head, little thorns along the body edge
    if (pt.petals > 0) {
      const k = sz(pt.petals), PT = L.leaf === 'sun' ? ['#fff8b0', '#fbd84a', '#d0a02a'] : L.leaf === 'plum' ? ['#f4e8ff', '#c8aaf0', '#8c6cc4'] : ['#ffe4f0', '#f7a6c8', '#d0609a'];
      for (const deg of [-168, -140, -112, -90, -68, -40, -12, 14, 166]) {
        const a = deg * Math.PI / 180, r = 8.6 + 1.3 * k;
        piece(B, t => t.ell(16 + Math.cos(a) * r, 21.4 + Math.sin(a) * r * 0.9, 2.5 * k, 1.8 * k, PT, a));
      }
    }
    if (pt.thorns > 0) {
      const k = sz(pt.thorns);
      for (const deg of [-156, -126, -54, -24, 8, 172]) {
        const a = deg * Math.PI / 180, rim = t => [16 + 8.2 * Math.cos(t), 22 + 7.6 * Math.sin(t)], tip = 9 + 3.2 * k;
        B.poly([rim(a - 0.17), rim(a + 0.17), [16 + tip * Math.cos(a), 22 + tip * 0.93 * Math.sin(a)]], '#b8804a');
      }
    }
    // --- behind (main layer) ---
    if (pt.wings > 0) { const k = sz(pt.wings); const fl = P.flap ? (P.frame ? 0.35 : -0.25) : 0; g.ell(6.2, 19, 2.7 * k, 4.9 * k, RAMPS.cloud, -0.6 - fl); g.ell(25.8, 19, 2.7 * k, 4.9 * k, RAMPS.cloud, 0.6 + fl); }
    if (pt.shell > 0) { const k = pt.shell >= 0.9 ? 1.08 : pt.shell >= 0.5 ? 1 : 0.94; g.ell(16, 22.6, 10.2 * k, 8.4 * k, RAMPS.moss); }
    if (pt.tail > 0) { const k = sz(pt.tail); g.ell(24.6 + k, 26.4 - k, 3.6 * k, 2.1 * k, R, -0.7); g.ell(26.8 + 1.8 * k, 24.4 - 1.4 * k, 1.5 * k, 1.5 * k, LR[1]); }
    if (pt.ears > 0) { const k = sz(pt.ears); g.ell(10.4 - k, 13.6 - 1.2 * k, 1.9, 4.6 * k, R, -0.42); g.ell(21.6 + k, 13.6 - 1.2 * k, 1.9, 4.6 * k, R, 0.42); }
    if (pt.vines > 0) { const k = sz(pt.vines); for (const s2 of [-1, 1]) piece(g, t => stroke(t, [[16 + s2 * 7.6, 17.6], [16 + s2 * (9 + k), 16.4], [16 + s2 * (9.4 + k), 14.4], [16 + s2 * (8.2 + k), 13.6]], 0.6, 0.5, '#3f8a3a')); }
    const LEAFE = pt.leafears > 0 ? [9.4 - sz(pt.leafears) * 1.2, 14 - 1.6 * sz(pt.leafears), 4.4 * sz(pt.leafears)] : null;
    if (LEAFE) { const [ex2, ey2, el] = LEAFE; g.ell(ex2, ey2, 2.3, el, LR, -0.78); g.ell(32 - ex2, ey2, 2.3, el, LR, 0.78); }
    if (pt.fins > 0) { const k = sz(pt.fins); g.ell(7 - k * 0.6, 19, 2 * k, 3.4 * k, RAMPS.sky, -0.55); g.ell(25 + k * 0.6, 19, 2 * k, 3.4 * k, RAMPS.sky, 0.55); }
    if (pt.horns > 0) { const k = sz(pt.horns); const hc = '#eec39a'; g.poly([[10.5, 16.5], [13.8, 15.2], [10 - k, 10.5 - 2 * k]], hc); g.poly([[21.5, 16.5], [18.2, 15.2], [22 + k, 10.5 - 2 * k]], hc); }
    if (pt.antennae > 0) { const k = sz(pt.antennae); g.ell(11 - 3.2 * k, 15 - 6 * k, 1.3, 1.3, RAMPS.sun); g.ell(21 + 3.2 * k, 15 - 6 * k, 1.3, 1.3, RAMPS.sun); }
    // feet or tentacles
    const tent = pt.tentacles > 0;
    if (tent) {
      const k = sz(pt.tentacles), wig = P.frame ? 0.7 : 0;
      for (const s of [-1, 1]) {
        const o = 16 + s * 5.5, n = 16 + s * 2.2, w2 = wig * s;
        stroke(g, [[o, 25], [o + s * 2.4 * k + w2, 28.4], [o + s * 4.8 * k, 29.3], [o + s * 6.6 * k, 27.8], [o + s * 6 * k - w2 * 0.5, 25.8]], 1.8, 0.9, R[1]);
        stroke(g, [[n, 27], [n + s * 0.8 - w2 * 0.6, 29.4], [n + s * 2.6 * k, 29.6], [n + s * 3.4 * k, 28.4]], 1.7, 0.9, R[1]);
      }
    } else {
      const fl = P.walk && P.frame ? -1 : 0, fr = P.walk && !P.frame ? -1 : 0, fc = L.pattern === 'socks' ? pc2 : R[2];
      if (skin === 'ghost') { const wv = P.frame ? 0.5 : 0; for (const [x, dy2] of [[10.4, wv], [16, -wv], [21.6, wv]]) g.ell(x, 28.4 + dy2, 2.4, 1.9, R); }
      else { g.ell(12.4, 29.2 + fl, 2.8, 1.8, fc); g.ell(19.6, 29.2 + fr, 2.8, 1.8, fc); }
    }
    // body
    const bodyMask = new Set(), bodyIdx = new Uint8Array(32 * 32);
    g.ell(16, 22, 8.3, 7.7, R, 0, (x, y) => { bodyMask.add(x + ',' + y); if (x >= 0 && y >= 0 && x < 32 && y < 32) bodyIdx[y * 32 + x] = 1; return true; });
    // pattern on body
    const onBody = (x, y) => bodyMask.has(x + ',' + y);
    const pc = L.patternColor;
    if (L.pattern === 'spots') g.px([[10, 16], [11, 16], [10, 17], [21, 17], [21, 18], [20, 17], [9, 24], [22, 24], [22, 25], [13, 15], [18, 14]].filter(([x, y]) => onBody(x, y)), pc);
    if (L.pattern === 'stripes') g.px([[12, 15], [12, 16], [15, 14], [16, 14], [15, 15], [16, 15], [19, 15], [19, 16], [9, 18], [22, 18]].filter(([x, y]) => onBody(x, y)), pc);
    if (L.pattern === 'twotone' && !skin) for (const k of bodyMask) { const [x, y] = k.split(',').map(Number); if (y <= 18) g.set(x, y, pc); }
    if (L.pattern === 'mask') for (const k of bodyMask) { const [x, y] = k.split(',').map(Number); if (y >= 19 && y <= 21 && x >= 10 && x <= 21) g.set(x, y, pc); }
    if (L.pattern === 'freckles') g.px([[8, 21], [9, 20], [10, 21], [23, 21], [22, 20], [21, 21], [9, 23], [22, 23]].filter(([x, y]) => onBody(x, y)), pc2);
    // newer stickers: in the pattern colour, or a deeper body tone when that colour would vanish on a pale body
    const newPat = Object.prototype.hasOwnProperty.call(PAT_PTS, L.pattern) ? L.pattern : null;
    const pcN = newPat ? patternInk(newPat === 'moonmark' && pc2 === BELLY ? '#fff27a' : pc2, skin ? (SKIN_TONE[skin] || [])[0] : R[1], skin ? (SKIN_TONE[skin] || [])[1] : R[2]) : null;
    if (newPat) g.px(PAT_PTS[newPat].filter(([x, y]) => onBody(x, y)), pcN);
    // belly (ember skin: warm cream dragon belly)
    const bellyCol = skin && skin in SKIN_BELLY ? SKIN_BELLY[skin] : (L.belly || BELLY);
    if (bellyCol) g.ell(16, 26, 4.8, 2.9, bellyCol, 0, onBody);
    if (skin === 'ember') for (let y = 23; y < 30; y += 2) for (let x = 10; x < 22; x++) if (g.get(x, y) === bellyCol) g.set(x, y, '#f6d68a');
    // soft shading under the belly (dithered one row up) and a glossy highlight on the head
    if (bellyCol) {
      const isB = (x, y) => { const c = g.get(x, y); return c === bellyCol || c === '#f6d68a'; };
      const bsh = mixHex(bellyCol, skin ? (SKIN_BELLY_SHADE[skin] || '#b08a60') : R[2], 0.28), bpts = [];
      for (let y = 23; y < 30; y++) for (let x = 10; x < 22; x++) if (isB(x, y) && (!isB(x, y + 1) || (!isB(x, y + 2) && (x + y) & 1) || (!isB(x + 1, y) && x > 18))) bpts.push([x, y]);
      g.px(bpts, bsh);
      if (!skin) g.px([[11, 16], [12, 16], [10, 17]].filter(([x, y]) => g.get(x, y) === R[0]), mixHex(R[0], '#ffffff', 0.55));
    }
    if (L.pattern === 'star') g.px([[15, 25], [16, 25], [15, 26], [16, 26], [14, 26], [17, 26], [15, 24], [16, 24], [15, 27], [16, 27]], pc === BELLY ? '#f6c83a' : pc);
    if (L.pattern === 'heart') g.px([[13, 25], [14, 25], [17, 25], [18, 25], [13, 26], [14, 26], [15, 26], [16, 26], [17, 26], [18, 26], [14, 27], [15, 27], [16, 27], [17, 27], [15, 28], [16, 28]].filter(([x, y]) => onBody(x, y)), pc2 === (L.belly || BELLY) || pc2 === BELLY ? '#e8608a' : pc2);
    // front fluff tufts
    if (pt.fluff > 0) { const k = sz(pt.fluff); for (const s of [-1, 1]) { g.ell(16 + s * 7.4, 27.2, 2.3 * k, 1.9 * k, RAMPS.cloud); g.ell(16 + s * 6.6, 15.8, 1.8 * k, 1.5 * k, RAMPS.cloud); } }
    // arms (or pincers)
    let arms = P.arms || 'down';
    if (arms === 'paddle') arms = P.frame ? 'up' : 'out';
    let hands;
    if (arms === 'up') { g.ell(7.4, 17.6, 1.7, 2.8, R, 0.45); g.ell(24.6, 17.6, 1.7, 2.8, R, -0.45); hands = [6, 15, -0.35, -1]; }
    else if (arms === 'out') { g.ell(6.4, 21.2, 2.8, 1.7, R); g.ell(25.6, 21.2, 2.8, 1.7, R); hands = [4, 20.4, -1, -0.45]; }
    else if (arms === 'hold') { g.ell(10, 23.5, 2, 1.7, R); g.ell(22, 23.5, 2, 1.7, R); hands = [9.6, 23, -0.2, -1]; }
    else { const s = P.walk ? (P.frame ? 0.5 : -0.5) : 0; g.ell(7.9, 23 + s, 1.8, 2.6, R); g.ell(24.1, 23 - s, 1.8, 2.6, R); hands = [6.4, 24.2 + s, -0.6, -0.8]; }
    if (pt.claws > 0) {
      const k = sz(pt.claws), C = new Grid(32, 32);
      for (const s of [-1, 1]) {
        const cx = s < 0 ? hands[0] : 32 - hands[0], cy = hands[1], dy = hands[3];
        const ddx = s < 0 ? hands[2] : -hands[2], n = Math.hypot(ddx, dy), ux = ddx / n, uy = dy / n, px = -uy, py = ux, r = 2.7 * k;
        C.ell(cx, cy, r, r * 0.92, RAMP_X.crab);
        C.poly([[cx + ux * 0.1, cy + uy * 0.1], [cx + ux * 3.8 * k + px * 1.9 * k, cy + uy * 3.8 * k + py * 1.9 * k], [cx + ux * 3.8 * k - px * 1.2 * k, cy + uy * 3.8 * k - py * 1.2 * k]], null);
      }
      g.merge(C);
    }
    // mushroom cap on the head (hats cover it; leaves, buds and blooms poke up through it)
    const capOn = pt.mushcap > 0 && (!L.hat || L.hat === 'none');
    if (capOn) { const k = sz(pt.mushcap); piece(g, t => t.ell(16, 15.6, 5.6 * k + 0.8, 4.6 * k, ['#ff9aa0', '#e8404a', '#a02c3a'], 0, (x, y) => y <= 15)); }
    // sprout / bud / bloom
    if (!hatHidesLeaves && L.bloom) {
      g.rect(15, 11, 2, 4, '#37946e');
      g.ell(13, 13.4, 2.1, 1, RAMPS.leaf, 0.45); g.ell(19, 13.4, 2.1, 1, RAMPS.leaf, -0.45);
      flowerArt(g, L.bloom, 16, 6.5);
    } else if (!hatHidesLeaves && L.bud) {
      const BR = BUD_RAMP[L.bud] || BUD_RAMP.wild;
      g.rect(15, 10, 2, 5, '#37946e');
      g.ell(12.9, 12.9, 2.3, 1.1, LR, 0.45); g.ell(19.1, 12.9, 2.3, 1.1, LR, -0.45);
      g.ell(16, 6.8, 2.9, 3.4, BR); g.poly([[13.7, 6], [18.3, 6], [16, 1.6]], BR[1]); g.ell(16, 6.8, 2.9, 3.4, BR, 0, (x, y) => y >= 5);
      g.poly([[12.8, 7.6], [14.4, 9.8], [16, 8.6], [17.6, 9.8], [19.2, 7.6], [18.2, 10.8], [13.8, 10.8]], '#6abe30');
    } else if (!hatHidesLeaves) {
      g.rect(15, 12, 2, 3, skin === 'pumpkin' ? '#7a4a2a' : LR[2]);
      g.ell(12.6, 11.4, 3.1, 1.6, LR, 0.42); g.ell(19.4, 11.4, 3.1, 1.6, LR, -0.42);
    }
    // unicorn horn (front)
    let horn = null;
    if (pt.unihorn > 0) { const k = sz(pt.unihorn); horn = new Grid(32, 32); horn.poly([[14, 17.8], [18, 17.8], [16.4, 17.8 - 10.5 * k]], '#fff8fc'); }
    const behind = under(g, B);
    g.outline();
    // ---------- details after outline ----------
    const onlyB = (x, y) => behind.has(y * 32 + x);
    if (pt.dragonwings > 0) { const k = sz(pt.dragonwings); const tx = Math.floor(9.5 - 6 * Math.min(k, 1)), ty = Math.floor(17.5 - 12.6 * k * 0.95 + flap); for (const X of [tx, 31 - tx]) if (g.get(X, ty - 1) === INK) g.set(X, ty - 1, '#fbf3dc'); }
    if (pt.fairywings > 0) {
      for (const i of behind) { const x = i % 32, y = (i / 32) | 0; if (g.get(x - 1, y) === INK || g.get(x + 1, y) === INK || g.get(x, y - 1) === INK || g.get(x, y + 1) === INK) g.set(x, y, '#c4b0f0'); }
      const k = sz(pt.fairywings);
      for (const s of [-1, 1]) { g.set(Math.floor(16 + s * (6.6 + 3.3 * k)), Math.floor(15.5 - 2.2 * k), '#f7b6c8'); g.set(Math.floor(16 + s * (6.8 + 2.6 * k)), 22, '#f7b6c8'); }
    }
    if (pt.flamewings > 0) for (const i of behind) { const x = i % 32, y = (i / 32) | 0; const c = g.get(x, y); if ((c === '#df7126' || c === '#f6c83a') && (x + y * 2) % 5 === 0) g.set(x, y, '#fff27a'); }
    if (pt.multitail > 0) { const km = Math.min(sz(pt.multitail), 1); for (const i of behind) { const x = i % 32, y = (i / 32) | 0; const c = g.get(x, y); if (!RAMP_X.cream.includes(c)) continue; const d = Math.hypot(x + 0.5 - 19.5, y + 0.5 - 25); if (d > 8.4 * km) g.set(x, y, d > 9.8 * km ? '#df7126' : '#f6a83a'); } }
    if (pt.spikes > 0) for (const i of behind) { const x = i % 32, y = (i / 32) | 0; const c = g.get(x, y); if (c === R[2] && Math.hypot(x + 0.5 - 16, (y + 0.5 - 22) * 1.08) > 10.4 && (x + y) % 2) g.set(x, y, R[1]); }
    if (pt.ears > 0) { const k = sz(pt.ears); g.ell(10.4 - k, 13.6 - 1.2 * k, 0.7, 3.2 * k, L.cheek, -0.42, (x, y) => g.filled(x, y)); g.ell(21.6 + k, 13.6 - 1.2 * k, 0.7, 3.2 * k, L.cheek, 0.42, (x, y) => g.filled(x, y)); }
    if (pt.shell > 0) g.px([[7, 20], [7, 21], [24, 20], [24, 21], [8, 27], [23, 27]].filter(([x, y]) => g.filled(x, y) && !onBody(x, y)), '#4b692f');
    if (LEAFE) { const [ex2, ey2, el] = LEAFE; const m = (x, y) => LR.includes(g.get(x, y)); g.ell(ex2, ey2, 0.5, el - 1, LR[2], -0.78, m); g.ell(32 - ex2, ey2, 0.5, el - 1, LR[2], 0.78, m); }
    if (capOn) { const CAPC = ['#ff9aa0', '#e8404a', '#a02c3a']; g.px([[12, 13], [13, 13], [16, 11], [17, 11], [16, 12], [20, 13], [19, 14], [11, 14]].filter(([x, y]) => CAPC.includes(g.get(x, y))), '#ffffff'); }
    if (pt.thorns > 0) for (const i of behind) { const x = i % 32, y = (i / 32) | 0; if (g.get(x, y) === '#b8804a' && Math.hypot(x + 0.5 - 16, (y + 0.5 - 22) * 1.07) > 9.3) g.set(x, y, '#f0d8a8'); }
    if (pt.vines > 0) { // curly vines winding down both sides
      const k = sz(pt.vines), VN = '#3f8a3a', VL = '#8ee06a';
      for (const s2 of [-1, 1]) for (let i = 0; i <= 26; i++) {
        const u = i / 26, y = Math.round(15.5 + u * 12 * Math.min(1, k + 0.1)), x = Math.round(16 + s2 * (7.6 + Math.sin(u * 8 + (s2 > 0 ? 1.5 : 0)) * 1.2));
        if (g.filled(x, y) && g.get(x, y) !== L.cheek) g.set(x, y, VN);
        if (i % 7 === 3) { const lx = x + s2, ly = y - 1; if (g.filled(lx, ly)) g.set(lx, ly, VL); }
      }
    }
    if (pt.antennae > 0) { const k = sz(pt.antennae); const tx = Math.round(11 - 3.2 * k), ty = Math.round(15 - 6 * k) + 1; line(g, 11, 15, tx + 1, ty, INK); line(g, 20, 15, 32 - tx - 2, ty, INK); g.set(Math.floor(11 - 3.2 * k - 0.6), Math.floor(15 - 6 * k - 0.6), '#ffffff'); g.set(Math.floor(21 + 3.2 * k - 0.6), Math.floor(15 - 6 * k - 0.6), '#ffffff'); }
    if (tent) { const k = sz(pt.tentacles); for (const s of [-1, 1]) for (const [x, y] of [[16 + s * (5.5 + 3.4 * k), 29], [16 + s * (5.5 + 5.6 * k), 28], [16 + s * (2.2 + 1.6 * k), 30]]) { const X = Math.floor(x), Y = Math.floor(y); if (g.filled(X, Y) && !onBody(X, Y)) g.set(X, Y, L.belly || BELLY); } }
    if (pt.claws > 0) { const s0 = hands; const cx = Math.floor(s0[0] - 1), cy = Math.floor(s0[1] - 1); if (g.filled(cx, cy)) g.set(cx, cy, '#ffc8b0'); if (g.filled(31 - cx, cy)) g.set(31 - cx, cy, '#ffc8b0'); }
    if (horn) {
      for (let y = 0; y < 32; y++) for (let x = 0; x < 32; x++) if (horn.get(x, y)) { if ((x + y) % 3 === 0) horn.set(x, y, '#e2b8f0'); else if ((x + y) % 3 === 1 && x >= 16) horn.set(x, y, '#f7d0e4'); }
      horn.outline(); g.merge(horn);
    }
    if (!hatHidesLeaves && L.bloom) flowerDetail(g, L.bloom, 16, 6.5);
    else if (!hatHidesLeaves && L.bud) {
      const BR = BUD_RAMP[L.bud] || BUD_RAMP.wild;
      g.px([[16, 4], [16, 5], [16, 6], [15, 7]].filter(([x, y]) => g.filled(x, y)), BR[2]); g.px([[14, 5], [14, 6]].filter(([x, y]) => g.filled(x, y)), BR[0]);
      if (L.bud === 'wild') g.px([[15, 2], [16, 2], [15, 3], [16, 3], [15, 4], [17, 4]].filter(([x, y]) => g.filled(x, y)), '#e07ba0');
      if (L.bud === 'moon') g.px([[19, 3], [12, 5]], '#dcd0ff');
      if (L.bud === 'sun') g.px([[19, 3], [12, 5]], '#fff27a');
    }
    else if (!hatHidesLeaves) { g.px([[12, 11], [13, 11]].filter(([x, y]) => g.filled(x, y)), LR[2]); g.px([[18, 11], [19, 11]].filter(([x, y]) => g.filled(x, y)), LR[2]); g.px([[11, 10], [20, 10]].filter(([x, y]) => g.filled(x, y)), mixHex(LR[0], '#ffffff', 0.4)); }
    void onlyB;
    // socks: shade the sole of each foot
    if (L.pattern === 'socks' && !tent) { const sd = mixHex(pc2, INK, 0.3); for (let y = 26; y < 32; y++) for (let x = 8; x < 24; x++) if (g.get(x, y) === pc2 && !onBody(x, y) && g.get(x, y + 1) === INK) g.set(x, y, sd); }
    // soft volume (PX.RIM): found on body-ramp (or skin-sentinel) pixels, painted once the body's final colours are known
    const rim = RIM ? rimPixels(g, bodyIdx, R) : null;
    if (rim && !skin) for (const [x, y, t, s] of rim) g.set(x, y, rimColor(null, t, s, R));
    // special skin: repaint every sentinel (body-ramp) pixel
    if (skin) applySkin(g, skin, 16, 22, 1, RAMPS[L.body] || RAMPS.mint);
    if (rim && skin) for (const [x, y, t, s] of rim) if (!(skin === 'ghost' && y >= 26)) g.set(x, y, rimColor(g.get(x, y), t, s, null));
    // shiny (L.shiny === true): a soft lighter diagonal band high on the right of the head and two tiny white glints.
    // Recolours body pixels only (never the outline), so the silhouette stays the same; skinned bodies just get the glints.
    if (L.shiny === true) {
      if (!skin) for (const [x, y] of SHINY_BAND) { if (!onBody(x, y)) continue; const t = R.indexOf(g.get(x, y)); if (t >= 0) g.set(x, y, t === 0 ? mixHex(R[0], '#ffffff', 0.5) : R[t - 1]); }
      for (const [x, y] of SHINY_GLINTS) if (onBody(x, y) && g.filled(x, y)) g.set(x, y, '#ffffff');
    }
    // face
    let eyes = P.eyes || L.eyes;
    const k = INK, w = '#ffffff', eyeShine = mixHex(L.eyeColor || '#5b6ee1', INK, 0.25);
    const eye = (x0, sd) => {
      const a = x0, b = x0 + 1;
      switch (eyes) {
        case 'happy': g.px([[a, 20], [b, 20]], k); g.px([[a - 1, 21], [b + 1, 21]], k); break;
        case 'closed': g.px([[a, 21], [b, 21]], k); g.px([[a - 1, 20], [b + 1, 20]], k); break;
        case 'blink': g.px([[a, 21], [b, 21]], k); break;
        case 'sleepy': g.px([[a, 20], [b, 20], [a, 21], [b, 21]], k); g.px([[a - 1, 20], [b + 1, 20]], k); break;
        case 'dot': g.px([[sd < 0 ? b : a, 20], [sd < 0 ? b : a, 21]], k); break;
        case 'sparkle': g.px([[a, 19], [b, 19], [a, 20], [b, 20]], k); g.px([[a, 21], [b, 21]], L.eyeColor || '#5b6ee1'); g.set(a, 19, w); g.set(b, 21, w); g.px([[a - 1, 20], [b + 1, 20]], k); break;
        // newer styles (hatched eye styles; pose eyes like happy/blink/closed/sad still replace them)
        case 'star': { // golden star-shaped eyes with an ink edge (3 wide, 4 tall), so they show on pale and yellow bodies too
          const c = sd < 0 ? a : b;
          g.px([[c, 18], [c - 1, 19], [c + 1, 19], [c - 1, 21], [c + 1, 21]], k);
          g.set(c, 19, '#fbf236'); g.set(c, 20, '#fff6c8'); g.px([[c - 1, 20], [c + 1, 20]], '#f6c83a');
          break;
        }
        case 'wink': // left eye open, right eye closed in a happy arch
          if (sd > 0) { g.px([[a, 20], [b, 20]], k); g.px([[a - 1, 21], [b + 1, 21]], k); }
          else { g.px([[a, 19], [b, 19], [a, 20], [b, 20], [a, 21], [b, 21]], k); g.set(a, 19, w); g.set(b, 21, eyeShine); }
          break;
        case 'big': { // bigger shiny eyes: 3 wide, 4 tall, soft outer corners
          const o = sd < 0 ? a - 1 : b + 1;
          g.px([[a, 18], [b, 18], [a, 19], [b, 19], [a, 20], [b, 20], [a, 21], [b, 21], [o, 19], [o, 20]], k);
          g.set(a, 19, w); g.set(a, 21, L.eyeColor || '#5b6ee1'); g.set(b, 21, eyeShine);
          break;
        }
        default:
          g.px([[a, 19], [b, 19], [a, 20], [b, 20], [a, 21], [b, 21]], k); g.set(a, 19, w); g.set(b, 21, eyeShine);
          if (eyes === 'brave') { if (sd < 0) g.px([[a - 1, 17], [a, 17], [b, 18]], k); else g.px([[b + 1, 17], [b, 17], [a, 18]], k); }
          if (eyes === 'sad') { if (sd < 0) g.px([[a - 1, 18], [a, 17], [b, 17]], k); else g.px([[b + 1, 18], [b, 17], [a, 17]], k); }
      }
    };
    // Dark bodies (night, plum, cocoa…) swallow ink eyes: give them pale eye patches and a muzzle so the face reads.
    const bodyMid = ((RAMPS[L.body] || RAMPS.mint)[1]).slice(1), lum = (parseInt(bodyMid.slice(0, 2), 16) * 0.3 + parseInt(bodyMid.slice(2, 4), 16) * 0.59 + parseInt(bodyMid.slice(4, 6), 16) * 0.11) / 255;
    if ((!skin && lum < 0.42) || (skin && SKIN_DARK[skin])) {
      const pale = '#e8ecff', onFace = (x, y) => g.filled(x, y);
      for (const x0 of [12, 18]) for (let y = 18; y <= 22; y++) for (let x = x0 - 1; x <= x0 + 2; x++) {
        const corner = (y === 18 || y === 22) && (x === x0 - 1 || x === x0 + 2);
        if (!corner && onFace(x, y)) g.set(x, y, pale);
      }
      g.ell(16, 23, 2.6, 1.3, pale, 0, onFace);
    }
    eye(12, -1); eye(18, 1);
    g.px([[10, 22], [11, 22]], L.cheek); g.px([[20, 22], [21, 22]], L.cheek);
    switch (P.mouth || 'smile') {
      case 'open': g.px([[14, 22], [17, 22], [15, 23], [16, 23]], k); g.px([[15, 22], [16, 22]], '#d95763'); break;
      case 'o': g.px([[15, 22], [16, 22], [15, 23], [16, 23]], k); break;
      case 'flat': g.px([[15, 23], [16, 23]], k); break;
      case 'grin': g.px([[14, 22], [15, 23], [16, 23], [17, 22]], k); g.px([[15, 22], [16, 22]], w); break;
      default: g.px([[14, 22], [15, 23], [16, 23], [17, 22]], k);
    }
    if (skin === 'vampire' && (P.mouth || 'smile') !== 'o' && (P.mouth || 'smile') !== 'flat') g.px([[14, 23], [17, 23]], '#ffffff');
    if (skin === 'ghost') { // a see-through, wispy lower half
      const pale = new Set(GHOST.concat(['#ffffff']));
      for (let y = 26; y < 32; y++) for (let x = 0; x < 32; x++) {
        const c = g.get(x, y); if (!c) continue;
        const a = y >= 28 ? 0.62 : 0.82;
        if (pale.has(c)) { const [r, gg, b] = [1, 3, 5].map(i => parseInt(c.slice(i, i + 2), 16)); g.set(x, y, `rgba(${r},${gg},${b},${(x + y) & 1 ? a : a + 0.12})`); }
        else if (c === INK) g.set(x, y, `rgba(110,92,170,${y >= 28 ? 0.55 : 0.85})`);
      }
    }
    // hat & extras on their own outlined layer
    const h = new Grid(32, 32);
    const crowned = !hatHidesLeaves && (L.bloom || L.bud);
    hatArt(h, L.hat, crowned, L.bloom);
    extraArt(h, L.extra, crowned);
    h.outline(); g.merge(h);
    return g;
  }
  const cache = new Map();
  function sprig(L, P) {
    const key = JSON.stringify(L) + '|' + JSON.stringify(P || {});
    let c = cache.get(key);
    if (!c) {
      const k0 = Grid.K; Grid.K = 1;
      try { c = buildSprig(L, P).canvas(); } catch (e) { console.error('PX.sprig', e); c = buildSprig(DEFAULT_LOOK, {}).canvas(); } finally { Grid.K = k0; }
      cache.set(key, c); if (cache.size > 600) cache.delete(cache.keys().next().value);
    }
    return c;
  }
  // canvas is SPRIG_W x SPRIG_H (32x32); anchor: feet bottom at (16, 31)
  const SPRIG_W = 32, SPRIG_H = 32, SPRIG_AX = 16, SPRIG_AY = 31;

  // ---------------- Chibi kit for the world art below (World G) ----------------
  // Round chunky shapes, flat pastel fills with ONE soft shade crescent on the lower right and a small highlight up-left, a
  // 1-fine-pixel piece outline plus a bold outer ring (g.outerLine()). Faces use PX.art.chibiEyes / blush / chibiMouth
  // (art-core.js, looked up when drawing). See docs/chibi-reference.js.
  const kFlat = R => [R[1], R[1], R[2]];
  const kIN = g => { const m = (x, y) => g.filled(x, y); m.fine = true; return m; };
  // the crescent shade for ANY silhouette on t: filled pixels outside the ellipse nudged up-left become R[2]
  function kShade(t, cx, cy, rx, ry, R, o) {
    o = o || {}; const k = o.shade == null ? 0.16 : o.shade, K = t.k || 1, sx = cx - rx * k, sy = cy - ry * k * 1.15;
    for (let fy = 0; fy < t.fh; fy++) for (let fx = 0; fx < t.fw; fx++) {
      const i = fy * t.fw + fx, c = t.a[i]; if (!c || c === INK || (o.only && c !== o.only)) continue;
      if (!inEll((fx + 0.5) / K, (fy + 0.5) / K, sx, sy, rx * 1.02, ry * 1.02, o.rot || 0).in) t.a[i] = R[2];
    }
    if (o.hl !== false) t.ell(cx - rx * 0.42, cy - ry * 0.5, Math.max(0.6, rx * 0.22), Math.max(0.45, ry * 0.13), R[0], -0.55, kIN(t));
    return t;
  }
  // a soft body: one ellipse with the crescent shade
  const kSoft = (t, cx, cy, rx, ry, R, o) => { t.ell(cx, cy, rx, ry, R[1], (o && o.rot) || 0, o && o.mask); return kShade(t, cx, cy, rx, ry, R, o); };
  function kRect(t, x0, y0, x1, y1, r, col) {
    const pts = [], arc = (cx, cy, a0) => { for (let i = 0; i <= 6; i++) { const a = a0 + i * Math.PI / 12; pts.push([cx + Math.cos(a) * r, cy + Math.sin(a) * r]); } };
    arc(x1 - r, y0 + r, -Math.PI / 2); arc(x1 - r, y1 - r, 0); arc(x0 + r, y1 - r, Math.PI / 2); arc(x0 + r, y0 + r, Math.PI);
    return t.poly(pts, col);
  }
  function kDrop(t, cx, cy, rx, ry, tipH, lean, col) {
    const Dd = ry + tipH, c = Math.min(0.95, ry / Dd), s = Math.sqrt(1 - c * c);
    t.ell(cx, cy, rx, ry, col);
    if (tipH > 0) t.poly([[cx + lean, cy - Dd], [cx + rx * s + 0.05, cy - ry * c], [cx, cy + 0.5], [cx - rx * s - 0.05, cy - ry * c]], col);
  }
  // a 4-point twinkle in fine pixels, only on empty pixels
  function kTw(g, x, y, c, big) {
    const put = (a, b, col) => { const fx = Math.floor((x + a) * g.k), fy = Math.floor((y + b) * g.k); if (!g.fget(fx, fy)) g.fset(fx, fy, col); };
    put(0, 0, '#ffffff'); for (const [a, b] of [[0.5, 0], [-0.5, 0], [0, 0.5], [0, -0.5]]) put(a, b, c);
    if (big) for (const [a, b] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) put(a, b, c);
  }
  const kArt = () => (window.PX && PX.art) || {};
  // chibi face: big glossy eyes, blush, tiny mouth (s = head radius; o: sp, w, h, mood, mouth, mw, one, col, by)
  function kFace(g, cx, cy, s, o) {
    o = o || {}; const A = kArt();
    if (A.chibiEyes) A.chibiEyes(g, cx, cy, { sp: o.sp || s * 0.86, w: o.w || Math.max(1.8, s * 0.48), h: o.h || Math.max(2.4, s * 0.64), mood: o.mood, col: o.col, one: o.one, white: o.white, look: o.look });
    if (o.blush !== false && A.blush) A.blush(g, cx + (o.bx || 0), cy + (o.by || s * 0.42), { sp: o.bsp || s * 1.04, w: o.bw || Math.max(0.8, s * 0.2), h: 0.55, one: o.one, col: o.blushCol });
    if (o.mouth !== null && A.chibiMouth) A.chibiMouth(g, cx + (o.mx || 0.1), cy + (o.my || s * 0.52), o.mouth || 'smile', o.mw || Math.max(1.3, s * 0.3));
  }

  // ---------------- Emote bubbles (13 x 13: a round speech bubble with a pastel icon) ----------------
  const EMO = {
    heart(t) { t.ell(5.3, 4.5, 1.6, 1.5, '#ff9ab4'); t.ell(7.7, 4.5, 1.6, 1.5, '#ff9ab4'); t.poly([[3.8, 5], [9.2, 5], [6.5, 8.2]], '#ff9ab4'); },
    '!'(t) { kRect(t, 5.6, 2.2, 7.4, 6.4, 0.9, '#ff9a7a'); t.ell(6.5, 8, 0.95, 0.95, '#ff9a7a'); },
    '?'(t) { stroke(t, [[4.8, 3.8], [5.4, 2.6], [6.8, 2.3], [8, 3.2], [7.8, 4.6], [6.6, 5.4], [6.5, 6.4]], 0.62, 0.62, '#86b8f0'); t.ell(6.5, 8.1, 0.9, 0.9, '#86b8f0'); },
    note(t) { t.ell(5.2, 7.2, 1.4, 1.1, '#b48ee8', -0.3); kRect(t, 6, 2.2, 6.9, 7.2, 0.4, '#b48ee8'); t.poly([[6.4, 2.2], [8.6, 3.2], [8.4, 4.6], [6.6, 3.8]], '#b48ee8'); },
    zz(t) { stroke(t, [[3.6, 3], [6, 3], [3.6, 6], [6, 6]], 0.5, 0.5, '#86b8f0'); stroke(t, [[7.2, 5], [9.2, 5], [7.2, 7.6], [9.2, 7.6]], 0.42, 0.42, '#a8cdf6'); },
    swirl(t) { const pts = []; for (let i = 0; i <= 22; i++) { const a = i * 0.55, r = 0.4 + i * 0.13; pts.push([6.5 + Math.cos(a) * r, 5.2 + Math.sin(a) * r]); } stroke(t, pts, 0.45, 0.45, '#ff9a9a'); },
    sparkle(t) { t.poly(starPts(6.5, 5.2, 3.5, 1.5, 4), '#ffd866'); t.ell(6.5, 5.2, 1.3, 1.3, '#ffd866'); },
    munch(t) { t.ell(6.5, 5.6, 3, 2.4, '#ff9aa6', 0, (x, y) => y >= 4.4); kRect(t, 3.5, 3.6, 9.5, 4.8, 0.5, '#ff9aa6'); t.ell(6.5, 6.4, 1.6, 0.9, '#ffd0d8'); },
  };
  const emoteCache = {};
  function emote(kind) {
    if (emoteCache[kind]) return emoteCache[kind];
    const g = new Grid(13, 13);
    piece(g, t => { kRect(t, 1.4, 1.2, 11.6, 9.4, 3.2, '#ffffff'); t.poly([[4.2, 8.6], [7, 8.6], [4.4, 11.4]], '#ffffff'); kShade(t, 6.5, 5.6, 5.4, 4.6, ['#ffffff', '#ffffff', '#eae6f2'], { hl: false }); });
    const ic = new Grid(13, 13); (EMO[kind] || EMO['!'])(ic);
    for (let i = 0; i < g.a.length; i++) if (ic.a[i] && g.a[i] && g.a[i] !== INK) g.a[i] = ic.a[i];
    g.outerLine();
    return (emoteCache[kind] = g.canvas());
  }

  // ---------------- Critters ----------------
  // Regular animals: 18x18. Rares: 26x26. Facing right; feet/ground on the bottom row. Anchor bottom-centre.
  const critterCache = {};
  const MK = g => (x, y) => g.filled(x, y);
  // Chibi animals: a big round head on a tiny body, big glossy eyes and blush (regular 18x18, rares 26x26, facing right).
  // Built from shared body plans so each kind only says what makes it itself (ears, tail, colours, beak, fins...).
  const PINK_IN = '#ffc4d4';
  // a land animal: tail (behind), tiny feet, an egg body, ears (behind the head), a big head, face, extras on top
  function beast(g, o) {
    const R = o.R, hd = o.head || [10.6, 8.2, 5.3, 4.9], bd = o.body || [7.4, 13.2, 4.4, 3.3], F = o.F || R;
    if (o.tail) piece(g, t => o.tail(t, R));
    if (o.feet !== false) piece(g, t => { t.ell(bd[0] - 1.8, 16, 1.4, 0.95, kFlat(F)); t.ell(bd[0] + 2.2, 16.1, 1.4, 0.95, kFlat(F)); });
    piece(g, t => { kSoft(t, bd[0], bd[1], bd[2], bd[3], R, { hl: false }); if (o.belly) t.ell(bd[0] + 1, bd[1] + 0.5, bd[2] * 0.55, bd[3] * 0.62, o.belly, 0, kIN(t)); });
    if (o.ears) piece(g, t => o.ears(t, R, hd));
    if (o.earsIn) o.earsIn(g, hd);
    piece(g, t => kSoft(t, hd[0], hd[1], hd[2], hd[3], R, { rot: o.rot || 0 }));
    if (o.muzzle) g.ell(hd[0] + 1.6, hd[1] + 2.2, 2.4, 1.6, o.muzzle, 0, kIN(g));
    if (o.mark) o.mark(g, hd);
    kFace(g, hd[0] + 1.1, hd[1] + 0.9, hd[2], Object.assign({ mouth: 'cat', mw: 1.3 }, o.face));
    if (o.front) o.front(g, R, hd);
    g.outerLine();
  }
  const roundEars = (r, inC) => (t, R, h) => { for (const [dx, dy] of [[-3.2, -3.8], [2.6, -4.2]]) t.ell(h[0] + dx, h[1] + dy, r, r, kFlat(R)); if (inC) for (const [dx, dy] of [[-3.2, -3.8], [2.6, -4.2]]) t.ell(h[0] + dx, h[1] + dy, r * 0.5, r * 0.5, inC); };
  const pointEars = (inC, tall) => (t, R, h) => { const H2 = tall || 4.4; for (const [dx, lean] of [[-2.6, -0.8], [2.4, 0.6]]) { t.poly([[h[0] + dx - 1.9, h[1] - 2.6], [h[0] + dx + lean, h[1] - 2.8 - H2], [h[0] + dx + 1.9, h[1] - 3]], R[1]); if (inC) t.poly([[h[0] + dx - 0.8, h[1] - 3], [h[0] + dx + lean * 0.8, h[1] - 2.8 - H2 * 0.62], [h[0] + dx + 0.8, h[1] - 3.2]], inC); } };
  const longEars = inC => (t, R, h) => { for (const [dx, rot] of [[-1.6, -0.22], [1.8, 0.3]]) { t.ell(h[0] + dx, h[1] - 6.2, 1.4, 3.6, R[1], rot); t.ell(h[0] + dx, h[1] - 6, 0.6, 2.6, inC, rot); } };
  const fluffTail = (x, y, r, tip) => (t, R) => { t.ell(x, y, r * 0.85, r, R[1], -0.6); if (tip) t.ell(x - r * 0.3, y - r * 0.55, r * 0.5, r * 0.45, tip, -0.6); };
  // a round chubby bird: a body-and-head blob, a belly, a wing, a beak, a little tail and stick feet
  function birdie(g, o) {
    const R = o.R, cx = o.cx || 9, cy = o.cy || 10.4, rx = o.rx || 6, ry = o.ry || 5.4;
    piece(g, t => t.poly([[cx - rx + 1.2, cy + 0.6], [cx - rx - 2.2, cy - 1.6], [cx - rx - 1.6, cy + 2.6]], R[2]));
    piece(g, t => { stroke(t, [[cx - 1.4, cy + ry - 0.6], [cx - 1.6, 16.6]], 0.36, 0.36, o.legs || '#f6b47a'); stroke(t, [[cx + 1.4, cy + ry - 0.6], [cx + 1.6, 16.6]], 0.36, 0.36, o.legs || '#f6b47a'); });
    if (o.back) piece(g, t => o.back(t, R));
    piece(g, t => { kSoft(t, cx, cy, rx, ry, R); if (o.belly) t.ell(cx + 1, cy + 2, rx * 0.6, ry * 0.5, o.belly, 0, kIN(t)); });
    piece(g, t => t.ell(cx - 2, cy + 1.2, 2.6, 1.7, kFlat([R[1], R[2], mixHex(R[2], INK, 0.12)]), 0.35));
    piece(g, t => { const b = o.beak || ['#ffd27a']; t.poly([[cx + rx - 0.8, cy - 1.4], [cx + rx + (o.beakLen || 2.4), cy - 0.2], [cx + rx - 0.8, cy + 0.9]], b[0]); });
    if (o.front) o.front(g, R);
    kFace(g, cx + 1.4, cy - 1.2, 4.6, Object.assign({ mouth: null }, o.face));
    g.outerLine();
  }
  // a fish: tail fin, top fin, an oval body, a side fin, a face
  function fishy(g, o) {
    const R = o.R, F = o.F || [R[0], mixHex(R[1], R[2], 0.5), R[2]], cx = o.cx || 9.6, cy = o.cy || 9.6, rx = o.rx || 5.8, ry = o.ry || 4.6;
    piece(g, t => { t.poly([[cx - rx + 1.4, cy], [cx - rx - 3, cy - 3.4], [cx - rx - 2.2, cy], [cx - rx - 3, cy + 3.4]], F[1]); t.ell(cx - rx - 2.4, cy - 2.6, 1, 1, F[1]); t.ell(cx - rx - 2.4, cy + 2.6, 1, 1, F[1]); });
    if (o.topFin !== false) piece(g, t => t.poly([[cx - 2.4, cy - ry + 0.8], [cx - 0.6, cy - ry - 2], [cx + 1.8, cy - ry + 0.6]], F[1]));
    if (o.back) piece(g, t => o.back(t, R));
    piece(g, t => kSoft(t, cx, cy, rx, ry, R));
    if (o.mark) o.mark(g);
    piece(g, t => t.ell(cx - 1, cy + 1.8, 1.8, 1.1, kFlat(F), 0.5));
    kFace(g, cx + 1.4, cy - 0.2, Math.min(rx, ry + 0.6), Object.assign({ mouth: 'o', mw: 1.4 }, o.face));
    if (o.front) o.front(g, R);
    g.outerLine();
  }
  // a bug: wings behind, a round body, antennae, stripes
  function buggy(g, o) {
    const R = o.R, cx = o.cx || 9.6, cy = o.cy || 10.6, r = o.r || 4.8, WG = o.WG || ['#ffffff', '#eef8ff', '#cde4f4'];
    if (o.wings) o.wings(g, WG);
    else { piece(g, t => t.ell(cx - 3, cy - 4.4, 1.9, 3, kFlat(WG), -0.5)); piece(g, t => t.ell(cx + 0.4, cy - 5, 1.7, 2.8, kFlat(WG), 0.2)); }
    if (o.tail) piece(g, t => o.tail(t, R));
    piece(g, t => { for (const dx of [1.4, 3.6]) stroke(t, [[cx + dx - 1.2, cy - r + 1], [cx + dx, cy - r - 2.2]], 0.3, 0.3, o.ant || '#a89cb8'); for (const dx of [1.4, 3.6]) t.ell(cx + dx + 0.2, cy - r - 2.4, 0.75, 0.75, o.antTip || R[1]); });
    piece(g, t => kSoft(t, cx, cy, r, r * 0.94, R));
    if (o.stripes) for (const x of o.stripes) { const m = (xx, yy) => g.filled(xx, yy) && Math.abs(xx - x) < 0.55; m.fine = true; g.ell(x, cy, 1, r, o.stripeCol, 0, m); }
    kFace(g, cx + 1, cy + 0.6, r, Object.assign({}, o.face));
    if (o.front) o.front(g, R);
    g.outerLine();
  }
  const C_BROWN = ['#fbe6d2', '#e2b48e', '#c8966e'], C_WHITE = ['#ffffff', '#f6f2f8', '#dcd4e4'], C_GREY = ['#f2f2fa', '#c8cadc', '#a6a8c2'];
  const CR = {
    // ----- meadow -----
    sparrow(g) { birdie(g, { R: C_BROWN, belly: '#fff2e2', beak: ['#ffd27a'] }); },
    hare(g) { beast(g, { R: C_WHITE, ears: longEars(PINK_IN), tail: fluffTail(2.8, 12.2, 1.6), face: { mouth: 'cat' } }); },
    ram(g) { // a fluffy wool cloud with a little peach face, curly horns and a wool tuft on top
      const WL = ['#ffffff', '#f6efe4', '#ddd0bc'], FC = ['#fff4ea', '#f8dcc6', '#e6c0a4'], HN = ['#fff0d8', '#eccb9a', '#d4ae7c'];
      piece(g, t => { t.ell(5.4, 16, 1.4, 0.95, kFlat(['#e2dcea', '#c4bcd2', '#a69eb6'])); t.ell(9.4, 16.1, 1.4, 0.95, kFlat(['#e2dcea', '#c4bcd2', '#a69eb6'])); });
      piece(g, t => { for (const [x, y, r] of [[3.4, 12, 2.4], [5.6, 10, 2.6], [8.4, 10.4, 2.4], [4.4, 14.4, 2.2], [7.6, 14.4, 2.4], [9.8, 13, 2.2]]) t.ell(x, y, r, r * 0.95, WL[1]); kShade(t, 6.6, 12.4, 5.6, 4.4, WL); });
      piece(g, t => { for (const x of [7.8, 15.6]) { t.ell(x, 8.4, 1.9, 1.9, HN[1]); } kShade(t, 11.6, 8.4, 6, 2, HN, { hl: false }); });
      for (const x of [7.8, 15.6]) g.ell(x, 8.4, 0.7, 0.7, HN[2], 0, kIN(g));
      piece(g, t => kSoft(t, 11.7, 9, 4.2, 4.1, FC));
      piece(g, t => { for (const [x, y, r] of [[10.4, 5.2, 1.5], [12, 4.6, 1.6], [13.5, 5.3, 1.3]]) t.ell(x, y, r, r, WL[1]); });
      kFace(g, 12.5, 9.6, 4.2, { sp: 3.2, w: 1.8, h: 2.4, mouth: 'cat', mw: 1.2 });
      g.outerLine();
    },
    tortoise(g) {
      const S = ['#e8f8d8', '#b4dc8c', '#94c46e'], SK = ['#f6fae2', '#d6e8a8', '#bcd48a'];
      piece(g, t => { t.ell(5, 15.6, 1.5, 1, kFlat(SK)); t.ell(10.4, 15.8, 1.5, 1, kFlat(SK)); });
      piece(g, t => { t.ell(2.6, 13.4, 1.2, 0.8, kFlat(SK), 0.5); t.ell(13.4, 11.4, 3.6, 3.2, SK[1]); kShade(t, 13.4, 11.4, 3.6, 3.2, SK); });
      piece(g, t => { t.ell(7.6, 12.4, 5.6, 4.6, S[1], 0, (x, y) => y <= 14); kRect(t, 2, 13, 13.2, 14.6, 0.7, '#f2e6c4'); kShade(t, 7.6, 11, 5.6, 4, S); });
      for (const [x, y] of [[5.4, 10.4], [8, 9.2], [9.8, 11.4], [6.6, 12.4]]) g.ell(x, y, 0.9, 0.7, S[0], 0, kIN(g));
      kFace(g, 14.2, 11.2, 3.2, { sp: 2.4, w: 1.3, h: 1.7, mouth: 'smile', mw: 1, bsp: 3.6, bw: 0.6 });
      g.outerLine();
    },
    fox(g) { beast(g, { R: ['#fff0e2', '#ffbe8e', '#f29e72'], belly: '#fff6ee', muzzle: '#fff6ee', ears: pointEars('#fff0e6'), tail: (t, R) => { t.ell(3.4, 11, 2.6, 3.8, R[1], -0.7); t.ell(1.9, 8.4, 1.5, 1.4, '#fff6ee', -0.7); } }); },
    bee(g) { buggy(g, { R: ['#fffbe0', '#ffe27a', '#f2c45a'], stripes: [7.6, 10.4], stripeCol: '#a8907c', tail: t => t.poly([[5, 10.4], [3, 11], [5, 11.8]], '#a8907c') }); },
    duck(g) { birdie(g, { R: ['#fffbe0', '#fff0a8', '#f2d47a'], beak: ['#ffb07a'], legs: '#ffb07a', beakLen: 2.8 }); },
    koi(g) { fishy(g, { R: ['#ffffff', '#fff6f2', '#ead8d8'], F: ['#ffe8dc', '#ffc4a8', '#f2a488'], mark: g2 => { g2.ell(7.6, 7.4, 2.4, 1.8, '#ffb48e', 0, kIN(g2)); g2.ell(11.6, 12.2, 1.8, 1.2, '#ffb48e', 0, kIN(g2)); } }); },
    owl(g) {
      const R = ['#f6eaf6', '#d4bcd6', '#b69ebc'];
      piece(g, t => { t.ell(6.2, 16.2, 1.2, 0.8, '#ffd27a'); t.ell(10.8, 16.2, 1.2, 0.8, '#ffd27a'); });
      piece(g, t => { t.poly([[3.6, 5.4], [3.8, 1.6], [6.6, 3.6]], R[1]); t.poly([[14.4, 5.4], [14.2, 1.6], [11.4, 3.6]], R[1]); t.ell(9, 10, 6.4, 6.2, R[1]); kShade(t, 9, 10, 6.4, 6.2, R); });
      g.ell(9, 13, 3.6, 2.8, '#fff6f0', 0, kIN(g));
      piece(g, t => { t.ell(3.4, 11, 1.8, 3, kFlat([R[1], R[2], mixHex(R[2], INK, 0.12)]), 0.2); t.ell(14.6, 11, 1.8, 3, kFlat([R[1], R[2], mixHex(R[2], INK, 0.12)]), -0.2); });
      for (const x of [6.8, 11.2]) g.ell(x, 8.6, 2.2, 2.2, '#fffaf2', 0, kIN(g));
      kFace(g, 9, 8.6, 5.4, { sp: 4.4, w: 2.4, h: 2.8, mouth: null, by: 2.8, bsp: 7.6 });
      piece(g, t => t.poly([[8.3, 10.4], [9.7, 10.4], [9, 11.8]], '#ffd27a'));
      g.outerLine();
    },
    firefly(g) { buggy(g, { R: ['#f2f0fa', '#cfcbe6', '#aea8cc'], r: 4.4, cy: 9.6, tail: t => t.ell(5, 12.6, 2.6, 2.4, '#fff6a8') , front: g2 => { g2.ell(4.6, 12.8, 1.2, 1.1, '#ffffff', 0, kIN(g2)); } }); kTw(g, 2, 16, '#fff27a'); kTw(g, 1.2, 9, '#fff27a'); },
    // ----- beach -----
    crab(g) {
      const R = ['#ffe2da', '#ffa898', '#ee8a7c'];
      piece(g, t => { for (const [x, d] of [[4.6, -1], [6.6, -0.5], [11.4, 0.5], [13.4, 1]]) stroke(t, [[x, 14], [x + d * 1.6, 16.4]], 0.45, 0.4, R[2]); });
      piece(g, t => { stroke(t, [[4.4, 11.4], [2.6, 8.4]], 0.6, 0.5, R[1]); stroke(t, [[13.6, 11.4], [15.4, 8.4]], 0.6, 0.5, R[1]); });
      piece(g, t => { t.ell(2.4, 7.2, 1.8, 1.8, R[1]); t.ell(15.6, 7.2, 1.8, 1.8, R[1]); t.ell(1.6, 6, 0.8, 0.8, null); t.ell(16.4, 6, 0.8, 0.8, null); kShade(t, 9, 7, 8, 2, R, { hl: false }); });
      piece(g, t => { stroke(t, [[7.4, 8], [7, 5.6]], 0.36, 0.36, R[2]); stroke(t, [[10.6, 8], [11, 5.6]], 0.36, 0.36, R[2]); });
      piece(g, t => kSoft(t, 9, 11.4, 5.6, 4, R));
      kFace(g, 9.4, 11, 4, { sp: 3.6, w: 1.9, h: 2.5, mouth: 'open', mw: 1.5 });
      g.outerLine();
    },
    seagull(g) { birdie(g, { R: C_WHITE, beak: ['#ffd27a'], legs: '#ffc08a', back: (t, R) => t.ell(6.2, 8.6, 3.6, 2.2, '#c8cadc', -0.2) }); },
    otter(g) { beast(g, { R: ['#f8e6d8', '#d8b49c', '#bc967e'], muzzle: '#fff4ea', belly: '#fff4ea', ears: roundEars(1.2, '#ecc8b4'), tail: (t, R) => stroke(t, [[4, 14.4], [1.8, 13.6], [1, 11.6]], 1.2, 0.7, R[1]),
      front: g2 => { piece(g2, t => { const pts = [[8.6, 15.6]]; for (let i = 0; i <= 8; i++) { const a = Math.PI + i * Math.PI / 8; pts.push([8.6 + Math.cos(a) * 2, 15 + Math.sin(a) * 2.2]); } t.poly(pts, '#ffd0dc'); }); } }); },
    seal(g) {
      const R = ['#f2f6fc', '#c6d2e6', '#a4b2ce'];
      piece(g, t => { t.poly([[3.6, 13.6], [0.8, 11.6], [1.2, 15.2]], R[2]); t.ell(6, 15.6, 2, 0.9, kFlat(R), 0.3); });
      piece(g, t => { t.ell(7.6, 13, 5.6, 3.4, R[1]); kShade(t, 7.6, 13, 5.6, 3.4, R, { hl: false }); });
      piece(g, t => kSoft(t, 11.4, 8.6, 5, 4.6, R));
      g.ell(13, 10.8, 2.2, 1.4, '#ffffff', 0, kIN(g));
      kFace(g, 12.4, 9.2, 4.8, { mouth: 'cat', mw: 1.3, my: 2.1 });
      for (const s2 of [-1, 1]) stroke(g, [[13 + s2 * 2.2, 10.9], [13 + s2 * 3.4, 10.6]], 0.14, 0.14, '#9aa6c0');
      g.outerLine();
    },
    dolphin(g) { fishy(g, { R: ['#eef8ff', '#a8d8f4', '#86bce4'], rx: 6.4, ry: 4.2, topFin: true, front: g2 => { piece(g2, t => t.ell(16.2, 10.4, 1.6, 0.9, ['#eef8ff', '#a8d8f4', '#86bce4'])); }, face: { mouth: 'smile' } }); },
    starfish(g) {
      const R = ['#ffeedd', '#ffbe9a', '#f2a07e'];
      piece(g, t => { t.poly(starPts(9, 10, 7.2, 3.6, 5), R[1]); for (let i = 0; i < 5; i++) { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; t.ell(9 + Math.cos(a) * 6.4, 10 + Math.sin(a) * 6.4, 1.3, 1.3, R[1]); } t.ell(9, 10.4, 4.2, 4, R[1]); kShade(t, 9, 10, 7, 7, R); });
      for (const [x, y] of [[9, 4.6], [4.6, 8.6], [13.4, 8.6]]) g.ell(x, y, 0.4, 0.4, '#fff6ee', 0, kIN(g));
      kFace(g, 9.4, 10.6, 4.4, { mouth: 'smile' });
      g.outerLine();
    },
    seaturtle(g) {
      const S = ['#e2f6ee', '#9cd8c0', '#7cbca4'], SK = ['#f2fae8', '#cce8b8', '#b0d09c'];
      piece(g, t => { t.ell(4.6, 15, 2.4, 1.1, kFlat(SK), 0.5); t.ell(11.6, 15.4, 2.6, 1.1, kFlat(SK), -0.4); t.ell(1.8, 12, 1.2, 0.7, kFlat(SK)); });
      piece(g, t => { t.ell(13.6, 10, 3.4, 3.1, SK[1]); kShade(t, 13.6, 10, 3.4, 3.1, SK); });
      piece(g, t => { t.ell(7.6, 11.6, 5.6, 4.2, S[1]); kShade(t, 7.6, 11.6, 5.6, 4.2, S); });
      for (const [x, y] of [[5.6, 10.4], [8.4, 9.6], [9.6, 12.4], [6.6, 13]]) g.ell(x, y, 1, 0.8, S[0], 0, kIN(g));
      kFace(g, 14.4, 10, 3.2, { sp: 2.4, w: 1.3, h: 1.7, mouth: 'smile', mw: 1, bsp: 3.6, bw: 0.6 });
      g.outerLine();
    },
    bat(g) { buggy(g, { R: ['#ece4f8', '#c4b4e2', '#a492c8'], r: 4.6, cy: 10.4, antTip: '#c4b4e2', ant: '#c4b4e2',
      wings: () => { for (const s2 of [-1, 1]) piece(g, t => { const x0 = 9.6 + s2 * 3; t.poly([[x0, 8.6], [x0 + s2 * 5.6, 6.4], [x0 + s2 * 6.4, 10.4], [x0 + s2 * 4.6, 9.8], [x0 + s2 * 3.6, 12], [x0 + s2 * 2, 11]], '#b4a2d6'); }); },
      face: { mouth: 'cat', blushCol: '#ffb8d0' } }); },
    wolf(g) { beast(g, { R: ['#eef0fa', '#c4c8e0', '#a2a6c6'], muzzle: '#ffffff', belly: '#ffffff', ears: pointEars('#ffd8e0', 4), tail: (t, R) => { t.ell(3.2, 10.6, 2.2, 3.6, R[1], -0.6); t.ell(2, 8.2, 1.2, 1.2, '#ffffff', -0.6); } }); },
    moth(g) { buggy(g, { R: ['#fffaf0', '#f2e6d4', '#dccab0'], ant: '#c8b4a0', antTip: '#f2e6d4', WG: ['#fff8ff', '#e6d8f6', '#cbb8e6'],
      wings: (g2, WG) => { piece(g2, t => t.ell(5.4, 7.4, 3.6, 3.2, kFlat(WG), -0.4)); piece(g2, t => t.ell(4.8, 12.4, 2.6, 2.2, kFlat(WG), 0.4)); g2.ell(5, 7, 1, 1, '#ffd8e8', 0, kIN(g2)); } }); },
    hedgehog(g) { beast(g, { R: ['#fff6ec', '#f6dcc4', '#e2c0a2'], body: [7.4, 13.4, 4.6, 3.2], head: [11, 9, 4.8, 4.4],
      tail: () => {}, ears: (t, R, h) => { const ox = h[0] - 3.4, oy = h[1] + 2.6; for (let i = 0; i < 6; i++) { const a = -3.25 + i * 0.36; t.poly([[ox + Math.cos(a - 0.3) * 3.4, oy + Math.sin(a - 0.3) * 3.4], [ox + Math.cos(a) * 6.4, oy + Math.sin(a) * 6], [ox + Math.cos(a + 0.3) * 3.4, oy + Math.sin(a + 0.3) * 3.4]], '#c9a088'); } t.ell(ox, oy, 4.2, 4, '#c9a088'); },
      face: { mouth: 'smile' } }); },
    jellyfish(g) {
      const R = ['#fff0f8', '#ffc4e0', '#f0a2c8'];
      piece(g, t => { for (const x of [5.4, 7.8, 10.2, 12.6]) stroke(t, [[x, 11], [x - 0.8, 13.6], [x + 0.4, 15.4], [x - 0.4, 16.6]], 0.55, 0.4, '#ffd8ea'); });
      piece(g, t => { t.ell(9, 9, 6, 5.2, R[1], 0, (x, y) => y <= 10.6); for (let x = 3.6; x <= 14.6; x += 2.2) t.ell(x, 10.6, 1.2, 0.9, R[1]); kShade(t, 9, 8, 6, 4.4, R); });
      kFace(g, 9.6, 8.4, 4.6, { mouth: 'smile' });
      g.outerLine();
    },
    // ----- candy -----
    gummybear(g) { beast(g, { R: ['#ffe6ea', '#ffaab6', '#f08a9c'], ears: roundEars(1.5, '#ffccd4'), muzzle: '#ffd0d8', face: { mouth: 'smile' }, front: g2 => { g2.dot(7, 12, '#ffffff'); g2.dot(7.5, 12, '#ffffff'); } }); },
    cottonsheep(g) { CR.ram(g); for (let i = 0; i < g.a.length; i++) { const c = g.a[i]; if (c === '#f6efe4') g.a[i] = '#ffd4ea'; else if (c === '#ffffff') g.a[i] = '#fff0f8'; else if (c === '#ddd0bc') g.a[i] = '#f0b0d4'; } },
    lollisnail(g) {
      const SK = ['#fffaf0', '#f8e8d0', '#e2ccb0'];
      piece(g, t => { t.ell(9, 15, 7.4, 1.8, SK[1]); t.ell(14.4, 11.4, 2.6, 3.6, SK[1]); kShade(t, 10, 13.4, 7.4, 3.6, SK, { hl: false }); });
      piece(g, t => { stroke(t, [[14, 8.6], [13.2, 5.6]], 0.3, 0.3, SK[2]); stroke(t, [[15.4, 8.6], [16.2, 5.8]], 0.3, 0.3, SK[2]); t.ell(13.1, 5.2, 0.7, 0.7, '#ffb4c8'); t.ell(16.3, 5.4, 0.7, 0.7, '#ffb4c8'); });
      piece(g, t => kSoft(t, 7.6, 9.6, 5, 5, ['#fff2f8', '#ffc4dc', '#f0a2c2']));
      const pts = []; for (let i = 0; i <= 26; i++) { const a = i * 0.5, r = 0.4 + i * 0.15; pts.push([7.6 + Math.cos(a) * r, 9.6 + Math.sin(a) * r]); } stroke(g, pts, 0.42, 0.42, '#ffffff');
      kFace(g, 15, 11.6, 2.8, { sp: 2.2, w: 1.2, h: 1.6, mouth: 'smile', mw: 1, bsp: 3.2, bw: 0.55 });
      g.outerLine();
    },
    sugarfinch(g) { birdie(g, { R: ['#fff0f8', '#ffc8e2', '#f2a6c8'], belly: '#eaf6ff', beak: ['#ffd866'], back: t => { t.ell(9, 4.4, 1.4, 1.4, '#a8d8ff'); } }); },
    sodafish(g) { fishy(g, { R: ['#ecfdff', '#9ee8f2', '#7ccce0'], F: ['#fff0f6', '#ffc4dc', '#f0a2c2'] }); for (const [x, y, r] of [[15.6, 3.2, 0.9], [13.6, 1.6, 0.6], [16.6, 6, 0.5]]) { const b = new Grid(g.w, g.h); b.ell(x, y, r, r, '#f4feff'); b.outline(); for (let i = 0; i < g.a.length; i++) if (b.a[i] && !g.a[i]) g.a[i] = b.a[i]; } },
    jellyocto(g) {
      const R = ['#f6eaff', '#d4b4f2', '#b494d8'];
      piece(g, t => { for (const [x, d] of [[4.6, -1.2], [7, -0.4], [9.6, 0.4], [12.2, 1], [14, 1.6]]) stroke(t, [[x, 11.6], [x + d, 14.4], [x + d * 1.6 + 0.8, 16]], 0.95, 0.65, R[1]); kShade(t, 9, 14, 6, 2.6, R, { hl: false }); });
      piece(g, t => kSoft(t, 9.2, 8.6, 6, 5.4, R));
      kFace(g, 10, 9.2, 5, { mouth: 'smile' });
      g.outerLine();
    },
    // ----- more -----
    frog(g) {
      const R = ['#eefad8', '#b4e48c', '#94c86e'];
      piece(g, t => { t.ell(4.4, 15.8, 2, 1, kFlat(R)); t.ell(13.6, 15.8, 2, 1, kFlat(R)); });
      piece(g, t => { t.ell(5.6, 5.8, 2.6, 2.6, R[1]); t.ell(12.4, 5.8, 2.6, 2.6, R[1]); t.ell(9, 11, 6.6, 5, R[1]); kShade(t, 9, 10, 6.8, 6, R); });
      g.ell(9, 13.4, 4, 2, '#fbfbe8', 0, kIN(g));
      kFace(g, 9, 6, 6, { sp: 6.8, w: 2.6, h: 3, mouth: null, by: 4.8, bsp: 9 });
      AR_mouth(g, 9.2, 11, 'smile', 2.4);
      g.outerLine();
    },
    squirrel(g) { beast(g, { R: ['#fbe6d2', '#e6b28a', '#cc946c'], belly: '#fff2e6', muzzle: '#fff2e6', ears: pointEars('#f2c8a8', 3), tail: (t, R) => { t.ell(3.4, 9.4, 2.8, 5, R[1], -0.25); t.ell(4.8, 4.6, 2.2, 1.9, R[1]); } }); },
    butterfly(g) { buggy(g, { R: ['#f6eaff', '#d8bcf2', '#b89cd8'], r: 3.6, cy: 10.6, cx: 10, ant: '#b8a4c8', antTip: '#ffb4c8',
      wings: () => { for (const [x, y, rx, ry, c, rot] of [[5.4, 6.6, 3.8, 3.4, '#ffc8dc', -0.4], [5.6, 12.8, 2.8, 2.4, '#c8e2ff', 0.4], [14.4, 6.6, 3.4, 3, '#ffc8dc', 0.4]]) piece(g, t => { t.ell(x, y, rx, ry, c, rot); kShade(t, x, y, rx, ry, [mixHex(c, '#ffffff', 0.6), c, mixHex(c, INK, 0.12)], { hl: false }); }); g.ell(5, 6.2, 1.1, 1, '#ffffff', 0, kIN(g)); } }); },
    pelican(g) { birdie(g, { R: C_WHITE, beak: ['#ffd27a'], beakLen: 4, cx: 8, front: g2 => { piece(g2, t => t.ell(15.4, 11, 2.6, 1.6, '#ffe2a0')); } }); },
    seahorse(g) {
      const R = ['#fff2dc', '#ffd28e', '#f2b46a'];
      piece(g, t => stroke(t, [[9, 11], [8.6, 14.4], [10.4, 16.4], [12, 15.4], [11, 14.2]], 1.6, 0.6, R[1]));
      piece(g, t => { t.poly([[5.4, 6], [3.4, 4.6], [3.6, 8.6]], '#ffc4dc'); t.poly([[5, 10], [3, 9.6], [4, 12.4]], '#ffc4dc'); });
      piece(g, t => { t.ell(8.6, 10.6, 3.6, 3.4, R[1]); kShade(t, 8.6, 10.6, 3.6, 3.4, R, { hl: false }); });
      piece(g, t => { kRect(t, 11.6, 6.2, 15.6, 7.8, 0.8, R[1]); t.ell(9.6, 5.6, 4, 3.8, R[1]); t.ell(8.4, 2, 1, 1.2, R[1]); kShade(t, 10.4, 5.6, 5, 3.8, R); });
      kFace(g, 10.2, 5.8, 3.6, { sp: 2.8, w: 1.5, h: 2, mouth: null, bsp: 4.6, bw: 0.7 });
      g.outerLine();
    },
    pufferfish(g) { fishy(g, { R: ['#fffbe0', '#ffe68a', '#f2c862'], rx: 5.4, ry: 5.2, cy: 9.6, topFin: false,
      back: (t, R) => { for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5; t.poly([[9.6 + Math.cos(a - 0.2) * 5, 9.6 + Math.sin(a - 0.2) * 5], [9.6 + Math.cos(a) * 7, 9.6 + Math.sin(a) * 6.8], [9.6 + Math.cos(a + 0.2) * 5, 9.6 + Math.sin(a + 0.2) * 5]], '#f2d48a'); } },
      face: { mouth: 'o' } }); },
    raccoon(g) { beast(g, { R: ['#f0f0f8', '#c4c4d8', '#a2a2bc'], ears: pointEars('#e2e2ee', 3.4), muzzle: '#ffffff',
      tail: (t, R) => { t.ell(3.2, 11, 2.2, 3.6, R[1], -0.6); },
      mark: (g2, h) => { g2.ell(h[0] + 1.1, h[1] + 0.6, 4.4, 1.8, '#8a8aa6', 0, kIN(g2)); },
      front: g2 => { for (const y of [9.4, 11.4]) { const m = (x, yy) => g2.filled(x, yy) && x < 5.4 && Math.abs(yy - y) < 0.5; m.fine = true; g2.ell(3.2, y, 3, 1, '#8a8aa6', 0, m); } } }); },
    anglerfish(g) { fishy(g, { R: ['#e8eaf8', '#aab0dc', '#8a90c4'], F: ['#e6e0f6', '#c0b2e2', '#a090c8'], face: { mouth: 'grin', mw: 2 },
      front: g2 => { piece(g2, t => stroke(t, [[11, 5.4], [12.6, 2.4], [14.8, 2]], 0.3, 0.3, '#a090c8')); piece(g2, t => t.ell(15.2, 2.4, 1.2, 1.2, '#fff4a0')); } }); kTw(g, 16.8, 1.2, '#fff4a0'); },
    moondeer(g) { beast(g, { R: ['#f4eeff', '#d4c4f2', '#b6a4d8'], muzzle: '#fbf6ff', ears: (t, R, h) => { pointEars('#f2e6ff', 2.6)(t, R, h); for (const s2 of [-1, 1]) stroke(t, [[h[0] + s2 * 1.4, h[1] - 4], [h[0] + s2 * 2.4, h[1] - 7], [h[0] + s2 * 3.8, h[1] - 7.6]], 0.42, 0.36, '#f6e2b8'); },
      tail: fluffTail(2.8, 11.6, 1.4, '#ffffff'), mark: (g2, h) => { g2.ell(h[0] - 1.6, h[1] - 3, 1.2, 1.2, '#fff4a8', 0, kIN(g2)); g2.ell(h[0] - 1.1, h[1] - 3.4, 1, 1, '#d4c4f2', 0, kIN(g2)); } }); },
    marshbunny(g) { beast(g, { R: ['#ffffff', '#fff4f8', '#f0d8e4'], ears: longEars('#ffd0e0'), tail: fluffTail(2.8, 12.2, 1.6), face: { mouth: 'cat', blushCol: '#ffb0c8' } }); },
    chocomouse(g) { beast(g, { R: ['#f6e2d4', '#d4ac92', '#b88e76'], ears: roundEars(2.2, '#ffc8d4'), muzzle: '#fbeee4', tail: (t, R) => stroke(t, [[4, 14.2], [1.8, 13.4], [1.2, 11]], 0.4, 0.3, '#ffb8c8'), face: { mouth: 'cat' } }); },
    licoriceeel(g) {
      const R = ['#ffe6ee', '#ffaabc', '#ee8aa0'];
      piece(g, t => stroke(t, [[1.6, 13.6], [4.4, 15.4], [7.6, 13.4], [10.4, 11.2], [13, 11.4]], 1.6, 2.2, R[1]));
      each2(g, (x, y, c) => { if (c === R[1] && x < 12 && Math.floor(x / 1.5) % 2 === 0) g.set(x, y, '#d4b4f2'); });
      piece(g, t => kSoft(t, 13.4, 9.6, 3.6, 3.4, R));
      kFace(g, 14, 9.6, 3.4, { sp: 2.6, w: 1.4, h: 1.9, mouth: 'smile', mw: 1, bsp: 3.8, bw: 0.6 });
      g.outerLine();
    },
    // ----- rares (26x26) -----
    dragon(g) {
      const R = ['#ffe6ea', '#ffa8b6', '#ee8a9c'], WG = ['#fff2e2', '#ffd2a0', '#f2b47e'];
      piece(g, t => { t.poly([[8, 11], [1.4, 4.4], [2.4, 10.6], [0.8, 13.4], [6.6, 15]], WG[1]); kShade(t, 5, 10, 5, 5, WG, { hl: false }); });
      piece(g, t => { stroke(t, [[7, 20], [3.6, 21.4], [1.6, 19.6]], 1.6, 0.8, R[1]); t.poly([[0.6, 18.4], [2.6, 17.6], [2, 20.4]], R[2]); });
      piece(g, t => { t.ell(9, 24, 2, 1.3, kFlat(R)); t.ell(14.6, 24.2, 2, 1.3, kFlat(R)); });
      piece(g, t => { kSoft(t, 11.4, 19.6, 6, 4.8, R, { hl: false }); t.ell(12.6, 20.4, 3.6, 3.4, '#fff4dc', 0, kIN(t)); });
      piece(g, t => { t.poly([[11.6, 6.4], [10.4, 1.6], [13.6, 5]], '#fff4dc'); t.poly([[17.4, 5.8], [18.8, 1.4], [19.4, 6]], '#fff4dc'); });
      piece(g, t => kSoft(t, 15.4, 11.4, 7.4, 6.8, R));
      for (const [x, y] of [[9, 7.2], [8, 10.4], [8.4, 13.6]]) piece(g, t => t.poly([[x, y - 1.2], [x - 2, y], [x, y + 1.2]], '#ffd2a0'));
      kFace(g, 17.2, 12.4, 7, { mouth: 'open', mw: 2.2 });
      g.outerLine();
    },
    unicorn(g) {
      const R = ['#ffffff', '#f8f4fc', '#e0d6ec'], MANE = ['#ffb8d0', '#ffe2a0', '#b8e6c8', '#a8d4ff', '#d4b8f4'];
      piece(g, t => { for (const [x, d] of [[8, -0.4], [10.6, 0.2], [15, -0.2], [17.6, 0.4]]) kRect(t, x - 1.1, 18, x + 1.1, 24.4 + d * 0, 0.9, R[1]); });
      piece(g, t => { stroke(t, [[6, 16.4], [3.4, 17], [2.2, 20]], 1.6, 1, MANE[3]); });
      piece(g, t => kSoft(t, 12.6, 17.4, 7, 4.4, R, { hl: false }));
      piece(g, t => { for (let i = 0; i < 5; i++) t.ell(11 - i * 0.6, 4.6 + i * 2, 2.4, 1.8, MANE[i]); });
      piece(g, t => { t.poly([[17, 4.4], [19.6, -0.2], [19.8, 4.6]], '#fff0b0'); });
      piece(g, t => { t.poly([[13, 4.6], [13.4, 1.6], [15.4, 4]], R[1]); });
      piece(g, t => kSoft(t, 17, 9.4, 6.4, 6, R));
      g.ell(20, 12.4, 2.6, 1.8, '#fff0f6', 0, kIN(g));
      kFace(g, 18, 9.8, 6, { mouth: 'smile', mw: 1.8, my: 3.6 });
      g.outerLine();
    },
    kitsune(g) {
      const R = ['#fffaf2', '#fbeedc', '#e6d2b6'];
      piece(g, t => { for (const [x, y, rot] of [[4.4, 11.6, -0.9], [3.6, 16, -0.4], [5, 20, 0.1]]) { t.ell(x, y, 2.6, 4.2, R[1], rot); } kShade(t, 4.4, 15.6, 3.6, 7, R, { hl: false }); });
      for (const [x, y] of [[2.4, 9.4], [1.6, 13.8], [2.6, 18.4]]) g.ell(x, y, 1.1, 1.1, '#ffc0a8', 0, kIN(g));
      piece(g, t => { t.ell(10.6, 24, 1.9, 1.2, kFlat(R)); t.ell(15.4, 24.1, 1.9, 1.2, kFlat(R)); });
      piece(g, t => kSoft(t, 12.6, 19.6, 5.6, 4.4, R, { hl: false }));
      piece(g, t => { for (const [dx, lean] of [[-3.6, -1], [3.4, 0.8]]) { t.poly([[15.4 + dx - 2.6, 8], [15.4 + dx + lean, 1.4], [15.4 + dx + 2.6, 7.4]], R[1]); t.poly([[15.4 + dx - 1.2, 7.4], [15.4 + dx + lean * 0.8, 3.4], [15.4 + dx + 1.2, 7.2]], '#ffc8b4'); } });
      piece(g, t => kSoft(t, 15.6, 11.6, 7, 6.4, R));
      g.dots([[14.6, 6.6], [15.6, 6.2], [16.6, 6.6]], '#ff9eb0');
      kFace(g, 17, 12.4, 6.6, { mouth: 'cat', mw: 2 });
      g.outerLine();
      piece(g, t => kDrop(t, 23.4, 4.6, 1.4, 1.4, 2, -0.4, '#a8d8ff')); g.outerLine();
    },
    yeti(g) {
      const R = ['#ffffff', '#f4f6fc', '#d8dcec'], FC = ['#eef4ff', '#c4d6f6', '#a4b8e4'];
      piece(g, t => { t.ell(8.4, 24, 2.6, 1.4, kFlat(FC)); t.ell(16, 24, 2.6, 1.4, kFlat(FC)); });
      piece(g, t => { t.ell(3.6, 17, 2.4, 3.6, R[1], 0.3); t.ell(21, 17, 2.4, 3.6, R[1], -0.3); for (const [x, y, r] of [[12.4, 18, 7.4], [12.4, 10.4, 8.4], [6, 8, 3], [18.6, 7.6, 3], [12.4, 3.6, 3.4]]) t.ell(x, y, r, r * 0.95, R[1]); kShade(t, 12.4, 13, 10, 11, R); });
      piece(g, t => kSoft(t, 13.4, 12, 5.4, 4.6, FC, { hl: false }));
      kFace(g, 13.8, 12, 5, { mouth: 'open', mw: 2 });
      g.outerLine();
    },
    griffin(g) {
      const L = ['#fff2dc', '#f6cf96', '#e2b074'], H = ['#ffffff', '#f6f4fa', '#ddd6e6'], WG = ['#fff8ee', '#f2e2c8', '#dcc6a4'];
      piece(g, t => { stroke(t, [[6, 19], [2.6, 18], [1.6, 14.6]], 0.7, 0.6, L[2]); t.ell(1.6, 13.8, 1.2, 1.4, L[1]); });
      piece(g, t => { t.ell(8.4, 24.2, 1.8, 1.2, kFlat(L)); t.ell(15.6, 24.2, 1.8, 1.2, kFlat(L)); });
      piece(g, t => kSoft(t, 11.4, 19.4, 6.4, 4.4, L, { hl: false }));
      piece(g, t => { t.poly([[9, 15.6], [2, 8.4], [4, 7.6], [3.4, 5], [6.4, 5.6], [7, 3.4], [11.4, 11]], WG[1]); kShade(t, 6.4, 9, 4.6, 5, WG, { hl: false }); });
      piece(g, t => kSoft(t, 16, 10.6, 6.2, 5.8, H));
      piece(g, t => { t.poly([[20.6, 10.2], [25, 11.6], [21.4, 13.4]], '#ffd27a'); });
      kFace(g, 16.6, 10.4, 5.6, { mouth: null });
      g.outerLine();
    },
    dinosaur(g) {
      const R = ['#eefad8', '#b4e28c', '#94c66e'];
      piece(g, t => { stroke(t, [[8, 19.4], [4, 21.4], [1, 22.4]], 2.2, 0.8, R[1]); });
      piece(g, t => { t.ell(9.6, 24, 2.2, 1.3, kFlat(R)); t.ell(15, 24.1, 2.2, 1.3, kFlat(R)); });
      piece(g, t => { kSoft(t, 12, 19.4, 6, 4.8, R, { hl: false }); t.ell(13.4, 20.4, 3.2, 3.2, '#fbfbe4', 0, kIN(t)); });
      for (const [x, y] of [[7.6, 9.6], [8.4, 6.2], [10.6, 3.4], [14, 2.2]]) piece(g, t => t.ell(x, y, 1.4, 1.4, '#ffc4a8'));
      piece(g, t => kSoft(t, 15, 10.6, 7.4, 6.8, R));
      piece(g, t => stroke(t, [[17.4, 18], [19.4, 18.6]], 0.7, 0.6, R[1]));
      kFace(g, 16.8, 11.4, 7, { mouth: 'open', mw: 2.2 });
      g.outerLine();
    },
    kraken(g) {
      const R = ['#f6eaff', '#d0aef2', '#b08ed8'];
      piece(g, t => { for (const [x, d] of [[4, -2.2], [7.4, -1], [11, 0], [14.6, 0.8], [18.2, 1.8], [21.4, 2.4]]) stroke(t, [[x + 0.6, 15], [x + d, 19.4], [x + d * 1.6 + 1.2, 22.4], [x + d * 1.4 + 2.6, 22]], 1.4, 0.8, R[1]); kShade(t, 13, 19, 10, 4, R, { hl: false }); });
      for (const [x, y] of [[5, 20.4], [11.4, 21.4], [18.4, 20.6]]) g.ell(x, y, 0.5, 0.5, '#fff0ff', 0, kIN(g));
      piece(g, t => kSoft(t, 13, 10, 9, 8.2, R));
      kFace(g, 14, 11, 8, { mouth: 'smile', mw: 2.4 });
      g.outerLine();
    },
    phoenix(g) {
      const R = ['#fff6dc', '#ffd27a', '#f6b05a'], FL = ['#ffe6d4', '#ffae8a', '#f28c6c'];
      piece(g, t => { for (const [a, l] of [[2.6, 9], [2.9, 10], [3.25, 8.6]]) { const ex = 11 + Math.cos(a) * l, ey = 16 + Math.sin(a) * l; kDrop(t, ex + 1, ey, 1.8, 1.6, 0, 0, FL[1]); stroke(t, [[11, 16], [ex, ey]], 1.6, 1.2, FL[1]); } kShade(t, 5, 17, 6, 5, FL, { hl: false }); });
      piece(g, t => { t.poly([[10, 13], [4, 6], [6.6, 6.2], [5.6, 3], [9.4, 5.4], [10, 2.6], [13.4, 10]], FL[1]); kShade(t, 8, 8, 4, 4.6, FL, { hl: false }); });
      piece(g, t => { stroke(t, [[13, 21], [12.6, 24.4]], 0.4, 0.4, '#ffb07a'); stroke(t, [[16, 21], [16.4, 24.4]], 0.4, 0.4, '#ffb07a'); });
      piece(g, t => kSoft(t, 15, 14.6, 6.4, 6, R));
      piece(g, t => { kDrop(t, 15.4, 8.4, 1.2, 1.2, 2.6, -1, FL[1]); });
      piece(g, t => t.poly([[20.6, 13.4], [24, 14.6], [20.8, 15.8]], '#ffae8a'));
      kFace(g, 16.6, 14, 5.6, { mouth: null });
      g.outerLine();
      kTw(g, 3, 3, '#ffd27a', true); kTw(g, 23, 6, '#ffd27a');
    },
    fairy(g) {
      const SK = ['#fff4ec', '#ffe0cc', '#f2c4ac'], HR = ['#fff8d0', '#ffe28a', '#f2c464'], DR = ['#fff0f8', '#ffc4e0', '#f0a2c8'], WG = ['#ffffff', '#eaf6ff', '#c8e2f6'];
      for (const [x, y, rx, ry, rot] of [[6.4, 9, 4, 5.4, -0.5], [6.4, 17, 3, 3.6, 0.4], [19.6, 9, 4, 5.4, 0.5], [19.6, 17, 3, 3.6, -0.4]]) piece(g, t => t.ell(x, y, rx, ry, kFlat(WG), rot));
      piece(g, t => { stroke(t, [[11.6, 21], [11.2, 24.4]], 0.6, 0.6, SK[1]); stroke(t, [[14.4, 21], [14.8, 24.4]], 0.6, 0.6, SK[1]); });
      piece(g, t => { t.poly([[10, 15.6], [16, 15.6], [18.6, 22], [7.4, 22]], DR[1]); kShade(t, 13, 18.6, 5.6, 3.6, DR, { hl: false }); });
      piece(g, t => { t.ell(13, 9, 7.2, 6.8, HR[1]); t.ell(7.6, 12.6, 2, 3.2, HR[1]); t.ell(18.4, 12.6, 2, 3.2, HR[1]); kShade(t, 13, 9.6, 7.4, 7, HR); });
      piece(g, t => kSoft(t, 13.4, 11, 5.4, 4.8, SK, { hl: false }));
      piece(g, t => { t.ell(10.4, 4.6, 3.6, 2.4, HR[1], -0.3); t.ell(15.6, 4.4, 3.6, 2.2, HR[1], 0.3); });
      kFace(g, 13.8, 11.6, 5, { mouth: 'smile', mw: 1.6 });
      g.outerLine();
      piece(g, t => { stroke(t, [[19.4, 19], [22.4, 15]], 0.3, 0.3, '#e2c4a8'); t.poly(starPts(22.8, 14.4, 1.8, 0.8, 5), '#ffe27a'); });
      kTw(g, 24.6, 11.6, '#ffe27a'); kTw(g, 2.4, 22, '#ffc4e0');
    },
  };
  const AR_mouth = (g, x, y, k, w) => { const A = kArt(); if (A.chibiMouth) A.chibiMouth(g, x, y, k, w); };
  const each2 = (g, fn) => { for (let y = 0; y < g.h; y++) for (let x = 0; x < g.w; x++) fn(x, y, g.get(x, y)); };

  // ---------------- Living plants (18x18, facing right, 3 frames: 0 rest, 1 sway/wave/open, 2 blink or squish) ----------------
  const pEyes = (g, x1, x2, y, blink) => { for (const x of [x1, x2]) { if (blink) g.set(x, y + 1, INK); else { g.set(x, y, INK); g.set(x, y + 1, INK); } } };
  const pSmile = (g, x, y, w) => { g.set(x, y, INK); for (let i = 1; i < w - 1; i++) g.set(x + i, y + 1, INK); g.set(x + w - 1, y, INK); };
  const pCheeks = (g, x1, x2, y, c) => g.px([[x1, y], [x2, y]].filter(([x, y2]) => g.filled(x, y2)), c || '#f4a3b8');
  const LEAFG = ['#a6ec70', '#5cb43a', '#2f7a4a'];
  // a water flower: pointed petals opening round a smiling bud, on a floating pad (face kept high so the swim cut shows it)
  function lily(g, f, P, PAD, dot) {
    const o = f === 1 ? 1 : 0;
    g.ell(9, 15.4, 8, 1.8, PAD);
    piece(g, t => { t.poly([[4.6, 13], [1.4 - o, 6 + o], [7.4, 9.6]], P[1]); t.poly([[13.4, 13], [16.6 + o, 6 + o], [10.6, 9.6]], P[1]); });
    piece(g, t => t.ell(9, 12.2, 6, 2.8, P, 0, (x, y) => y >= 10));
    piece(g, t => t.ell(9, 6.6, 4, 4.2 - o * 0.3, P));
    g.outline();
    g.px([[3, 8], [15, 8], [2, 7]].filter(([x, y]) => g.filled(x, y)), P[0]);
    pEyes(g, 7, 10, 5 + o, f === 2); pSmile(g, 7, 8 + o, 4); pCheeks(g, 6, 11, 8 + o, '#f7b6c8');
    g.px([[8, 3], [9, 3]].filter(([x, y]) => g.filled(x, y)), '#ffffff');
    g.px([[7, 11], [9, 11], [11, 11]].filter(([x, y]) => g.filled(x, y)), dot);
  }
  const PLANTS = {
    // ----- meadow -----
    sunbuddy(g, f) {
      const hx = 9.6 + (f === 1 ? 0.7 : 0), hy = 6.6, pr = f === 1 ? 4.5 : 4.1, up = f === 1;
      g.rect(9, 10, 2, 6, '#4f9a3e');
      g.ell(5.8, up ? 10.2 : 12.4, 2.5, 1.2, LEAFG, up ? -0.7 : 0.4); g.ell(13.6, up ? 11 : 12.6, 2.5, 1.2, LEAFG, up ? 0.7 : -0.4);
      g.ell(8, 16.2, 1.7, 0.9, '#8f563b'); g.ell(11.8, 16.2, 1.7, 0.9, '#8f563b');
      for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5 + (up ? 0.2 : 0); g.ell(hx + Math.cos(a) * (pr + 0.3), hy + Math.sin(a) * (pr + 0.3), 1.8, 1.1, RAMPS.sun, a); }
      piece(g, t => t.ell(hx, hy, 3.5, 3.3, ['#fbe0b0', '#f0c080', '#c88a50']));
      g.outline();
      const ex = Math.round(hx) - 2; pEyes(g, ex, ex + 3, 4, f === 2);
      pSmile(g, ex, 7, 4); pCheeks(g, ex - 1, ex + 4, 7);
      g.px([[5, 10], [13, 11]].filter(([x, y]) => g.filled(x, y)), '#d4f8a8');
    },
    shroomy(g, f) {
      const sq = f === 2 ? 1 : 0, CAP = ['#ff9aa0', '#e8404a', '#a02c3a'];
      g.ell(6.6 + (f === 1 ? -0.6 : 0), 15.8, 1.8, 1.1, '#e8d8c0'); g.ell(11.6 + (f === 1 ? 0.6 : 0), 15.8, 1.8, 1.1, '#e8d8c0');
      g.ell(9.4, 11.8 + sq * 0.4, 4.9 + sq * 0.4, 3.6 - sq * 0.4, ['#fffaf0', '#f4e6d0', '#c8b498']);
      g.ell(9, 7.6 + sq, 7.4 + sq * 0.4, 5.2 - sq * 0.5, CAP, 0, (x, y) => y <= 8 + sq);
      g.outline();
      for (const [x, y] of [[5, 5], [9, 3], [12, 6], [7, 7], [14, 8]]) if (CAP.includes(g.get(x, y + sq))) { g.set(x, y + sq, '#ffffff'); if (CAP.includes(g.get(x + 1, y + sq))) g.set(x + 1, y + sq, '#fbe8e8'); }
      g.px([[3, 8 + sq], [4, 8 + sq], [15, 8 + sq]].filter(([x, y]) => g.filled(x, y)), '#c86a5a');
      pEyes(g, 8, 11, 10, f === 2); pSmile(g, 8, 13, 4); pCheeks(g, 7, 12, 13);
    },
    puffball(g, f) {
      stroke(g, [[9, 17], [9.4, 13.4], [9, 11]], 0.55, 0.5, '#4f9a3e');
      g.ell(6.6, 15.6, 2, 0.9, LEAFG, 0.5);
      const r = f === 1 ? 5.6 : 5.9;
      g.ell(9, 6.8, r, r, RAMPS.cloud);
      g.outline('#9aa4c0');
      for (let k = 0; k < 12; k++) { const a = k * Math.PI / 6 + (f === 1 ? 0.26 : 0), x = Math.round(9 + Math.cos(a) * (r - 0.6)), y = Math.round(6.8 + Math.sin(a) * (r - 0.6)); if (g.filled(x, y)) g.set(x, y, '#dfe4f4'); }
      for (const [x, y] of f === 1 ? [[16, 2], [1, 5], [15, 11]] : [[17, 4], [2, 1]]) if (!g.get(x, y)) { g.set(x, y, '#ffffff'); if (!g.get(x - 1, y + 1)) g.set(x - 1, y + 1, '#c8d0e0'); }
      pEyes(g, 8, 11, 6, f === 2); pSmile(g, 8, 9, 4); pCheeks(g, 7, 12, 9, '#f7b6c8');
    },
    cloverkin(g, f) {
      const s = f === 1 ? 0.35 : 0;
      g.ell(6.8, 15.8, 1.6, 0.9, '#37946e'); g.ell(11.4, 15.8, 1.6, 0.9, '#37946e');
      g.ell(9.4, 11.8, 4.9, 3.8, LEAFG);
      g.rect(9, 5, 1, 3, '#37946e');
      for (let k = 0; k < 4; k++) { const a = -Math.PI / 4 + k * Math.PI / 2 + s; piece(g, t => t.ell(9.5 + Math.cos(a) * 2.2, 4.6 + Math.sin(a) * 2, 2.1, 1.8, ['#c8f4a0', '#6abe30', '#37946e'], a)); }
      g.outline();
      g.px([[9, 4], [10, 5]].filter(([x, y]) => g.filled(x, y)), '#37946e'); g.set(8, 3, '#ffffff');
      pEyes(g, 8, 11, 10, f === 2); pSmile(g, 8, 13, 4); pCheeks(g, 7, 12, 13);
      g.px([[6, 10], [6, 11]].filter(([x, y]) => g.filled(x, y)), '#c8f4a0');
    },
    // ----- beach -----
    cactling(g, f) {
      const CG = ['#9ce07a', '#4fae5a', '#2f7a4a'], up = f === 1;
      g.poly([[4.4, 12.6], [13.6, 12.6], [12.6, 16.6], [5.4, 16.6]], '#d8764a');
      g.rect(4, 12, 10, 1, '#e8905a');
      piece(g, t => { stroke(t, [[4.6, 10.4], [2.6, 9.8], [2.2, 7.4]], 1, 0.9, CG[1]); stroke(t, [[13.6, 9.8], [15.4, up ? 8 : 9.6], [15.6, up ? 5 : 7.2]], 1, 0.9, CG[1]); });
      g.ell(9.2, 7.8, 5, 5.6, CG, 0, (x, y) => y <= 12);
      g.outline();
      for (let y = 12; y < 17; y++) for (let x = 3; x < 15; x++) { const c = g.get(x, y); if (c === '#d8764a' && g.get(x + 1, y) === INK) g.set(x, y, '#a8502e'); }
      g.px([[6, 4], [5, 9], [12, 4], [12, 10], [6, 11], [2, 8], [15, up ? 6 : 8]].filter(([x, y]) => g.filled(x, y)), '#ffffff');
      g.ell(9, 1.8, 1.8, 1.2, '#f07aa0'); g.set(9, 1, '#ffd0e0'); g.px([[8, 2], [10, 2]], '#e04a80'); g.set(9, 3, '#fbf236');
      pEyes(g, 8, 11, 6, f === 2); pSmile(g, 8, 9, 4); pCheeks(g, 7, 12, 9);
    },
    kelpie(g, f) {
      const K = ['#9cd06a', '#4f9a3e', '#2f6a3a'], w = f === 1 ? 1 : -1;
      piece(g, t => { stroke(t, [[3.4, 17], [2.4 - w * 0.5, 12.4], [3.2 + w * 0.6, 8], [2 - w * 0.4, 4.4]], 1.1, 0.7, '#6a9a3a'); stroke(t, [[15, 17], [15.8 + w * 0.5, 12.6], [15 - w * 0.6, 8.4], [16 + w * 0.4, 5]], 1.1, 0.7, '#6a9a3a'); });
      g.ell(9.4, 10.6, 5, 6.2, K);
      stroke(g, [[9, 4.6], [9.6 + w * 0.8, 2.2], [11 + w * 0.4, 0.8]], 0.9, 0.6, K[1]);
      g.outline();
      g.px([[7, 14], [8, 12], [11, 15], [10, 13]].filter(([x, y]) => g.filled(x, y)), K[2]); g.px([[3, 10], [15, 11]].filter(([x, y]) => g.filled(x, y)), '#b8e08a');
      pEyes(g, 8, 11, 6, f === 2); pSmile(g, 8, 9, 4); pCheeks(g, 7, 12, 9);
      for (const [x, y] of f === 1 ? [[16, 1], [1, 3]] : [[17, 3], [0, 6]]) if (!g.get(x, y)) g.set(x, y, '#dff6ff');
    },
    coconut(g, f) {
      const CO = ['#c48a5c', '#8f563b', '#5a3322'], sw = f === 1 ? 0.35 : 0;
      g.ell(6.6, 16, 1.7, 0.9, CO[2]); g.ell(11.6, 16, 1.7, 0.9, CO[2]);
      for (const [a, l] of [[-2.5, 5.2], [-1.9, 5.6], [-1.2, 5.2], [-0.6, 4.4]]) { const b = a + sw; piece(g, t => stroke(t, [[9, 6], [9 + Math.cos(b) * l * 0.55, 6 + Math.sin(b) * l * 0.55 - 0.8], [9 + Math.cos(b) * l, 6 + Math.sin(b) * l + 1.2]], 1.2, 0.5, LEAFG[1])); }
      g.ell(9, 11, 5.2, 4.8, CO);
      g.outline();
      g.ell(10.4, 10.6, 3.2, 2.4, '#f0dcc0', 0, (x, y) => CO.includes(g.get(x, y)));
      g.px([[5, 8], [6, 7], [4, 11], [6, 13], [13, 14]].filter(([x, y]) => CO.includes(g.get(x, y))), '#6a3e26');
      pEyes(g, 9, 12, 9, f === 2); pSmile(g, 9, 12, 4); pCheeks(g, 8, 13, 12);
    },
    // ----- moonlit -----
    glowcap(g, f) {
      const CAP = f === 1 ? ['#f0ffff', '#9ff8f0', '#4fb8b8'] : ['#c8fff8', '#5fe8e0', '#2f8f98'];
      g.ell(6.8, 15.8, 1.7, 1, '#d8e0f0'); g.ell(11.4, 15.8, 1.7, 1, '#d8e0f0');
      g.ell(9.4, 12, 4.4, 3.6, ['#ffffff', '#e8eef8', '#b8c0d8']);
      g.ell(9, 7.8, 7, 5.4, CAP, 0, (x, y) => y <= 8.5);
      g.outline();
      for (const [x, y] of [[5, 5], [9, 3], [12, 5], [14, 7], [6, 7]]) if (CAP.includes(g.get(x, y))) g.set(x, y, '#ffffff');
      if (f === 1) for (const [x, y] of [[1, 5], [17, 6], [3, 1], [15, 1]]) if (!g.get(x, y)) g.set(x, y, '#c8fff8');
      pEyes(g, 8, 11, 10, f === 2); pSmile(g, 8, 13, 4); pCheeks(g, 7, 12, 13, '#a6e8ff');
    },
    snapvine(g, f) {
      const open = f === 1, JW = ['#b4ec6c', '#5cb43a', '#2f7a4a'];
      g.ell(6.4, 16, 2.2, 1, LEAFG, 0.3); g.ell(11.8, 16, 2.2, 1, LEAFG, -0.3);
      g.rect(8, 11, 2, 5, '#4f9a3e');
      piece(g, t => t.ell(9.4, 5.4 - (open ? 0.6 : 0), 6.4, 3.6, JW, 0, (x, y) => y <= 6 - (open ? 0.6 : 0)));
      piece(g, t => t.ell(9.4, 7.6 + (open ? 0.8 : 0), 6.4, 3.4, JW, 0, (x, y) => y >= 7 + (open ? 0.8 : 0)));
      g.outline();
      const y1 = open ? 6 : 6, y2 = open ? 8 : 7;
      for (let x = 4; x <= 15; x++) { if (g.get(x, y1) && g.get(x, y1) !== INK) g.set(x, y1, '#e8506a'); if (open && g.filled(x, 6) && g.filled(x, 8)) g.set(x, 7, '#a02c46'); }
      for (const x of [4, 7, 12, 15]) for (let y = 0; y < 9; y++) if (g.get(x, y) === INK) { if (!g.get(x, y - 1)) g.set(x, y - 1, '#7ed04a'); break; }
      for (const x of [5, 8, 11, 14]) { if (g.filled(x, y1)) g.set(x, y1, '#ffffff'); if (open && g.filled(x + 1, y2)) g.set(x + 1, y2, '#ffffff'); }
      // eyes on top of the head
      piece(g, t => { t.ell(8, 1.6, 1.5, 1.5, '#ffffff'); t.ell(11.6, 1.6, 1.5, 1.5, '#ffffff'); });
      if (f === 2) { g.px([[7, 2], [8, 2], [11, 2], [12, 2]], INK); } else { g.px([[8, 1], [8, 2], [12, 1], [12, 2]], INK); }
      g.px([[4, 5], [14, 4]].filter(([x, y]) => g.filled(x, y)), '#f4a3b8');
    },
    moonlotus(g, f) { lily(g, f, ['#fff4ff', '#e4c8f8', '#a88ad8'], ['#6ad0a8', '#2f8f78', '#1f5a50'], '#fff27a'); },
    // ----- candy -----
    lollibloom(g, f) {
      g.rect(9, 11, 1, 5, '#fff4f8'); g.px([[9, 12], [9, 14]], '#f07aa0');
      g.ell(5.8, 13, 2.2, 1.1, ['#c8fff0', '#7ee4c4', '#3fa890'], f === 1 ? -0.8 : 0.4); g.ell(12.8, 13.4, 2.2, 1.1, ['#c8fff0', '#7ee4c4', '#3fa890'], f === 1 ? 0.8 : -0.4);
      g.ell(7.4, 16.2, 1.5, 0.8, '#f07aa0'); g.ell(11.2, 16.2, 1.5, 0.8, '#f07aa0');
      g.ell(9.4, 6, 5.6, 5.6, '#fff');
      g.outline();
      const ph = f === 1 ? 0.6 : 0;
      for (let y = 0; y < 13; y++) for (let x = 2; x < 17; x++) if (g.get(x, y) === '#fff') { const dx = x + 0.5 - 9.4, dy = y + 0.5 - 6, a = Math.atan2(dy, dx), r = Math.hypot(dx, dy); const b = Math.floor(((a / (2 * Math.PI)) * 2 + r * 0.55 + ph) % 2 + 2) % 2; g.set(x, y, b ? '#ffffff' : (dx + dy > 3 ? '#d04a7a' : '#f07aa0')); }
      g.ell(10, 6.6, 2.6, 2, '#fff4f8', 0, (x, y) => g.filled(x, y));
      pEyes(g, 8, 11, 4, f === 2); pSmile(g, 8, 7, 4); pCheeks(g, 7, 12, 7);
    },
    marshroom(g, f) {
      const sq = f === 1 ? 1 : 0, M = ['#ffffff', '#ffe6f0', '#e4a8c4'];
      g.ell(6.8, 15.9, 1.7, 1, '#f7b6c8'); g.ell(11.4, 15.9, 1.7, 1, '#f7b6c8');
      g.ell(9, 12.2, 4.6, 3.4, ['#ffe0ec', '#f7b6c8', '#d07aa0']);
      for (const [x, r] of [[4.4, 3], [9, 3.8], [13.6, 3]]) g.ell(x, 7 + sq + (x === 9 ? -1 : 0), r + sq * 0.3, r - sq * 0.4, M);
      g.outline();
      g.px([[5, 6 + sq], [10, 4 + sq], [13, 7 + sq], [8, 8 + sq]].filter(([x, y]) => g.filled(x, y)), '#e0b080'); g.px([[6, 6 + sq], [11, 4 + sq]].filter(([x, y]) => g.filled(x, y)), '#c8905a');
      g.set(7, 4 + sq, '#ffffff');
      pEyes(g, 7, 10, 11, f === 2); g.px([[8, 14], [9, 14]], INK); pCheeks(g, 6, 11, 13);
    },
    licovine(g, f) {
      const w = f === 1 ? 1 : 0;
      stroke(g, [[5, 16.4], [7, 13.6], [5.4 + w, 11], [8, 9]], 1.4, 1.2, '#fff');
      stroke(g, [[12, 16.4], [11, 14], [13 - w, 12.4], [14.6, 13.4], [15.4 - w, 11.6]], 1, 0.8, '#fff');
      g.ell(10.6, 6.4, 4.4, 4.2, '#d24552');
      stroke(g, [[13.4, 3.6], [15.2, 1.8 + w], [16.6, 2.4], [16, 3.8]], 0.6, 0.5, '#fff');
      g.outline();
      const Rd = ['#ff8a90', '#e0303e', '#901c30'], Bk = ['#6a5a70', '#3a2e44', '#2a2034'];
      for (let y = 0; y < 18; y++) for (let x = 0; x < 18; x++) {
        const c = g.get(x, y); if (!c || c === INK) continue;
        const R2 = c === '#fff' ? (Math.floor((x - y * 0.7 + 20) / 1.5) % 2 ? Bk : Rd) : ['#ff9aa0', '#e0303e', '#a01c34'];
        const top = g.get(x, y - 1) === INK, bot = g.get(x, y + 1) === INK;
        g.set(x, y, top && !bot ? R2[0] : bot && !top ? R2[2] : R2[1]);
      }
      g.set(8, 4, '#ffffff'); g.set(9, 3, '#ffb0b8');
      pEyes(g, 10, 13, 4, f === 2); pSmile(g, 10, 7, 4); pCheeks(g, 9, 14, 7, '#ffb0c8');
    },
    sugarlily(g, f) { lily(g, f, ['#ffffff', '#ffd8ec', '#f07aa8'], ['#c8fff0', '#7ee4c4', '#3fa890'], '#5fcde4'); g.px([[3, 11], [15, 11]].filter(([x, y]) => g.filled(x, y)), '#fff27a'); },
    // Pea Popper: a round pod head with a tube snout that puffs peas (frame 1 = cheeks puffed, pea in the snout)
    peapod(g, f) {
      const PG = ['#c6f48a', '#6cc84a', '#3a8a3e'], puff = f === 1, lean = puff ? -0.5 : 0;
      stroke(g, [[8, 17], [8.4, 14], [7.8, 11.4]], 0.9, 0.8, '#4f9a3e');
      g.ell(5, 15.6, 2.7, 1.1, LEAFG, 0.4); g.ell(11.2, 15.8, 2.7, 1.1, LEAFG, -0.4);
      piece(g, t => t.ell(3.6 + lean, 3.4, 2.2, 1.1, LEAFG, -0.8));
      g.ell(7.8 + lean, 7.4, 4.8, 4.5, PG);
      g.ell(12.6 + lean, 7.4, 3, puff ? 2.3 : 1.9, PG);
      piece(g, t => t.ell(15.4 + lean, 7.4, 1.4, puff ? 2.6 : 2.3, PG));
      g.outline();
      const hx = Math.round(15.4 + lean);
      for (let y = 6; y <= 8; y++) if (g.filled(hx, y)) g.set(hx, y, '#1f4a2a');
      if (puff && g.filled(hx, 7)) g.set(hx, 7, '#b8f07a');
      g.px([[5, 4], [6, 4]].filter(([x, y]) => g.filled(x, y)), '#e8ffc8');
      const ex = Math.round(7 + lean); pEyes(g, ex, ex + 3, 6, f === 2); pCheeks(g, ex - 1, ex + 3, 9, puff ? '#f07a84' : '#f4a3b8');
      g.px([[3, 15], [12, 16]].filter(([x, y]) => g.filled(x, y)), '#d4f8a8');
    },
  };
  const PLANT_FRAMES = 3;
  // number of animation frames a critter has (living plants have 3; animals 1)
  const critterFrames = kind => (PLANTS[kind] ? PLANT_FRAMES : 1);
  // PX.critter(id) is frame 0; PX.critter(id, f) gives another animation frame (unknown frames fall back to 0)
  function critter(kind, frame) {
    const f = PLANTS[kind] && frame > 0 && frame < PLANT_FRAMES ? frame | 0 : 0, key = f ? kind + ':' + f : kind;
    if (critterCache[key]) return critterCache[key];
    const D = window.PSDATA || {}, rare = !!(D.RARES && D.RARES[kind]) || ['dragon', 'unicorn', 'kitsune', 'yeti', 'griffin', 'dinosaur', 'kraken', 'phoenix', 'fairy'].includes(kind);
    let c;
    const fn = PLANTS[kind] || CR[kind];
    if (fn) { const g = new Grid(rare ? 26 : 18, rare ? 26 : 18); g.spec = !!PLANTS[kind]; try { fn(g, f); c = g.canvas(); } catch (e) { console.error('PX.critter', kind, e); } }
    return (critterCache[key] = c || (f ? critter(kind) : genericCritter(kind)));
  }
  // Fallback critter for unknown ids: shaped by where it lives, tinted by its element.
  const EL_RAMP = { leaf: 'leaf', water: 'sky', fire: 'clay', stone: 'slate', sky: 'cloud', shadow: 'night', light: 'sun', sweet: 'rose', normal: 'peach' };
  function genericCritter(id) {
    const D = window.PSDATA || {}, a = (D.ANIMALS && D.ANIMALS[id]) || (D.RARES && D.RARES[id]) || null;
    const rare = !!(a && a.rare), S = rare ? 26 : 18, k = S / 18;
    const g = new Grid(S, S), R = RAMPS[EL_RAMP[a ? a.el : 'normal']] || RAMPS.peach, where = a ? a.where : 'land';
    if (where === 'water') {
      g.poly([[3 * k, 6 * k], [6 * k, 10 * k], [3 * k, 14 * k]], R[2]); g.ell(10 * k, 10 * k, 6 * k, 4 * k, R);
      g.outline(); g.set(Math.round(13 * k), Math.round(9 * k), INK);
    } else if (where === 'air') {
      g.ell(8 * k, 11 * k, 4.6 * k, 3.6 * k, R); g.ell(12 * k, 7.5 * k, 2.9 * k, 2.7 * k, R); g.ell(6.5 * k, 9.5 * k, 3 * k, 2 * k, R[0], -0.5);
      g.poly([[14.5 * k, 7 * k], [17 * k, 8 * k], [14.5 * k, 9 * k]], '#f6c83a');
      g.outline(); g.set(Math.round(12.5 * k), Math.round(7 * k), INK);
    } else {
      g.ell(8 * k, 11.5 * k, 5 * k, 3.6 * k, R); g.ell(13 * k, 8 * k, 3.2 * k, 3 * k, R); g.ell(11.6 * k, 4.8 * k, 1.1 * k, 1.6 * k, R[2]);
      g.rect(Math.round(5 * k), Math.round(14 * k), Math.max(1, Math.round(k)), S - 1 - Math.round(14 * k), R[2]); g.rect(Math.round(10 * k), Math.round(14 * k), Math.max(1, Math.round(k)), S - 1 - Math.round(14 * k), R[2]);
      g.outline(); g.set(Math.round(14 * k), Math.round(7.5 * k), INK);
    }
    return g.canvas();
  }
  // Swimming version: top ~60% of the critter with a ripple line. Anchor bottom-centre = water surface.
  const swimCache = {};
  function critterSwim(kind, frame) {
    const f = PLANTS[kind] && frame > 0 && frame < PLANT_FRAMES ? frame | 0 : 0, key = f ? kind + ':' + f : kind;
    if (swimCache[key]) return swimCache[key];
    // (worked in fine pixels: K fine pixels per art pixel)
    const c = critter(kind, f), K = c.k || 1, w = c.width, h = c.height, d = c.getContext('2d').getImageData(0, 0, w, h).data;
    let top = h, bot = 0;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3]) { top = Math.min(top, y); bot = Math.max(bot, y); }
    const cut = Math.round(Math.max(top + 3 * K, Math.round(top + (bot - top) * 0.62)) / K) * K;
    let x0 = w, x1 = 0;
    for (let y = cut - 2 * K; y < cut; y++) for (let x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3]) { x0 = Math.min(x0, x); x1 = Math.max(x1, x); }
    const o = document.createElement('canvas'); o.width = w; o.height = cut + 2 * K;
    const x = o.getContext('2d'); x.drawImage(c, 0, 0, w, cut, 0, 0, w, cut);
    x.fillStyle = '#ffffff'; for (let i = Math.max(0, x0 - 2 * K); i <= Math.min(w - 1, x1 + 2 * K); i++) if (Math.floor((i - x0) / K) % 4 !== 3) x.fillRect(i, cut, 1, K);
    x.fillStyle = '#9fd8ff'; for (let i = Math.max(0, x0); i <= Math.min(w - 1, x1); i++) if (Math.floor((i - x0) / K) % 4 < 2) x.fillRect(i, cut + K, 1, K);
    x.fillStyle = '#cbe8ff'; x.fillRect(Math.max(0, x0 - K), cut - K, K, K); x.fillRect(Math.min(w - K, x1 + 1), cut - K, K, K);
    return (swimCache[key] = keepK(c, o));
  }

  // ---------------- Items (fruit 13x13, egg 20x24, coin 9x9, bigcoin 11x11, xp 9x9, element 7x7, flower 12x12) ----------------
  const itemCache = {};
  function item(kind, id) {
    const key = kind + ':' + id; if (itemCache[key]) return itemCache[key];
    let g;
    try { g = (ITEM[kind] || ITEM.unknown)(id); } catch (e) { console.error('PX.item', kind, id, e); g = ITEM.unknown(); }
    return (itemCache[key] = g instanceof Grid ? g.canvas() : g);
  }
  function eggShape(g, ramp) {
    const pts = [];
    for (let y = 0; y < 24; y++) for (let x = 0; x < 20; x++) {
      const dy = (y + 0.5 - 13) / 10, wf = dy < 0 ? 1 + 0.2 * dy : 1 - 0.04 * dy, dx = (x + 0.5 - 10) / (7.4 * wf);
      if (dx * dx + dy * dy <= 1) { g.set(x, y, ramp === SKIN_SENT ? shadeOf(ramp, dx, dy) : shadeDith(ramp, dx, dy, x, y, 0.07)); pts.push([x, y, dx, dy]); }
    }
    return pts;
  }
  const FRUIT_ART = { // 13 x 13 chunky pastel fruit (art-core.js adds melon and plantfood)
    apple(g) {
      const R = ['#ffe2e4', '#ff9ea6', '#ee7c88'];
      piece(g, t => { stroke(t, [[6.5, 4.6], [6.8, 2.6], [7.6, 1.6]], 0.5, 0.45, '#b8906c'); });
      piece(g, t => { t.ell(4.7, 7.2, 3.4, 3.6, R[1]); t.ell(8.3, 7.2, 3.4, 3.6, R[1]); t.ell(6.5, 9, 3.6, 2.7, R[1]); kShade(t, 6.5, 7.6, 5.2, 4.6, R); });
      piece(g, t => t.ell(9.2, 2.6, 1.9, 0.95, kFlat(['#e2f8c4', '#a6dc7e', '#84c062']), -0.45));
      g.outerLine();
    },
    sunpear(g) {
      const R = ['#fffbe0', '#ffe486', '#f4c662'];
      piece(g, t => stroke(t, [[6.6, 3.6], [6.8, 1.6]], 0.45, 0.45, '#b8906c'));
      piece(g, t => { t.ell(6.5, 8.6, 4, 3.5, R[1]); t.ell(6.3, 5.2, 2.4, 2.6, R[1]); kShade(t, 6.5, 7.2, 4.4, 5, R); });
      piece(g, t => t.ell(8.6, 2.4, 1.6, 0.85, kFlat(['#e2f8c4', '#a6dc7e', '#84c062']), -0.35));
      g.ell(7.6, 9.2, 0.9, 0.5, '#ffd0b0', 0, kIN(g));
      g.outerLine();
    },
    moonplum(g) {
      const R = ['#f4eaff', '#c8a8f0', '#a888d8'];
      piece(g, t => stroke(t, [[6.4, 3.2], [6.6, 1.4]], 0.45, 0.45, '#b8906c'));
      piece(g, t => { t.ell(6.5, 7.4, 4.3, 4.4, R[1]); t.ell(5.4, 6.6, 3, 3.4, R[1]); kShade(t, 6.5, 7.2, 4.6, 4.6, R); });
      stroke(g, [[7.2, 4.4], [7.6, 7.2], [7.2, 10.2]], 0.2, 0.2, R[2]);
      g.ell(4.6, 8.4, 1.2, 1.2, '#fff4b0', 0, kIN(g)); g.ell(5.2, 8, 1.0, 1.0, R[1], 0, kIN(g));
      g.outerLine();
      kTw(g, 11.6, 2.4, '#fff4b0');
    },
    swiftberry(g) {
      const R = ['#ffeedd', '#ffb486', '#f29468'];
      piece(g, t => { t.ell(4.4, 8.6, 2.6, 2.6, R[1]); t.ell(8.6, 8.6, 2.6, 2.6, R[1]); kShade(t, 6.5, 8.6, 4.8, 2.8, R); });
      piece(g, t => kSoft(t, 6.5, 5.6, 2.6, 2.6, R));
      piece(g, t => { t.ell(5.2, 2.6, 1.6, 0.8, '#a6dc7e', -0.5); t.ell(7.8, 2.6, 1.6, 0.8, '#a6dc7e', 0.5); });
      g.outerLine();
    },
    wingseed(g) {
      const WG = ['#ffffff', '#f2f6ff', '#d4dcf0'], S = ['#fbe8cc', '#e6c08e', '#cca070'];
      piece(g, t => { t.ell(3, 5.4, 2.6, 1.5, kFlat(WG), -0.55); t.ell(10, 5.4, 2.6, 1.5, kFlat(WG), 0.55); });
      piece(g, t => { kDrop(t, 6.5, 8.2, 2.7, 3, 2.2, 0, S[1]); kShade(t, 6.5, 7.6, 3, 4, S); });
      g.outerLine();
    },
    seakelp(g) {
      const K = ['#e0faf0', '#8ee0c0', '#6cc4a4'], K2 = ['#d8f6e4', '#72cca8', '#56b08e'];
      piece(g, t => { stroke(t, [[7.6, 11.2], [8.8, 8.6], [7.6, 6.2], [8.6, 4]], 1.25, 0.95, K2[1]); kShade(t, 8.2, 7.6, 1.6, 4, K2, { hl: false }); });
      piece(g, t => { stroke(t, [[4.8, 11.2], [3.6, 8.4], [5.2, 5.4], [4.2, 2.6]], 1.45, 1.05, K[1]); kShade(t, 4.4, 7, 1.8, 4.6, K); });
      piece(g, t => t.ell(10.6, 2.8, 1.25, 1.25, '#f0fbff'));
      g.dot(10.2, 2.4, '#ffffff');
      g.outerLine();
    },
    powernut(g) {
      const N = ['#fff0dc', '#f2c48e', '#dca46e'], C = ['#ecd2b4', '#c49a72', '#a8805c'];
      piece(g, t => { kDrop(t, 6.5, 7.8, 3.6, 3.6, 0, 0, N[1]); t.poly([[4.6, 10.4], [8.4, 10.4], [6.5, 12.2]], N[1]); kShade(t, 6.5, 8.4, 3.8, 3.8, N); });
      piece(g, t => { t.ell(6.5, 5.2, 4.6, 2.5, C[1], 0, (x, y) => y <= 5.8); kRect(t, 1.9, 4.6, 11.1, 6, 0.7, C[1]); kShade(t, 6.5, 4.8, 4.6, 1.8, C, { hl: false }); });
      piece(g, t => stroke(t, [[6.5, 2.8], [6.8, 1.2]], 0.42, 0.42, '#a8805c'));
      for (const x of [3.6, 5.6, 7.6, 9.6]) g.dot(x, 4.8, C[2]);
      g.outerLine();
    },
    heartyroot(g) {
      const R = ['#fff2f8', '#f6c4dc', '#e2a2c0'], L = ['#e2f8c4', '#a6dc7e', '#84c062'];
      piece(g, t => { t.ell(4.6, 3.4, 1.1, 2.3, kFlat(L), -0.4); t.ell(6.5, 2.8, 1.1, 2.5, kFlat(L), 0); t.ell(8.4, 3.4, 1.1, 2.3, kFlat(L), 0.4); });
      piece(g, t => { t.ell(6.5, 8, 4, 3.4, R[1]); t.poly([[5.4, 10.4], [7.6, 10.4], [6.6, 12.4]], R[1]); kShade(t, 6.5, 8, 4.2, 3.8, R); });
      g.ell(6.5, 6, 2.6, 0.8, '#e890b8', 0, kIN(g));
      g.outerLine();
    },
    goldfruit(g) {
      const R = ['#fffbe0', '#ffd866', '#f0b44a'];
      piece(g, t => stroke(t, [[6.5, 4.6], [6.8, 2.6], [7.6, 1.6]], 0.5, 0.45, '#b8906c'));
      piece(g, t => { t.ell(4.7, 7.2, 3.4, 3.6, R[1]); t.ell(8.3, 7.2, 3.4, 3.6, R[1]); t.ell(6.5, 9, 3.6, 2.7, R[1]); kShade(t, 6.5, 7.6, 5.2, 4.6, R); });
      piece(g, t => t.ell(9.2, 2.6, 1.9, 0.95, kFlat(['#e2f8c4', '#a6dc7e', '#84c062']), -0.45));
      g.dots([[4, 6], [4.5, 5.5], [4, 6.5]], '#ffffff');
      g.outerLine();
      kTw(g, 1, 2.6, '#ffe680'); kTw(g, 12, 10.8, '#ffe680');
    },
  };
  const EGG_ART = {
    meadow(g) {
      const e = eggShape(g, ['#fffdf4', '#f4ecd4', '#c8bc98']);
      const on = MK(g);
      g.ell(7, 9, 2.2, 2.2, '#6abe30', 0, on); g.ell(13, 16, 2.8, 2.4, '#6abe30', 0, on); g.ell(13.5, 7, 1.4, 1.4, '#99e550', 0, on); g.ell(6, 17, 1.5, 1.3, '#99e550', 0, on);
      g.outline(); g.px([[6, 8], [12, 15]], '#99e550'); g.px([[5, 6], [5, 7], [6, 5]], '#ffffff'); void e;
    },
    beach(g) {
      const e = eggShape(g, ['#fff8e0', '#f4dca8', '#c8a468']);
      for (const [x, y, dx] of e) { const w = 13 + Math.round(Math.sin(x * 0.9) * 1.1); if (y === w - 1) g.set(x, y, '#ffffff'); else if (y >= w && y <= w + 2) g.set(x, y, dx > 0.5 ? '#3f7fc0' : '#5fa8e8'); else if (y > w + 2 && y <= w + 4) g.set(x, y, '#9fd8ff'); }
      g.outline(); g.px([[7, 19], [8, 19], [7, 20]], '#f7b6c8'); g.px([[5, 6], [5, 7], [6, 5]], '#ffffff'); g.px([[12, 8], [9, 5]], '#e8c888');
    },
    moonlit(g) {
      eggShape(g, ['#8c9cf0', '#4a4aa0', '#2c2c66']);
      for (let y = 0; y < 24; y++) for (let x = 0; x < 20; x++) if (Math.hypot(x + 0.5 - 8, y + 0.5 - 11) < 3.2 && Math.hypot(x + 0.5 - 9.6, y + 0.5 - 10) >= 2.8) g.set(x, y, '#fff27a');
      g.outline(); g.px([[13, 7], [5, 17], [14, 16], [11, 20], [6, 6]], '#ffffff'); g.px([[13, 12], [12, 13], [13, 13], [14, 13], [13, 14]], '#dcd0ff'); g.px([[4, 11]], '#9fd8ff');
    },
    candy(g) {
      const e = eggShape(g, ['#fff4fa', '#ffd0e4', '#e090b8']);
      for (const [x, y, dx] of e) if ((((x + y) % 6) + 6) % 6 < 2) g.set(x, y, dx > 0.45 ? '#c8487a' : '#f06a98');
      g.outline(); g.px([[5, 6], [5, 7], [6, 5]], '#ffffff'); g.px([[9, 10], [13, 18]], '#5fcde4'); g.px([[12, 6], [7, 16]], '#fbf236'); g.px([[10, 14]], '#99e550');
    },
    // ---- Halloween eggs ----
    pumpkin(g) {
      const e = eggShape(g, PUMPKIN);
      for (const [x, y, dx, dy] of e) { const u = Math.abs(dx / Math.sqrt(Math.max(0.12, 1 - dy * dy))); if (Math.abs(u - 0.4) < 0.09 || Math.abs(u - 0.8) < 0.07) g.set(x, y, dx > 0.2 ? '#a84a1a' : '#d0661c'); }
      g.rect(9, 0, 2, 4, '#7a4a2a'); g.ell(13, 2.2, 2.4, 1.1, RAMPS.leaf, -0.3);
      g.outline();
      g.px([[5, 7], [5, 8], [6, 6]], '#ffe4b8'); g.set(9, 0, '#a8703a'); g.px([[12, 2], [13, 2]], '#99e550'); g.px([[7, 3], [6, 2], [6, 1]].filter(([x, y]) => !g.get(x, y)), '#6abe30');
    },
    ghost(g) {
      eggShape(g, GHOST);
      g.outline('#6e5ca8');
      g.px([[7, 11], [7, 12], [12, 11], [12, 12]], INK); g.set(7, 11, '#8a7ad0'); g.set(12, 11, '#8a7ad0');
      g.px([[9, 14], [10, 14], [9, 15], [10, 15]], INK); g.set(9, 14, '#e07ba0');
      g.px([[5, 13], [6, 13], [13, 13], [14, 13]], '#f7b6c8'); g.px([[5, 6], [5, 7], [6, 5]], '#ffffff');
      for (const [x, y] of [[1, 7], [0, 8], [1, 9], [18, 15], [19, 16], [18, 17], [17, 2], [16, 1]]) if (!g.get(x, y)) g.set(x, y, '#d8ccff');
    },
    mummy(g) {
      const e = eggShape(g, WRAP);
      for (const [x, y] of e) { const f = (((x * 0.55 - y) % 3.1) + 3.1) % 3.1; if (f < 0.6) g.set(x, y, '#8a7456'); else if (f < 1.1) g.set(x, y, WRAP[2]); }
      for (const [x, y] of e) if (y >= 10 && y <= 13 && x >= 4 && x <= 15) g.set(x, y, y === 10 || y === 13 ? WRAP[2] : '#6a5644');
      g.outline();
      for (const cx of [7, 12]) { g.px([[cx - 1, 11], [cx, 11], [cx - 1, 12], [cx, 12]], '#ffffff'); g.set(cx, 12, INK); g.set(cx - 1, 12, INK); }
      g.px([[16, 17], [17, 18], [17, 19], [18, 20]].filter(([x, y]) => !g.get(x, y)), WRAP[1]); g.px([[5, 6], [6, 5]], '#ffffff');
    },
    candycorn(g) {
      const T = ['#0a0a01', '#0a0a02', '#0a0a03'], e = eggShape(g, T);
      for (const [x, y] of e) { const i = T.indexOf(g.get(x, y)); if (i < 0) continue; const b = y + ((x + y) & 1 ? 0.4 : -0.4); g.set(x, y, (b < 9 ? CORN[0] : b < 16 ? CORN[1] : CORN[2])[i]); }
      g.outline(); g.px([[5, 6], [5, 7], [6, 5]], '#ffffff'); g.px([[5, 11], [5, 12]], '#ffe0a8');
    },
    vampire(g) {
      const e = eggShape(g, VAMP[0]);
      g.outline();
      g.ell(13.6, 6.6, 1.9, 1.9, ['#fffbd0', '#fff27a', '#e8c840']); g.ell(14.6, 5.8, 1.5, 1.5, VAMP[0][1]);
      const bat = ['k...k.k...k', 'kk..kkk..kk', 'kkkkkkkkkkk', '.kkk.k.kkk.', '..k.....k..'];
      bat.forEach((row, j) => { for (let i = 0; i < row.length; i++) if (row[i] === 'k') g.set(5 + i, 10 + j, '#c9a2f0'); });
      g.px([[9, 11], [11, 11]], '#fff27a');
      for (const [x, y] of e) { const d = Math.abs(x + 0.5 - 10); if (y >= 17 && y <= 22 && d > 2.2 && y < 23 - (d - 2.2) * 0.5 && y > 16 + (7 - d) * 0.9) g.set(x, y, d < 3.8 ? '#e8506a' : '#b02846'); }
      g.px([[5, 6], [5, 7], [6, 5]], '#9a88c8'); g.px([[4, 15], [15, 16], [7, 4]], '#fff27a');
    },
    witch(g) {
      const e = eggShape(g, WITCH[0]);
      for (const [x, y] of [[6, 12], [13, 16], [8, 19], [14, 9]]) g.px([[x, y], [x - 1, y], [x + 1, y], [x, y - 1], [x, y + 1]].filter(([a, b]) => g.filled(a, b)), '#fff27a');
      g.px([[11, 13], [5, 17], [15, 20], [9, 7]].filter(([a, b]) => g.filled(a, b)), '#ffffff');
      const H = new Grid(20, 24); H.poly([[6.6, 4.4], [13.4, 4.4], [12.2, 1.6], [14.6, 0.2], [10.6, 0.8], [8.4, 3]], '#6c3eb0'); H.rect(8, 3, 4, 1, '#ff9a22'); H.ell(10, 4.6, 6, 1.1, '#43206e'); H.outline();
      g.outline(); g.merge(H); g.set(10, 3, '#fbf236'); g.px([[5, 7], [6, 6]], '#e4d0ff'); void e;
    },
    golden(g) {
      const e = eggShape(g, RAMP_X.gold);
      for (const [x, y] of e) { const z = 13 + (x % 4 < 2 ? x % 2 : 1 - x % 2); if (y === z || y === z + 3) g.set(x, y, '#fff27a'); }
      g.outline(); g.px([[9, 14], [10, 14], [9, 15], [10, 15]], '#d24552'); g.px([[5, 15], [14, 15]], '#5fcde4');
      g.px([[5, 6], [5, 7], [6, 5], [4, 8], [4, 9]], '#ffffff');
      g.px([[1, 4], [0, 5], [2, 5], [1, 6]], '#fff27a'); g.px([[18, 17], [17, 18], [19, 18], [18, 19]], '#fff27a'); g.px([[16, 2]], '#ffffff');
    },
    rainbow(g) {
      const e = eggShape(g, RAMPS.cloud);
      const Lc = ['#ffb0b8', '#ffc890', '#fff8a0', '#c8f090', '#a8ecf8', '#d8b8f8'], Mc = ['#f07a84', '#f6a83a', '#fbf236', '#99e550', '#5fcde4', '#9a6ad0'], Dc = ['#d24552', '#df7126', '#c7a81c', '#4fae3a', '#3f8fc0', '#6a3a9e'];
      for (const [x, y, dx] of e) { const b = Math.max(0, Math.min(5, Math.floor((y - 3 + x * 0.3) / 3.3))); g.set(x, y, dx < -0.55 ? Lc[b] : dx > 0.5 ? Dc[b] : Mc[b]); }
      g.outline(); g.px([[5, 6], [5, 7], [6, 5], [4, 9]], '#ffffff'); g.px([[1, 3], [18, 20]], '#fff27a');
    },
    crystal(g) {
      const e = eggShape(g, ['#f4feff', '#c8ecfa', '#8ab8e0']);
      const pal = ['#e8fbff', '#bfe2f8', '#d8ccf8', '#a8d0f0', '#f4f0ff', '#9cc4ec'];
      const facet = (x, y) => { const a = Math.atan2(y + 0.5 - 12, x + 0.5 - 10), r = Math.hypot((x + 0.5 - 10) / 7, (y + 0.5 - 12) / 9.5); return Math.floor((a + Math.PI) / (Math.PI / 3) + (r > 0.55 ? 0.5 : 0)) % 6 + (r > 0.55 ? 6 : 0); };
      for (const [x, y] of e) { const f = facet(x, y); g.set(x, y, pal[f % 6]); }
      for (const [x, y] of e) { const f = facet(x, y); if ((g.filled(x + 1, y) && facet(x + 1, y) !== f) || (g.filled(x, y + 1) && facet(x, y + 1) !== f)) g.set(x, y, '#ffffff'); }
      g.outline(); g.px([[1, 6], [0, 7], [2, 7], [1, 8]], '#ffffff'); g.px([[17, 15], [18, 16]], '#c9a2f0'); g.px([[15, 3]], '#9fd8ff');
    },
    dragon(g) {
      const e = eggShape(g, RAMPS.berry);
      for (const [x, y] of e) { const row = Math.floor(y / 3); if (y % 3 === 2 && ((x + (row % 2) * 2) % 4) !== 0) g.set(x, y, '#9a2c3c'); }
      g.poly([[5.6, 6.4], [8.2, 4.2], [4, 1.4]], '#fbe0a0'); g.poly([[14.4, 6.4], [11.8, 4.2], [16, 1.4]], '#fbe0a0'); g.poly([[8.8, 4], [11.2, 4], [10, 1.2]], '#f6c83a');
      g.outline(); g.px([[5, 6], [5, 7], [6, 5]], '#ffb0b8'); g.px([[8, 12], [10, 16], [6, 18]], '#f6c83a');
    },
    // ---- special eggs (2026) ----
    eclipse(g) { // sunny gold with a starry night crescent, joined by a glowing seam
      const e = eggShape(g, ECL.sun);
      const side = (x, y) => Math.hypot(x + 0.5 - 4.2, (y + 0.5 - 12.8) * 0.72) - 7.2; // < 0: sunny side
      for (const [x, y, dx, dy] of e) {
        if (side(x, y) < 0) { if (side(x + 1, y) >= 0) g.set(x, y, dy > 0.45 ? ECL.dusk[2] : ECL.dusk[1]); continue; }
        if (side(x - 1, y) < 0 || side(x, y - 1) < 0 || side(x, y + 1) < 0) g.set(x, y, ECL.seam);
        else if (side(x - 2, y) < 0) g.set(x, y, ECL.night[0]);
        else g.set(x, y, dx > 0.62 || dy > 0.72 ? ECL.night[2] : ECL.night[1]);
      }
      g.outline();
      g.px([[5, 12], [6, 12], [7, 12], [5, 13], [7, 13], [5, 14], [6, 14], [7, 14]], '#fff6b0'); g.set(6, 13, '#ffffff'); // a little sun...
      g.px([[6, 10], [6, 16], [3, 13], [9, 13], [4, 11], [8, 11], [4, 15], [8, 15]], '#e27a26');
      g.px([[14, 7], [13, 8], [13, 9], [14, 10]], '#fff6b0'); g.set(15, 7, '#fff6b0'); // ...and a tiny crescent moon
      g.px([[12, 18], [15, 15], [16, 11]], '#ffffff'); g.px([[13, 13], [11, 21]], '#fff27a'); g.px([[15, 3], [14, 4], [16, 4], [15, 5]], '#c9d0ff'); g.set(15, 4, '#ffffff');
      g.px([[5, 6], [5, 7], [6, 5]], '#ffffff');
      g.px([[1, 4], [0, 5], [2, 5], [1, 6]], '#fff27a'); g.px([[18, 17], [17, 18], [19, 18], [18, 19]], '#c9d0ff'); g.px([[16, 1]], '#ffffff');
    },
    starry(g) { // deep indigo with a soft nebula band and twinkly stars
      const e = eggShape(g, GAL);
      for (const [x, y] of e) {
        const t = GAL.indexOf(g.get(x, y)), v = (y + 0.5 - 13) + (x + 0.5 - 10) * 0.8;
        if (Math.abs(v) < 1.3) g.set(x, y, NEB[Math.max(0, t)]);
        else if (Math.abs(v) < 2.8 && (x + y) & 1) g.set(x, y, NEB[Math.min(2, Math.max(0, t) + 1)]);
      }
      g.outline();
      for (const [cx, cy] of [[7, 8], [13, 16]]) { g.px([[cx - 1, cy], [cx + 1, cy], [cx, cy - 1], [cx, cy + 1]], '#b8c4ff'); g.set(cx, cy, '#ffffff'); }
      g.px([[12, 6], [5, 15], [15, 11], [9, 19], [11, 10], [6, 18]], '#ffffff'); g.px([[14, 8], [8, 13], [12, 20]], '#fff6b0'); g.px([[4, 11], [15, 18]], '#b8f0ff');
      g.px([[5, 6], [6, 5]], '#9a8ef0');
      g.px([[17, 2], [16, 3], [18, 3], [17, 4]], '#fff6b0'); g.set(17, 3, '#ffffff'); g.px([[1, 16], [2, 9]], '#c9a2f0'); g.px([[18, 12]], '#b8f0ff');
    },
    frost(g) { // icy blue under a snowy cap, with a snowflake and frosty glints
      const e = eggShape(g, FROST);
      const capAt = x => 7.2 + Math.sin(x * 1.25 + 0.4) * 0.9;
      for (const [x, y] of e) { const cap = capAt(x); if (y + 0.5 < cap) g.set(x, y, '#ffffff'); else if (y + 0.5 < cap + 1) g.set(x, y, '#8cc0ea'); }
      g.outline();
      g.px([[5, 9], [12, 9], [12, 10], [15, 9]].filter(([x, y]) => g.filled(x, y)), '#ffffff'); g.px([[12, 11]].filter(([x, y]) => g.filled(x, y)), '#dff4ff'); // icicles
      const fx = 11, fy = 14; // a snowflake
      g.px([[fx, fy - 2], [fx, fy - 1], [fx, fy + 1], [fx, fy + 2], [fx - 2, fy], [fx - 1, fy], [fx + 1, fy], [fx + 2, fy], [fx - 2, fy - 2], [fx + 2, fy - 2], [fx - 2, fy + 2], [fx + 2, fy + 2], [fx - 1, fy - 1], [fx + 1, fy - 1], [fx - 1, fy + 1], [fx + 1, fy + 1]], '#ffffff'); g.set(fx, fy, '#dff4ff');
      for (const [x, y] of [[6, 18], [15, 19]]) g.px([[x, y], [x - 1, y - 1], [x + 1, y - 1], [x - 1, y + 1], [x + 1, y + 1]].filter(([a, b]) => g.filled(a, b)), '#ffffff');
      g.px([[5, 13], [16, 13], [9, 21]].filter(([x, y]) => g.filled(x, y)), '#f0faff');
      g.px([[5, 6], [6, 5]], '#dff4ff');
      g.px([[1, 7], [0, 8], [2, 8], [1, 9]], '#ffffff'); g.px([[18, 16], [17, 17], [19, 17], [18, 18]], '#c8ecfa'); g.px([[16, 2], [3, 19]], '#c8ecfa');
    },
    blossom(g) { // soft spring pink sprinkled with little 5-petal flowers
      const e = eggShape(g, BLOS);
      g.outline();
      const flower = (x, y) => { g.px([[x, y - 1], [x - 1, y], [x + 1, y]], '#ffffff'); g.px([[x - 1, y + 1], [x + 1, y + 1]], '#fff4f8'); g.set(x, y, '#fbf236'); };
      for (const [x, y] of [[7, 8], [13, 11], [6, 15], [12, 18], [10, 4]]) flower(x, y);
      g.px([[10, 13], [16, 15], [8, 20], [4, 11]].filter(([x, y]) => g.filled(x, y)), '#ffe8f2');
      g.px([[5, 6], [6, 5]], '#ffffff');
      g.px([[1, 5], [2, 5], [1, 6]], '#f7b6c8'); g.px([[18, 16], [18, 17]], '#f7b6c8'); g.px([[17, 20], [2, 15]], '#ffd6e6'); g.px([[16, 2]], '#ffffff'); void e;
    },
    pearl(g) { // pearly white with a soft pastel sheen and a bright shine
      const e = eggShape(g, PEARL[0]);
      for (const [x, y, dx, dy] of e) {
        const t = PEARL[0].indexOf(g.get(x, y)), r = Math.hypot(x + 0.5 - 6.5, (y + 0.5 - 8) * 0.8), band = Math.floor(r / 2.4 + ((x + y) & 1) * 0.3) % 4;
        g.set(x, y, PEARL[band][Math.max(0, t)]);
        if (dx > 0.2 && dx < 0.7 && dy > 0.35 && dy < 0.75 && t === 2 && (x + y) & 1) g.set(x, y, PEARL[band][1]); // soft reflected light
      }
      g.outline();
      g.px([[5, 6], [6, 6], [5, 7], [6, 5], [4, 8]], '#ffffff'); g.px([[7, 5], [4, 9]], '#fff8fc');
      g.px([[1, 5], [0, 6], [2, 6], [1, 7]], '#ffffff'); g.px([[18, 16], [18, 17]], '#f7c6de'); g.px([[17, 19], [16, 2]], '#c8d8ff');
    },
  };
  const EL_ICON = {
    leaf: [['....kkk', '..kkLLk', '.kLLLek', 'kLLeeEk', 'kLeeEk.', 'keEEk..', 'kkkk...'], { L: '#99e550', e: '#6abe30', E: '#37946e' }],
    water: [['...k...', '..kak..', '.kwauk.', 'kaauuBk', 'kauuuBk', 'kuuuBBk', '.kkkkk.'], { a: '#9fd8ff', u: '#639bff', B: '#3f55b8', w: '#ffffff' }],
    fire: [['..k....', '.kok.k.', '.koykok', 'kooyyok', 'koyyyok', 'kroyyrk', '.kkkkk.'], { y: '#fff27a', o: '#f6a83a', r: '#d24552' }],
    stone: [['.......', '..kkk..', '.kllmk.', 'klllmmk', 'klmmmdk', 'kmmmddk', '.kkkkk.'], { l: '#d8c8a8', m: '#a8946e', d: '#6a5a40' }],
    sky: [['.......', '..kkk..', '.kwwwkk', 'kwwwwwk', 'kwwaaak', '.kkkkk.', '.......'], { w: '#ffffff', a: '#9fd8ff' }],
    shadow: [['..kkk..', '.kppk..', 'kppk...', 'kpPk...', 'kpPPk.k', '.kqPPqk', '..kkkk.'], { p: '#c9a2f0', P: '#9a6ad0', q: '#5e3a8e' }],
    light: [['...k...', '..kyk..', '.kyyyk.', 'kyywyok', '.kyook.', '..kok..', '...k...'], { y: '#fff27a', o: '#f6c83a', w: '#ffffff' }],
    sweet: [['.kk.kk.', 'kRRkRmk', 'kwRRmmk', 'kRRmmMk', '.kmmMk.', '..kMk..', '...k...'], { R: '#f7b6c8', m: '#e07ba0', M: '#a2477a', w: '#ffffff' }],
    normal: [['..kkk..', '.klllk.', 'klwllmk', 'kllllmk', 'klllmmk', '.kmmmk.', '..kkk..'], { l: '#dfe3ea', m: '#8c93a8', w: '#ffffff' }],
  };
  const ITEM = {
    unknown() { const g = new Grid(9, 9); piece(g, t => kSoft(t, 4.5, 4.5, 3.4, 3.4, ['#f4f2fb', '#d2cde2', '#aea8c4'])); g.outerLine(); return g; },
    coin() { // a round butter-gold coin with a raised star
      const c = new Grid(9, 9), G2 = ['#fffbe0', '#ffd866', '#f0b44a'];
      piece(c, t => kSoft(t, 4.5, 4.5, 3.3, 3.3, G2));
      c.ell(4.5, 4.5, 2.2, 2.2, '#ffe68a', 0, kIN(c)); c.poly(starPts(4.5, 4.7, 1.6, 0.7, 5), '#f6c25a');
      c.dots([[3, 2.6], [2.6, 3]], '#ffffff');
      c.outerLine(); return c;
    },
    bigcoin() { // a little stack of three coins
      const c = new Grid(11, 11), G2 = ['#fffbe0', '#ffd866', '#f0b44a'];
      for (let i = 0; i < 3; i++) { const cy = 8 - i * 2.3; piece(c, t => { t.ell(5.5, cy + 0.7, 4.1, 1.6, G2[2]); t.ell(5.5, cy, 4.1, 1.6, G2[1]); }); }
      c.ell(5.5, 3.4, 2.4, 0.7, '#ffe68a', 0, kIN(c)); c.dots([[3, 3], [3.5, 3]], '#ffffff');
      c.outerLine(); kTw(c, 10, 0.8, '#ffe680'); return c;
    },
    xp() { // a mint orb with a white star
      const c = new Grid(9, 9);
      piece(c, t => kSoft(t, 4.5, 4.5, 3.4, 3.4, ['#e8fad6', '#a8e080', '#86c464']));
      c.poly(starPts(4.5, 4.75, 2.5, 1.1, 5), '#ffffff');
      c.outerLine(); return c;
    },
    fruit(id) { const g = new Grid(13, 13); (FRUIT_ART[id] || FRUIT_ART.apple)(g); return g; },
    egg(id) { const g = new Grid(20, 24); (EGG_ART[id] || EGG_ART.meadow)(g); return g; },
    element(id) { const e = EL_ICON[id] || EL_ICON.normal; return fromStrings(e[0], e[1]); },
    flower(id) { const g = new Grid(12, 12); flowerArt(g, id, 6, 6); g.outline(); flowerDetail(g, id, 6, 6); return g; },
    // 7x7 shiny pastel gumball; id = colour index 0..7
    gumball(id) {
      const n = (((parseInt(id, 10) || 0) % 8) + 8) % 8, R2 = PGUM[n], g = new Grid(7, 7);
      piece(g, t => kSoft(t, 3.5, 3.5, 2.5, 2.5, R2, { hl: false })); g.dot(2.6, 2.4, '#ffffff'); g.dot(3.1, 2.4, '#ffffff'); g.dot(2.6, 2.9, '#ffffff');
      g.outerLine(); return g;
    },
    // 13x13 paint tin in a body colour, paint dripping over the rim
    paint(id) {
      const R2 = RAMPS[id] || RAMPS.mint, M = ['#dfe4ee', '#aab2c2', '#6e7690'], g = new Grid(13, 13);
      g.rect(2, 5, 9, 6, M[1]); g.ell(6.5, 10.6, 4.5, 1.5, M[1]);
      g.ell(6.5, 5, 4.5, 1.7, '#f4f6fa');
      g.outline();
      for (let y = 5; y < 13; y++) for (let x = 0; x < 13; x++) if (g.get(x, y) === M[1]) { if (x <= 3) g.set(x, y, M[0]); else if (x >= 9) g.set(x, y, M[2]); }
      g.ell(6.5, 5, 3.6, 1.1, R2[1], 0, MK(g)); g.set(4, 4, R2[0]); g.set(5, 4, R2[0]);
      for (const [x, y0, n] of [[3, 6, 3], [5, 6, 1], [7, 6, 4], [9, 6, 2]]) for (let y = y0; y < y0 + n; y++) g.set(x, y, y === y0 + n - 1 ? R2[2] : x < 5 ? R2[0] : R2[1]);
      g.px([[4, 6], [8, 6], [6, 6]], R2[1]);
      g.px([[1, 4], [1, 3], [2, 2], [3, 1], [4, 1], [5, 0], [6, 0], [7, 0], [8, 1], [9, 1], [10, 2], [11, 3], [11, 4]], '#595a70');
      return g;
    },
    // 13x13 round sticker showing a body pattern
    pattern(id) {
      const g = new Grid(13, 13), C = '#fbf3dc';
      g.ell(6.5, 6.5, 4.7, 4.7, RAMPS.mint);
      const on = MK(g), put = (pts, c) => g.px(pts.filter(([x, y]) => on(x, y)), c);
      switch (id) {
        case 'spots': put([[4, 4], [5, 4], [4, 5], [8, 5], [8, 6], [9, 5], [5, 8], [6, 8], [9, 9]], C); break;
        case 'stripes': for (let y = 0; y < 13; y++) for (let x = 0; x < 13; x++) if ((x + y) % 4 === 0) put([[x, y]], C); break;
        case 'twotone': for (let y = 0; y < 7; y++) for (let x = 0; x < 13; x++) put([[x, y]], C); break;
        case 'mask': for (let y = 5; y < 8; y++) for (let x = 0; x < 13; x++) put([[x, y]], C); break;
        case 'star': g.poly(starPts(6.5, 6.9, 3.8, 1.6, 5), '#f6c83a'); g.px([[6, 5]], '#fff27a'); break;
        case 'freckles': put([[3, 6], [4, 5], [5, 6], [8, 6], [9, 5], [10, 6], [6, 3]], '#a8653a'); put([[4, 8], [5, 8], [8, 8], [9, 8]], '#f4a3b8'); break;
        case 'heart': g.px([[4, 4], [5, 4], [7, 4], [8, 4], [3, 5], [4, 5], [5, 5], [6, 5], [7, 5], [8, 5], [9, 5], [3, 6], [4, 6], [5, 6], [6, 6], [7, 6], [8, 6], [9, 6], [4, 7], [5, 7], [6, 7], [7, 7], [8, 7], [5, 8], [6, 8], [7, 8], [6, 9]], '#e8608a'); g.px([[4, 5]], '#ffb0c8'); break;
        case 'socks': piece(g, t => t.str(['......ppp', '......www', '......www', '.....wwww', '...wwwwww', '...ppwwwp'], 0, 3, { p: '#f07aa8', w: '#ffffff' })); g.px([[5, 8], [6, 8], [7, 8]], '#dfe8fb'); break;
        case 'zigzag': for (let x = 2; x <= 10; x++) { const y = [7, 6, 5, 6, 7, 6, 5, 6, 7][x - 2]; put([[x, y], [x, y + 1]], C); } break;
        case 'patches': put([[4, 3], [5, 3], [3, 4], [4, 4], [5, 4], [6, 4], [3, 5], [4, 5], [5, 5], [4, 6], [8, 7], [9, 7], [7, 8], [8, 8], [9, 8], [8, 9], [9, 9], [9, 4], [9, 5], [10, 5]], C); break;
        case 'tiger': { const L2 = [[2, 4], [3, 4], [4, 5], [2, 7], [3, 7], [4, 7], [3, 9], [4, 9], [6, 2], [6, 3]]; put(L2.concat(L2.map(([x, y]) => [12 - x, y])), C); break; }
        case 'moonmark': g.px([[6, 3], [7, 3], [8, 3], [5, 4], [6, 4], [7, 4], [4, 5], [5, 5], [6, 5], [4, 6], [5, 6], [4, 7], [5, 7], [6, 7], [5, 8], [6, 8], [7, 8], [6, 9], [7, 9], [8, 9]], '#fbf236');
          g.px([[6, 3], [5, 4], [4, 5], [4, 6], [4, 7]], '#fff6c8'); g.px([[8, 3], [7, 4], [6, 5], [6, 7], [7, 8], [8, 9]], '#f6c83a'); break;
        default: break;
      }
      g.outline('#ffffff'); g.outline();
      return g;
    },
    // 16x14 icon of a hat or extra (same art as on the Sprig)
    hat(id) {
      const h = new Grid(32, 32);
      if (EXTRA_IDS.includes(id)) extraArt(h, id, false); else hatArt(h, id, false, null, true);
      h.outline();
      return cropCentre(h, 16, 14);
    },
    // 13x13 orb in a special skin
    skin(id) {
      const g = new Grid(13, 13);
      g.ell(6.5, 6.5, 5.3, 5.3, SKIN_SENT); g.outline();
      applySkin(g, SKINS[id] ? id : 'gold', 6.5, 6.5, 0.62, id === 'mummy' ? RAMPS.sun : RAMPS.cream);
      g.px([[4, 3], [3, 4]], '#ffffff');
      return g;
    },
  };
  // copy the filled bounding box of g, centred, into a w x h grid (clipped if larger)
  function cropCentre(g, w, h) { // (copies fine pixels, so hi-res detail survives)
    const k = g.k || 1; let x0 = g.w, y0 = g.h, x1 = -1, y1 = -1;
    for (let fy = 0; fy < g.fh; fy++) for (let fx = 0; fx < g.fw; fx++) if (g.fget(fx, fy)) { const x = Math.floor(fx / k), y = Math.floor(fy / k); x0 = Math.min(x0, x); x1 = Math.max(x1, x); y0 = Math.min(y0, y); y1 = Math.max(y1, y); }
    const o = new Grid(w, h, k); if (x1 < 0) return o;
    const ox = Math.floor((w - (x1 - x0 + 1)) / 2) - x0, oy = Math.floor((h - (y1 - y0 + 1)) / 2) - y0;
    for (let fy = y0 * k; fy < (y1 + 1) * k; fy++) for (let fx = x0 * k; fx < (x1 + 1) * k; fx++) { const c = g.fget(fx, fy); if (c) o.fset(fx + ox * k, fy + oy * k, c); }
    return o;
  }

  // ---------------- Gumball machine (40x60, anchor bottom-centre 20,60) ----------------
  // A chunky toy machine: a big glass globe of pastel gumballs, a coral cap and knob, a round body with a coin plate, a crank
  // (frames 0, 1, 2 turn it a third each) and a chute (frame 3: the flap open). Positions match the old machine (chute 16..24, 49..52).
  const PGUM = [['#ffe0e4', '#ff9aa6', '#ec7a8a'], ['#ffeedd', '#ffc08a', '#f2a06c'], ['#fffbe0', '#ffe27a', '#f2c45a'], ['#ecfadc', '#aee68a', '#8ccc6c'],
    ['#e4fbff', '#8ee0f0', '#6cc4dc'], ['#e6efff', '#9ab8f4', '#7a98dc'], ['#f4e8ff', '#c8a4f0', '#a886d8'], ['#ffe8f6', '#ffaad8', '#ec88bc']];
  const gumCache = {};
  function buildGumballMachine(frame) {
    const W = 40, H = 60, g = new Grid(W, H), cx = 20;
    const RED = ['#ffe0e4', '#ff9cac', '#ec7c90'], DRED = ['#ffc8d0', '#f08498', '#d8687e'], MET = ['#ffffff', '#e2e6f0', '#b8c0d2'], GL = ['#ffffff', '#f2fafe', '#d8ecf6'];
    const gcx = 20, gcy = 19.6, grx = 12.6, gry = 12.1;
    // base + body (behind the globe's collar)
    piece(g, t => { kRect(t, 7.2, 52.6, 32.8, 58.6, 2.4, DRED[1]); kShade(t, 20, 55.6, 13, 3.2, DRED, { hl: false }); });
    piece(g, t => { t.poly([[11.6, 32.4], [28.4, 32.4], [30.6, 53.6], [9.4, 53.6]], RED[1]); t.ell(20, 53, 10.6, 1.6, RED[1]); kShade(t, 20, 43, 10.4, 11, RED); });
    // the glass globe with gumballs piled in it
    piece(g, t => {
      t.ell(gcx, gcy, grx, gry, GL[1]);
      const inG = (x, y, r) => inEll(x, y, gcx, gcy, grx - r - 0.3, gry - r - 0.3).in;
      let seed = 11; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
      const balls = [];
      for (let row = 0; row < 7; row++) { const y = 29.4 - row * 3.2; for (let i = -1; i < 10; i++) { const x = 6.4 + (row % 2) * 1.85 + i * 3.7 + (rnd() - 0.5) * 0.5; if (y > 14 - (row > 4 ? 0 : 99) && inG(x, y, 1.6)) balls.push([x, y, PGUM[Math.floor(rnd() * 8)]]); } }
      for (const [x, y, R] of balls) { t.ell(x, y, 1.75, 1.75, R[1]); t.ell(x + 0.5, y + 0.55, 1.2, 1.15, R[2], 0, (xx, yy) => !inEll(xx + 0.25, yy + 0.25, x - 0.3, y - 0.35, 1.7, 1.7).in); t.dot(x - 0.6, y - 0.6, '#ffffff'); }
      kShade(t, gcx, gcy, grx, gry, GL, { only: GL[1], hl: false });
    });
    // a big glass shine
    stroke(g, [[11.4, 15.4], [12.6, 12], [15.2, 9.6]], 0.75, 0.55, '#ffffff'); g.ell(10.9, 18.2, 0.6, 0.8, '#ffffff', 0, kIN(g));
    // collar, cap and knob
    piece(g, t => { kRect(t, 10.4, 30.4, 29.6, 33.6, 1.5, RED[1]); kShade(t, 20, 32, 9.8, 1.8, RED, { hl: false }); });
    piece(g, t => { t.ell(cx, 9.4, 7.6, 3.4, RED[1], 0, (x, y) => y <= 9.6); kRect(t, 12.2, 8.4, 27.8, 10.6, 1, RED[1]); kShade(t, 20, 8.6, 7.8, 2.6, RED); });
    piece(g, t => kSoft(t, cx, 4.6, 2.3, 2.1, RED));
    // coin plate with a slot
    piece(g, t => { kRect(t, 15.6, 34.4, 24.4, 37.6, 1, MET[1]); kShade(t, 20, 36, 4.6, 1.8, MET, { hl: false }); });
    stroke(g, [[18.2, 36], [21.8, 36]], 0.32, 0.32, '#7c849c');
    // crank disk + knob (turns with the frame)
    const ang = ((frame | 0) % 3) * (2 * Math.PI / 3) - Math.PI / 6, dcx = cx, dcy = 42.2, kx = dcx + Math.cos(ang) * 4.6, ky = dcy + Math.sin(ang) * 4.6;
    piece(g, t => kSoft(t, dcx, dcy, 4, 4, MET));
    stroke(g, [[dcx, dcy], [dcx + Math.cos(ang) * 3, dcy + Math.sin(ang) * 3]], 0.42, 0.42, MET[2]);
    piece(g, t => kSoft(t, kx, ky, 1.9, 1.9, ['#fff6c8', '#ffd866', '#f0b44a']));
    // chute with its little flap
    piece(g, t => { kRect(t, 15.6, 48.4, 24.4, 52.4, 1.2, MET[1]); kShade(t, 20, 50.4, 4.6, 2.2, MET, { hl: false }); });
    if (frame === 3) { piece(g, t => kRect(t, 16.8, 49.4, 23.2, 51.6, 0.8, '#6e5a72')); piece(g, t => kRect(t, 16, 51.8, 24, 53.4, 0.7, MET[0])); }
    else { piece(g, t => kRect(t, 16.8, 49.4, 23.2, 51.4, 0.8, MET[0])); stroke(g, [[18.4, 50.4], [21.6, 50.4]], 0.25, 0.25, MET[2]); }
    // a little heart on the body
    g.ell(26.2, 45.4, 0.75, 0.7, '#ffffff', 0, kIN(g)); g.ell(27.4, 45.4, 0.75, 0.7, '#ffffff', 0, kIN(g)); g.poly([[25.5, 45.6], [28.1, 45.6], [26.8, 47.2]], '#ffffff');
    g.outerLine();
    return g;
  }
  function gumballMachine(frame) {
    const f = ((frame | 0) % 4 + 4) % 4;
    if (gumCache[f]) return gumCache[f];
    let c;
    try { c = buildGumballMachine(f).canvas(); } catch (e) { console.error('PX.gumballMachine', e); const g = new Grid(40, 60); g.ell(20, 19, 12, 12, RAMPS.cloud); g.rect(11, 32, 18, 26, RAMPS.berry[1]); g.outline(); c = g.canvas(); }
    return (gumCache[f] = c);
  }

  // ---------------- Fruit (13x13, centre 6.5,6.5) ----------------
  const fruitCache = {};
  function fruit(kind) {
    if (fruitCache[kind]) return fruitCache[kind];
    const g = new Grid(13, 13);
    if (kind === 'sun') { // a smiling butter-yellow sun-star
      const pts = []; for (let i = 0; i < 16; i++) { const r = i % 2 ? 4.1 : 5.6, a = -Math.PI / 2 + i * Math.PI / 8; pts.push([6.5 + Math.cos(a) * r, 6.6 + Math.sin(a) * r]); }
      piece(g, t => { t.poly(pts, '#ffe27a'); kShade(t, 6.5, 6.6, 5.4, 5.4, ['#fffbe0', '#ffe27a', '#f6c45a'], { hl: false }); });
      piece(g, t => kSoft(t, 6.5, 6.6, 3.4, 3.4, ['#fffdf0', '#fff0a8', '#ffd870']));
      kFace(g, 6.8, 6.8, 3.4, { sp: 2.6, w: 1.2, h: 1.6, mouth: 'smile', mw: 1.2, by: 1.2, bsp: 3.6, bw: 0.6 });
    } else if (kind === 'moon') { // a sleepy lilac crescent
      piece(g, t => { t.ell(6.5, 6.5, 4.7, 4.7, '#c8b0f2'); t.ell(9, 4.8, 3.7, 3.7, null); kShade(t, 6, 7, 4.4, 4.4, ['#f2eaff', '#c8b0f2', '#a690d8']); });
      g.outerLine(); kTw(g, 10.6, 9.4, '#fff4b0'); return (fruitCache[kind] = g.canvas());
    } else { // a round pink cherry-apple
      piece(g, t => stroke(t, [[6.5, 4.4], [6.8, 2.4], [7.6, 1.4]], 0.5, 0.45, '#b8906c'));
      piece(g, t => kSoft(t, 6.5, 7.6, 4.2, 4, ['#ffe2e4', '#ff9ea6', '#ee7c88']));
      piece(g, t => t.ell(9.2, 2.4, 1.8, 0.9, kFlat(['#e2f8c4', '#a6dc7e', '#84c062']), -0.45));
    }
    g.outerLine();
    return (fruitCache[kind] = g.canvas());
  }

  // ---------------- Tiny FX sprites (same canvas sizes as before; drawn in fine pixels) ----------------
  const fxCache = {};
  function fx(kind, color) {
    const key = kind + color; if (fxCache[key]) return fxCache[key];
    let g;
    if (kind === 'heart') { g = new Grid(7, 6); piece(g, t => { t.ell(2.1, 2.1, 1.45, 1.4, '#ff9ab4'); t.ell(4.9, 2.1, 1.45, 1.4, '#ff9ab4'); t.poly([[0.75, 2.5], [6.25, 2.5], [3.5, 5.3]], '#ff9ab4'); kShade(t, 3.5, 3, 2.8, 2.4, ['#ffe0ea', '#ff9ab4', '#ec7a9a'], { hl: false }); }); g.dot(2, 1.9, '#ffffff'); }
    else if (kind === 'spark') { g = new Grid(3, 3); const c = color || '#ffe27a'; g.dots([[1, 0.5], [1.5, 0.5], [0.5, 1], [2, 1], [0.5, 1.5], [2, 1.5], [1, 2], [1.5, 2], [1, 1.5], [1.5, 1]], c); g.dots([[1, 1]], '#ffffff'); }
    else if (kind === 'bigspark') { g = new Grid(5, 5); const c = color || '#ffe27a'; g.poly(starPts(2.5, 2.5, 2.5, 0.8, 4), c); g.dots([[2, 2], [2.5, 2], [2, 2.5], [2.5, 2.5]], '#ffffff'); }
    else if (kind === 'drop') { g = new Grid(1, 2); const c = color || '#cbdbfc'; g.dots([[0.5, 0], [0, 0.5], [0.5, 0.5], [0, 1], [0.5, 1], [0, 1.5]], c); g.dot(0, 0.5, '#ffffff'); }
    else if (kind === 'leaf') { g = new Grid(2, 2); g.dots([[1.5, 0], [1, 0.5], [1.5, 0.5], [0.5, 1], [1, 1], [0, 1.5]], '#a6dc7e'); g.dot(0.5, 1.5, '#84c062'); }
    else if (kind === 'shell') { g = new Grid(2, 2); g.dots([[0.5, 0], [1, 0], [0, 0.5], [0.5, 0.5], [1, 0.5], [1.5, 0.5], [0, 1], [0.5, 1], [1, 1], [1.5, 1], [0.5, 1.5], [1, 1.5]], '#ffd8e2'); g.dots([[0.5, 1], [1, 1]], '#f4b4c8'); }
    else if (kind === 'feather') { g = new Grid(3, 2); g.dots([[0, 0], [0.5, 0], [1, 0.5], [1.5, 0.5], [2, 1], [2.5, 1], [0.5, 0.5], [1, 1], [1.5, 1]], '#ffffff'); g.dots([[2.5, 1.5], [2, 1.5]], '#dfe4f2'); }
    else { g = new Grid(1, 1); g.rect(0, 0, 1, 1, color || '#fff'); }
    return (fxCache[key] = g.canvas());
  }

  // ---------------- Props for gardens (anchor bottom-centre) ----------------
  const propCache = {};
  const hsh = (x, y, s) => { let h = Math.imul(x + 31 * (s || 0), 374761393) ^ Math.imul(y + 7, 668265263); h = Math.imul(h ^ (h >>> 13), 1274126177); return ((h ^ (h >>> 16)) >>> 0) / 4294967296; };
  // leafy texture: small lit leaves with a shadow under them, one tone off the local shade
  function foliage(g, R, dens, s) {
    const inR = c => c === R[0] || c === R[1] || c === R[2], out = [];
    for (let y = 1; y < g.h - 1; y++) for (let x = 1; x < g.w - 1; x++) {
      const c = g.get(x, y); if (!inR(c) || hsh(x, y, s) > dens) continue;
      if (!inR(g.get(x, y + 1)) || !inR(g.get(x - 1, y)) || !inR(g.get(x + 1, y)) || !inR(g.get(x, y - 1))) continue;
      const i = R.indexOf(c);
      out.push([x, y, R[Math.max(0, i - 1)]], [x, y + 1, R[Math.min(2, i + 1)]], [x + 1, y + 1, R[Math.min(2, i + 1)]]);
    }
    for (const [x, y, c] of out) if (inR(g.get(x, y))) g.set(x, y, c);
  }
  // bark: broken vertical grain lines on the given trunk colours
  function bark(g, cols, dark, s) { for (let y = 0; y < g.h; y++) for (let x = 0; x < g.w; x++) if (cols.includes(g.get(x, y)) && hsh(x, y >> 2, s) < 0.2 && g.get(x - 1, y) !== INK) g.set(x, y, dark); }
  // ---------------- Chibi scenery props (World G): PROP2[kind] = { w, h, draw(g, theme) }, anchor bottom-centre ----------------
  // Round puffy trees, chunky rocks and toy-like beach / candy / glow props: pastel, one soft shade, bold outer line.
  // (Same canvas sizes as the old props, and the trees keep their canopies over the game's fruit slots.)
  const PLEAF = { day: ['#e0f8c4', '#a4da7e', '#82be62'], night: ['#d6f4ea', '#8ed0ba', '#6eb4a0'], candy: ['#ffe8f4', '#ffb8d8', '#f096be'], desert: ['#f0f4c8', '#cad68c', '#a8b66e'] };
  const pLeaf = th => PLEAF[th] || PLEAF.day;
  const PTRUNK = ['#fbe2c8', '#dcae88', '#c09068'];
  const pTint = (R, th) => (th === 'night' ? R.map(c => mixHex(c, '#7f88cc', 0.18)) : R);
  function puffTree(g, th, cx, trunkTop, trunkBot, trunkW, puffs, o) {
    o = o || {};
    const L = o.leaf || pLeaf(th), T = pTint(o.trunk || PTRUNK, th);
    piece(g, t => { t.poly([[cx - trunkW, trunkBot - 1], [cx - trunkW * 0.7, trunkTop], [cx + trunkW * 0.7, trunkTop], [cx + trunkW, trunkBot - 1]], T[1]); t.ell(cx, trunkBot - 1.2, trunkW + 1.6, 1.3, T[1]); kShade(t, cx, (trunkTop + trunkBot) / 2, trunkW + 1, (trunkBot - trunkTop) / 2 + 1, T, { hl: false }); });
    piece(g, t => {
      for (const [x, y, rx, ry] of puffs) t.ell(x, y, rx, ry, L[1]);
      const xs = puffs.map(p => [p[0] - p[2], p[0] + p[2]]).flat(), ys = puffs.map(p => [p[1] - p[3], p[1] + p[3]]).flat();
      const mx = (Math.min(...xs) + Math.max(...xs)) / 2, my = (Math.min(...ys) + Math.max(...ys)) / 2;
      kShade(t, mx, my, (Math.max(...xs) - Math.min(...xs)) / 2 + 0.6, (Math.max(...ys) - Math.min(...ys)) / 2 + 0.6, L);
    });
    // a few soft leafy bumps (lighter ovals) so the canopy reads as leaves, not a ball
    for (const [x, y, r] of o.bumps || []) g.ell(x, y, r, r * 0.62, L[0], -0.35, kIN(g));
    if (o.blossom) for (const [x, y] of o.blossom) { g.dots([[x - 0.5, y], [x + 0.5, y], [x, y - 0.5], [x, y + 0.5]], o.blossomCol || '#ffc8d8'); g.dot(x, y, '#ffe680'); }
  }
  const PROP2 = {
    tree: { w: 30, h: 38, draw(g, th) { puffTree(g, th, 15, 21, 37.6, 2.4, [[15, 14.6, 10.4, 8.8], [7.6, 20, 6, 4.8], [22.4, 20, 6, 4.8], [15, 7.4, 7, 5.4], [10, 9.6, 4.6, 3.8], [20.4, 9.8, 4.4, 3.8]], { bumps: [[10.6, 8.6, 1.8], [18.4, 6.4, 1.6], [6.4, 17.6, 1.5], [20.6, 15.4, 1.6]] }); } },
    bigtree: { w: 46, h: 52, draw(g, th) { puffTree(g, th, 23, 30, 51.6, 3.4, [[23, 21.6, 15.4, 12.4], [11.4, 28.4, 9, 6.8], [34.6, 28.4, 9, 6.8], [23, 10.8, 10.4, 7.6], [15, 13.6, 6.6, 5.4], [31.2, 13.8, 6.4, 5.4]], { bumps: [[15.6, 12.4, 2.4], [27.4, 8.6, 2.2], [9.6, 25.4, 2.2], [31.4, 20.8, 2.3], [20.6, 20, 2]], blossom: th === 'day' ? [[12, 18], [30, 15], [24.6, 26.4], [17, 30], [36, 27]] : null }); } },
    glowtree: { w: 40, h: 48, draw(g, th) {
      puffTree(g, th, 20, 28, 47.6, 3, [[20, 19, 13.4, 11], [10.4, 25.4, 8, 6], [29.6, 25.4, 8, 6], [20, 9.6, 9.2, 6.8]], { leaf: ['#e0f6f6', '#9ad8d6', '#78bcbc'], trunk: ['#e8dcf2', '#b8a6d0', '#9886b4'], bumps: [[13.6, 13, 2.2], [24.6, 8.4, 2], [9, 22.4, 2], [27.6, 19, 2.1]] });
      for (const [x, y] of [[12, 19], [27, 14], [20, 25], [30, 26], [16, 9]]) { g.ell(x, y, 1.1, 1.1, '#fff4b0', 0, kIN(g)); g.dot(x - 0.3, y - 0.3, '#ffffff'); }
    } },
    lollitree: { w: 28, h: 42, draw(g, th) {
      piece(g, t => { kRect(t, 13, 18, 15, 41.4, 0.8, '#fff6ee'); kShade(t, 14, 30, 1.4, 12, ['#ffffff', '#fff6ee', '#ead8d0'], { hl: false }); });
      for (let y = 19; y < 41; y += 2.6) stroke(g, [[13, y], [15, y - 1.2]], 0.35, 0.35, '#ffb8d0');
      piece(g, t => { t.ell(14, 11.2, 11, 10, '#ffc4dc'); kShade(t, 14, 11.2, 11, 10, ['#fff0f6', '#ffc4dc', '#f0a0c0']); });
      const pts = []; for (let i = 0; i <= 40; i++) { const a = i * 0.42, r = 0.6 + i * 0.22; pts.push([14 + Math.cos(a) * r, 11.2 + Math.sin(a) * r * 0.92]); }
      stroke(g, pts, 0.75, 0.75, '#ffffff');
      g.outerLine();
    } },
    bush: { w: 20, h: 12, draw(g, th) {
      const L = pLeaf(th);
      piece(g, t => { t.ell(6, 7.2, 5, 4.2, L[1]); t.ell(14, 7.2, 5, 4.2, L[1]); t.ell(10, 5.4, 5.4, 4.6, L[1]); t.ell(10, 9.4, 8.6, 1.8, L[1]); kShade(t, 10, 6.6, 9, 5, L); });
      for (const [x, y] of [[5.4, 6], [11.6, 3.8], [15, 7.2], [8.6, 8.6]]) { g.dots([[x - 0.5, y], [x + 0.5, y], [x, y - 0.5], [x, y + 0.5]], th === 'night' ? '#e6d8ff' : th === 'candy' ? '#ffffff' : '#ffc8d8'); g.dot(x, y, '#ffe680'); }
    } },
    rock: { w: 14, h: 9, draw(g, th) {
      const S = pTint(['#f4f2f8', '#d4cfde', '#b0aac2'], th);
      piece(g, t => { t.ell(6.4, 5.4, 5.6, 3.4, S[1]); t.ell(10, 6.2, 3.2, 2.4, S[1]); kShade(t, 7, 5.4, 6.4, 3.6, S); });
      piece(g, t => { t.ell(5.2, 2.4, 2, 1, th === 'candy' ? '#ffd0e4' : pLeaf(th)[1], -0.2); t.ell(6.8, 2.1, 1.2, 0.7, th === 'candy' ? '#ffd0e4' : pLeaf(th)[1], 0.2); });
    } },
    flowerbed: { w: 22, h: 11, draw(g, th) {
      const SO = pTint(['#e8cab4', '#c8a28a', '#ad8870'], th), L = pLeaf(th);
      const cols = th === 'night' ? ['#e6d8ff', '#c8e6ff', '#ffffff', '#fff2b0', '#e6d8ff', '#c8e6ff'] : th === 'candy' ? ['#ffd0e4', '#fff2b0', '#c8f4e4', '#e6d8ff', '#c8e6ff', '#ffd0e4'] : ['#ffc4d4', '#fff0a0', '#ffffff', '#c4e2ff', '#ffb4b8', '#e6d4ff'];
      piece(g, t => { t.ell(11, 8.6, 10, 2.1, SO[1]); kShade(t, 11, 8.6, 10, 2.1, SO, { hl: false }); });
      piece(g, t => { for (let i = 0; i < 6; i++) t.ell(2.8 + i * 3.3, 6.8, 1.7, 0.9, kFlat(L), i % 2 ? 0.45 : -0.45); });
      [[3.2, 4], [6.6, 3], [10.2, 4.2], [13.8, 2.8], [17.2, 4], [19.4, 5.4]].forEach(([x, y], i) => piece(g, t => { for (let k = 0; k < 5; k++) { const a = -Math.PI / 2 + k * Math.PI * 2 / 5; t.ell(x + Math.cos(a) * 1.05, y + Math.sin(a) * 0.95, 0.85, 0.8, cols[i]); } }));
      [[3.2, 4], [6.6, 3], [10.2, 4.2], [13.8, 2.8], [17.2, 4], [19.4, 5.4]].forEach(([x, y], i) => g.ell(x, y, 0.5, 0.5, i % 2 ? '#ffd866' : '#fff6c8'));
    } },
    palm: { w: 28, h: 42, draw(g, th) {
      const TR = pTint(['#fbe4c4', '#e2b886', '#c69a6a'], th), LV = th === 'night' ? PLEAF.night : ['#dcf6c4', '#9ed67c', '#7cba60'];
      for (let i = 9; i >= 0; i--) { const k = i / 10; piece(g, t => t.ell(11.4 + 4.6 * k * k, 39 - k * 27.6, 2.6 - k * 0.6, 1.9, kFlat(TR))); }
      const cx = 16.6, cy = 10.4;
      const fr = [[[cx, cy], [11.4, 8.6], [6.4, 10.4], [2.6, 15]], [[cx, cy], [21.8, 8.8], [25.2, 11.2], [26.6, 15.4]], [[cx, cy], [12.4, 5.6], [7.4, 4.4], [3.6, 6.4]], [[cx, cy], [20.6, 5.2], [24.4, 4.4], [26.6, 6.6]], [[cx, cy], [15, 4], [13, 1.6]], [[cx, cy], [18.6, 3.6], [21, 1.6]]];
      for (const f of fr) piece(g, t => { stroke(t, f, 2.0, 0.8, LV[1]); kShade(t, (f[0][0] + f[f.length - 1][0]) / 2, (f[0][1] + f[f.length - 1][1]) / 2 - 1, 7, 3, LV, { hl: false }); });
      piece(g, t => { for (const [x, y] of [[14.4, 12.4], [17, 13.2], [19.4, 12.2]]) t.ell(x, y, 1.45, 1.4, ['#f6e2c8', '#d8b088', '#be9470']); });
      g.dots([[13.9, 11.9], [16.5, 12.7], [18.9, 11.7]], '#fff6e8');
    } },
    sandcastle: { w: 24, h: 20, draw(g, th) {
      const S = pTint(['#fff6dc', '#f4dca8', '#dcc088'], th);
      for (const [x0, x1, top] of [[2, 7.4, 6.4], [16.6, 22, 6.4], [8.4, 15.6, 2.6]]) piece(g, t => { kRect(t, x0, top + 1, x1, 18.6, 0.8, S[1]); for (let x = x0 + 0.9; x <= x1 - 0.8; x += 1.8) t.ell(x, top + 1, 0.95, 1.1, S[1]); kShade(t, (x0 + x1) / 2, (top + 19) / 2, (x1 - x0) / 2 + 0.6, (19 - top) / 2, S); });
      piece(g, t => { kRect(t, 1.2, 12, 22.8, 19, 1, S[1]); kShade(t, 12, 15.4, 11, 3.6, S, { hl: false }); });
      piece(g, t => { kRect(t, 10, 13.4, 14, 19, 1.8, '#c8a07e'); });
      piece(g, t => { stroke(t, [[12, 3.4], [12, 0.8]], 0.3, 0.3, '#c8a888'); t.poly([[12.2, 0.6], [15, 1.4], [12.2, 2.4]], '#ff9eb0'); });
      for (const [x, y] of [[4.6, 10], [19.2, 10], [12, 7], [6, 15], [18, 15.6]]) g.ell(x, y, 0.5, 0.5, S[2], 0, kIN(g));
      g.dots([[3.6, 16.6], [20, 17]], '#ffc8d8');
    } },
    umbrella: { w: 22, h: 28, draw(g, th) {
      piece(g, t => kRect(t, 10.4, 7, 11.6, 27, 0.5, '#fff4e4'));
      piece(g, t => { t.ell(11, 10.4, 10.2, 8, '#fff', 0, (x, y) => y <= 10.4); for (let i = 0; i < 6; i++) t.ell(2.6 + i * 3.36, 10.2, 1.75, 1.3, '#fff'); });
      each2(g, (x, y, c) => { if (c !== '#fff') return; const a = Math.atan2(y + 0.5 - 10.4, x + 0.5 - 11), band = Math.floor((a + Math.PI) / (Math.PI / 6)) % 2; g.set(x, y, band ? '#ffa8bc' : '#ffffff'); });
      kShade(g, 11, 7, 10.4, 6.4, ['#ffffff', '#ffffff', '#ecdfe8'], { only: '#ffffff', hl: false }); kShade(g, 11, 7, 10.4, 6.4, ['#ffd0dc', '#ffa8bc', '#ee88a2'], { only: '#ffa8bc', hl: false });
      piece(g, t => t.ell(11, 2.4, 1, 1, '#ffa8bc'));
      piece(g, t => t.ell(11, 26.8, 3.2, 0.9, '#f4dca8'));
    } },
    shells: { w: 14, h: 7, draw(g) {
      piece(g, t => { const pts = [[4, 6.2]]; for (let i = 0; i <= 8; i++) { const a = Math.PI + i * Math.PI / 8; pts.push([4 + Math.cos(a) * 3.2, 5.6 + Math.sin(a) * 3.6]); } t.poly(pts, '#ffd0dc'); kShade(t, 4, 4, 3.2, 2.8, ['#fff0f4', '#ffd0dc', '#f2acc0'], { hl: false }); });
      for (const a of [-2.4, -1.9, -1.4, -0.9]) stroke(g, [[4, 5.8], [4 + Math.cos(a) * 2.6, 5.8 + Math.sin(a) * 3]], 0.16, 0.16, '#f2acc0');
      piece(g, t => { t.ell(10, 4.6, 2.6, 1.9, '#fff4e2'); kDrop(t, 11.2, 4.2, 1.3, 1.2, 1.4, 1.4, '#fff4e2'); kShade(t, 10.2, 4.4, 3, 2, ['#ffffff', '#fff4e2', '#ecd6bc'], { hl: false }); });
      stroke(g, [[8.6, 4.6], [10, 3.8], [11.2, 4.6]], 0.16, 0.16, '#e6c8a8');
    } },
    rockpool: { w: 24, h: 10, draw(g, th) {
      const S = pTint(['#f4f2f8', '#d4cfde', '#b0aac2'], th);
      piece(g, t => { for (const [x, y, rx, ry] of [[3.4, 6.2, 2.8, 2.2], [8, 7.6, 3, 1.8], [14, 7.8, 3.2, 1.8], [20, 6.6, 3, 2.3], [11, 3.6, 4, 1.6], [17.4, 3.6, 3, 1.5], [5.6, 3.8, 2.4, 1.6]]) t.ell(x, y, rx, ry, S[1]); kShade(t, 12, 5.6, 11, 3.6, S, { hl: false }); });
      g.ell(11.8, 5.6, 7.4, 2.2, '#bfe8fa'); g.ell(10.4, 5.2, 4, 0.8, '#e8f8ff');
      g.poly(starPts(15.2, 6, 1.4, 0.6, 5), '#ffb0a0');
      g.dots([[7.6, 5.4], [8.1, 5.4]], '#ffffff');
    } },
    glowshroom: { w: 14, h: 15, draw(g, th) {
      const C = ['#e8fcff', '#a4ecf4', '#80d0e2'], ST = ['#ffffff', '#f6f0fa', '#dcd2e6'];
      piece(g, t => { kRect(t, 9.2, 9.4, 11.4, 14.4, 0.8, ST[1]); t.ell(10.3, 14, 1.8, 0.7, ST[1]); });
      piece(g, t => { t.ell(10.3, 9.6, 3.4, 2.6, C[1], 0, (x, y) => y <= 9.8); kRect(t, 6.9, 9, 13.7, 10.2, 0.6, C[1]); kShade(t, 10.3, 8.6, 3.4, 2.2, C); });
      piece(g, t => { kRect(t, 3.4, 6.8, 6.2, 14.4, 1, ST[1]); t.ell(4.8, 14, 2.2, 0.8, ST[1]); kShade(t, 4.8, 10.6, 1.6, 4, ST, { hl: false }); });
      piece(g, t => { t.ell(4.8, 6.8, 4.4, 3.6, C[1], 0, (x, y) => y <= 7.2); kRect(t, 0.4, 6.2, 9.2, 7.8, 0.8, C[1]); kShade(t, 4.8, 5.4, 4.4, 3, C); });
      for (const [x, y] of [[3.2, 5], [6, 4.4], [5, 6.4], [9.8, 8], [11.2, 8.6]]) g.ell(x, y, 0.45, 0.45, '#ffffff', 0, kIN(g));
      kFace(g, 5, 10.4, 1.9, { sp: 1.6, w: 0.75, h: 1.0, mouth: null, blush: false });
    } },
    crystal: { w: 14, h: 21, draw(g, th) {
      const B = ['#f2f6ff', '#c4d8fa', '#a0b8ea'], V = ['#f8eeff', '#d8bcf6', '#b89ce0'];
      piece(g, t => { t.poly([[1.6, 20.4], [2.2, 11.8], [4.4, 9.2], [6.2, 12], [6.4, 20.4]], V[1]); kShade(t, 4, 15, 2.6, 5.6, V, { hl: false }); });
      piece(g, t => { t.poly([[8, 20.4], [8.6, 12.6], [10.6, 10.4], [12.4, 13], [12.6, 20.4]], V[1]); kShade(t, 10.4, 16, 2.4, 5, V, { hl: false }); });
      piece(g, t => { t.poly([[4.4, 20.4], [4.6, 6.4], [7, 1.6], [9.4, 6.4], [9.6, 20.4]], B[1]); kShade(t, 7, 11, 3, 9.6, B, { hl: false }); });
      stroke(g, [[5.8, 7], [5.8, 13]], 0.32, 0.32, '#ffffff'); g.dot(5.8, 5.6, '#ffffff');
      piece(g, t => t.ell(7, 20.4, 6.2, 0.9, '#d4cfde'));
    } },
    lantern: { w: 11, h: 28, draw(g, th) {
      const M = pTint(['#ece8f6', '#bcb6d4', '#9c96b8'], th), GL = th === 'night' ? ['#fffbe0', '#fff1a0', '#f6d470'] : ['#fffbec', '#fff1c4', '#f2d89c'];
      piece(g, t => { kRect(t, 4.8, 9, 6.2, 26.4, 0.5, M[1]); t.ell(5.5, 26.4, 3, 1, M[1]); kShade(t, 5.5, 18, 1.4, 9, M, { hl: false }); });
      piece(g, t => { kRect(t, 2.4, 3, 8.6, 8.4, 1.4, GL[1]); kShade(t, 5.5, 5.6, 3.2, 2.8, GL, { hl: false }); });
      piece(g, t => { t.poly([[1.6, 3.4], [5.5, 0.6], [9.4, 3.4]], M[1]); kRect(t, 1.8, 8.2, 9.2, 9.6, 0.5, M[1]); });
      g.ell(4.4, 4.6, 0.6, 1.1, '#ffffff', 0, kIN(g));
    } },
    mushrooms: { w: 14, h: 11, draw(g, th) {
      const C = ['#ffe2e6', '#ffa4b0', '#ec8494'], ST = ['#ffffff', '#fff6ee', '#eadcd0'];
      piece(g, t => { kRect(t, 9, 6.4, 11, 10.4, 0.8, ST[1]); t.ell(10, 10, 1.6, 0.6, ST[1]); });
      piece(g, t => { t.ell(10, 6.6, 3, 2.4, C[1], 0, (x, y) => y <= 6.8); kRect(t, 7, 6.1, 13, 7.2, 0.5, C[1]); kShade(t, 10, 5.6, 3, 2, C); });
      piece(g, t => { kRect(t, 3.2, 5.6, 5.8, 10.4, 1, ST[1]); t.ell(4.5, 10, 2, 0.7, ST[1]); kShade(t, 4.5, 8, 1.4, 2.6, ST, { hl: false }); });
      piece(g, t => { t.ell(4.5, 5.6, 4, 3.4, C[1], 0, (x, y) => y <= 6); kRect(t, 0.5, 5.1, 8.5, 6.5, 0.7, C[1]); kShade(t, 4.5, 4.2, 4, 2.8, C); });
      for (const [x, y, r] of [[3, 3.6, 0.6], [5.6, 3, 0.5], [6.4, 4.8, 0.45], [9.4, 5, 0.45], [11, 5.6, 0.4]]) g.ell(x, y, r, r, '#ffffff', 0, kIN(g));
    } },
    driftwood: { w: 24, h: 9, draw(g, th) {
      const W = pTint(['#f6ece2', '#d8c6b6', '#bca898'], th);
      piece(g, t => { stroke(t, [[14.6, 4.6], [17.6, 2.2], [19.6, 1.6]], 0.8, 0.6, W[1]); });
      piece(g, t => { stroke(t, [[2.6, 6.2], [12, 5.6], [21.4, 6.4]], 2.1, 1.8, W[1]); kShade(t, 12, 6, 10.4, 2.4, W); });
      piece(g, t => t.ell(22, 6.4, 1.3, 1.8, W[0]));
      g.ell(22, 6.4, 0.6, 0.9, W[2]);
      g.ell(8.4, 5.8, 0.9, 0.6, W[2], 0, kIN(g));
      stroke(g, [[11, 5.4], [15.4, 5.6]], 0.15, 0.15, W[2]);
    } },
    fern: { w: 20, h: 13, draw(g, th) {
      const L = pLeaf(th);
      piece(g, t => { for (const [a, len] of [[-2.7, 8], [-2.2, 9.4], [-1.57, 10], [-0.95, 9.4], [-0.45, 8]]) t.ell(10 + Math.cos(a) * len / 2, 12.4 + Math.sin(a) * len / 2, len / 2, 1.5, L[1], a); kShade(t, 10, 8, 9, 5, L); });
      for (const [a, len] of [[-2.2, 9.4], [-1.57, 10], [-0.95, 9.4]]) stroke(g, [[10, 12.2], [10 + Math.cos(a) * len * 0.8, 12.4 + Math.sin(a) * len * 0.8]], 0.15, 0.15, L[2]);
    } },
    candycane: { w: 12, h: 26, draw(g) {
      piece(g, t => stroke(t, [[4, 25.2], [4, 7.4], [4.6, 3.8], [6.8, 2], [9, 3], [9.6, 5.6]], 1.6, 1.6, '#fff'));
      each2(g, (x, y, c) => { if (c === '#fff' && Math.floor((y - x * 0.6) / 1.6) % 2 === 0) g.set(x, y, '#ffa4b4'); });
      kShade(g, 6, 13, 4, 12, ['#ffffff', '#ffffff', '#ecdfe6'], { only: '#fff', hl: false }); kShade(g, 6, 13, 4, 12, ['#ffd0da', '#ffa4b4', '#ee84a0'], { only: '#ffa4b4', hl: false });
    } },
    cupcake: { w: 26, h: 25, draw(g) {
      const WR = ['#eef6ff', '#b4d4f4', '#94b8e0'], FR = ['#fff2f8', '#ffc4dc', '#f0a2c2'];
      piece(g, t => { t.poly([[4.4, 13.4], [21.6, 13.4], [19.4, 24.4], [6.6, 24.4]], WR[1]); kShade(t, 13, 19, 8.6, 5.6, WR, { hl: false }); });
      for (let x = 7; x <= 19; x += 2.4) stroke(g, [[x, 14.4], [x + (x < 13 ? 0.4 : -0.4), 23.6]], 0.2, 0.2, WR[2]);
      piece(g, t => { t.ell(13, 13.2, 10.4, 3.4, FR[1]); t.ell(13, 9.6, 8, 3.6, FR[1]); t.ell(13, 6.4, 5.4, 3, FR[1]); kShade(t, 13, 9.6, 10.4, 7, FR); });
      piece(g, t => { t.ell(13.6, 2.8, 2.1, 2, '#ff9eaa'); });
      g.dot(13, 2.2, '#ffffff');
      for (const [x, y, c] of [[8, 10, '#fff2a0'], [16, 8, '#a8e0ff'], [11, 12.6, '#c8f0a8'], [18.4, 11.6, '#fff2a0'], [12, 7, '#d8c0ff']]) g.ell(x, y, 0.55, 0.35, c, 0.5, kIN(g));
    } },
    gumdrops: { w: 20, h: 10, draw(g) {
      [[5, 8.8, '#ffb4c4'], [15.4, 8.8, '#b8e8a0'], [10.2, 8.8, '#c8b0f4']].forEach(([x, y, c]) => piece(g, t => { t.ell(x, y, 3.8, 6, c, 0, (xx, yy) => yy <= y); t.ell(x, y - 0.2, 3.8, 0.8, c); kShade(t, x, y - 3, 3.8, 3.6, [mixHex(c, '#ffffff', 0.6), c, mixHex(c, INK, 0.12)]); }));
      for (const [x, y] of [[4, 6], [6, 7.6], [9.6, 5.4], [11.4, 7.4], [14.6, 6.4], [16.4, 8]]) g.dot(x, y, '#ffffff');
    } },
  };

  function prop(kind, theme) {
    theme = theme || 'day';
    const key = kind + theme; if (propCache[key]) return propCache[key];
    let g;
    if (PROP2[kind]) { // the chibi props above
      const P2 = PROP2[kind]; g = new Grid(P2.w, P2.h);
      try { P2.draw(g, theme); g.outerLine(); } catch (e) { console.error('PX.prop', kind, e); }
      return (propCache[key] = g.canvas());
    }
    const leafR = theme === 'candy' ? ['#ffc3dc', '#f08cbc', '#b8508a'] : theme === 'night' ? ['#52c7a8', '#2f8078', '#1f5452'] : ['#99e550', '#6abe30', '#37946e'];
    switch (kind) {
      case 'tree':
        g = new Grid(30, 38); g.dither = false;
        g.poly([[12.5, 38], [13.5, 22], [16.5, 22], [17.5, 38]], '#8f563b'); g.rect(13, 22, 1, 16, '#a8653a');
        g.ell(15, 15, 10.5, 9, leafR); g.ell(7.5, 20, 6.2, 5, leafR); g.ell(22.5, 20, 6.2, 5, leafR); g.ell(15, 7.5, 7, 5.6, leafR);
        g.outline();
        foliage(g, leafR, 0.05, 3); bark(g, ['#8f563b'], '#663931', 1);
        g.px([[10, 11], [11, 10], [19, 13], [8, 19], [21, 18], [14, 6]], leafR[0]);
        g.px([[9, 10], [10, 9], [13, 5]].filter(([x, y]) => g.filled(x, y)), mixHex(leafR[0], '#ffffff', 0.45));
        g.px([[12, 37], [18, 37], [11, 36]].filter(([x, y]) => !g.get(x, y)), leafR[1]);
        break;
      case 'bigtree':
        g = new Grid(46, 52); g.dither = false;
        g.poly([[19.5, 52], [20.5, 31], [25.5, 31], [26.5, 52]], '#8f563b'); g.rect(21, 31, 1, 21, '#a8653a'); g.rect(25, 34, 1, 18, '#663931');
        g.ell(23, 21, 15.5, 12.5, leafR); g.ell(11.5, 28, 9, 6.8, leafR); g.ell(34.5, 28, 9, 6.8, leafR); g.ell(23, 10.5, 10.5, 7.8, leafR);
        g.outline();
        foliage(g, leafR, 0.045, 5); bark(g, ['#8f563b'], '#663931', 2);
        g.px([[14, 16], [15, 15], [16, 15], [27, 19], [28, 18], [7, 26], [8, 25], [31, 25], [20, 6], [21, 6], [22, 5]], leafR[0]);
        g.px([[13, 15], [14, 14], [19, 5], [6, 25]].filter(([x, y]) => g.filled(x, y)), mixHex(leafR[0], '#ffffff', 0.45));
        g.px([[18, 30], [19, 30], [29, 31], [30, 31], [12, 33], [36, 33]], leafR[2]);
        g.px([[23, 40], [23, 41], [22, 44]].filter(([x, y]) => g.filled(x, y)), '#5a3322'); g.set(24, 42, '#5a3322');
        g.px([[18, 51], [19, 51], [27, 51], [28, 51], [17, 50]].filter(([x, y]) => !g.get(x, y)), leafR[1]);
        break;
      case 'bush':
        g = new Grid(20, 12);
        g.ell(6, 7, 5, 4.4, leafR); g.ell(14, 7, 5, 4.4, leafR); g.ell(10, 5, 5.4, 4.6, leafR);
        g.outline(); foliage(g, leafR, 0.14, 7);
        g.px([[5, 5], [11, 3], [15, 6], [8, 8]], '#f7b6c8'); g.px([[12, 7], [7, 4]], '#fbf236'); g.px([[5, 4], [11, 2]].filter(([x, y]) => g.filled(x, y)), '#ffffff');
        break;
      case 'bench':
        g = new Grid(22, 13);
        g.rect(1, 1, 20, 2, '#b8743a').rect(1, 4, 20, 2, '#b8743a').rect(1, 7, 20, 2, '#d9a066').rect(2, 9, 2, 3, '#663931').rect(18, 9, 2, 3, '#663931').rect(2, 3, 1, 4, '#663931').rect(19, 3, 1, 4, '#663931');
        g.outline();
        for (let x = 1; x < 21; x++) { g.set(x, 1, '#d9a066'); g.set(x, 4, '#d9a066'); g.set(x, 7, '#f0c890'); if (x % 7 === 3) { g.set(x, 2, '#8f563b'); g.set(x + 2, 5, '#8f563b'); g.set(x + 1, 8, '#b8743a'); } }
        g.px([[2, 9], [18, 9]], '#8f563b');
        break;
      case 'lamp':
        g = new Grid(9, 26);
        g.rect(4, 8, 1, 17, '#595a70').rect(2, 24, 5, 1, '#595a70').rect(2, 2, 5, 1, '#595a70').rect(2, 3, 5, 5, theme === 'night' ? '#fff27a' : '#fbf3dc').rect(3, 1, 3, 1, '#595a70');
        g.outline();
        break;
      case 'house':
        g = new Grid(22, 21);
        g.poly([[5, 20], [6, 10], [16, 10], [17, 20]], '#fbf3dc');
        g.ell(11, 10, 10, 7, theme === 'candy' ? RAMPS.plum : RAMPS.berry, 0, (x, y) => y <= 10);
        g.outline();
        g.rect(9, 15, 4, 5, '#8f563b'); g.px([[11, 17]], '#fbf236'); g.px([[14, 13]], theme === 'night' ? '#fff27a' : '#9fd8ff');
        g.px([[6, 6], [7, 6], [11, 4], [12, 4], [11, 5], [15, 7], [16, 7]], '#ffffff');
        break;
      case 'rock':
        g = new Grid(14, 9);
        g.ell(7, 5.5, 6, 3.6, RAMPS.slate); g.ell(10.6, 6.6, 2.6, 1.8, RAMPS.slate); g.outline();
        g.px([[4, 3], [5, 3], [3, 4]], '#dfe8fb'); g.px([[7, 4], [8, 5], [8, 6]], '#6e7690'); g.px([[9, 2], [10, 2], [11, 2], [10, 3]], theme === 'night' ? '#2f8078' : theme === 'candy' ? '#f7b6c8' : '#6abe30'); g.set(10, 2, theme === 'night' ? '#52c7a8' : theme === 'candy' ? '#ffffff' : '#99e550');
        break;
      case 'ball':
        g = new Grid(8, 8);
        g.ell(4, 4, 3.4, 3.4, '#ffffff'); g.rect(1, 1, 2, 6, '#d24552'); g.rect(5, 1, 2, 6, '#639bff'); g.ell(4, 4, 3.4, 3.4, null, 0, () => false);
        // re-clip stripes to the circle
        for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) if (!inEll(x + 0.5, y + 0.5, 4, 4, 3.4, 3.4).in) g.set(x, y, null);
        g.outline(); g.px([[3, 2]], '#ffffff');
        break;
      case 'egg':
        g = new Grid(20, 24);
        g.ell(10, 13, 7.6, 10, RAMPS.cloud);
        g.ell(7, 10, 2.2, 2.2, '#52c7a8', 0, (x, y) => g.filled(x, y)); g.ell(13, 17, 2.8, 2.4, '#52c7a8', 0, (x, y) => g.filled(x, y)); g.ell(13.5, 7, 1.4, 1.4, '#52c7a8', 0, (x, y) => g.filled(x, y));
        g.outline();
        break;
      case 'flowerbed': {
        g = new Grid(22, 11);
        const cols = theme === 'night' ? ['#c9a2f0', '#9fd8ff', '#ffffff', '#fff27a', '#c9a2f0'] : theme === 'candy' ? ['#ffc3dc', '#fff27a', '#a6f2d3', '#c9a2f0', '#9fd8ff'] : ['#f7b6c8', '#fbf236', '#ffffff', '#9fd8ff', '#d95763'];
        g.ell(11, 8.4, 10, 2.4, RAMP_X.bark, 0, (x, y) => y >= 6);
        for (let i = 0; i < 6; i++) g.ell(2.6 + i * 3.4, 6.6, 1.6, 1, leafR, i % 2 ? 0.4 : -0.4);
        const heads = [[3, 3.6], [6.6, 2.6], [10.2, 3.8], [13.8, 2.4], [17.4, 3.6], [19.6, 5]];
        heads.forEach(([x, y], i) => { g.rect(Math.floor(x), Math.floor(y) + 1, 1, 6 - Math.floor(y), leafR[2]); g.ell(x + 0.5, y, 1.5, 1.4, cols[i % cols.length]); });
        g.outline();
        heads.forEach(([x, y], i) => g.set(Math.floor(x), Math.floor(y), i % 2 ? '#f6c83a' : '#fff6d0'));
        g.px([[4, 9], [9, 9], [15, 9]], '#5a3322');
        break;
      }
      case 'dock':
        g = new Grid(26, 12);
        g.rect(3, 5, 2, 6, '#5a3322'); g.rect(12, 5, 2, 6, '#5a3322'); g.rect(21, 5, 2, 6, '#5a3322');
        g.rect(1, 2, 24, 3, theme === 'candy' ? '#f0c890' : '#b8743a');
        g.outline();
        g.rect(1, 2, 24, 1, theme === 'candy' ? '#ffe4b8' : '#d9a066');
        for (let x = 4; x < 25; x += 5) g.px([[x, 2], [x, 3], [x, 4]], theme === 'candy' ? '#c89a60' : '#8f563b');
        g.px([[2, 3], [7, 3], [12, 3], [17, 3], [22, 3]], '#595652');
        g.px([[3, 9], [12, 9], [21, 9]], '#7a4a2e'); g.px([[4, 6], [13, 6], [22, 6]], '#8f563b');
        break;
      case 'palm': {
        g = new Grid(28, 42);
        const TR = ['#e0b070', '#b8843a', '#7a5228'];
        for (let i = 0; i <= 14; i++) { const t = i / 14; g.ell(12 + 4 * t * t, 39.6 - t * 27, 2 - t * 0.4, 1.4, TR); }
        const fr = [[[16, 11], [12, 12.4], [9, 15.6]], [[16, 11], [20, 12], [23, 15.4]], [[16, 11], [11, 9], [6, 9.6], [3, 12.6]], [[16, 11], [21, 8.4], [24.6, 9], [26, 12]], [[16, 11], [12, 7], [7.6, 5.6], [4.6, 7.2]], [[16, 11], [19.4, 6], [23, 4.8], [25, 6.4]], [[16, 11], [15, 6.4], [13.2, 3]]];
        for (const f of fr) piece(g, t => stroke(t, f, 1.9, 0.7, leafR[1]));
        for (const f of fr) for (let i = 1; i < f.length; i++) line(g, f[i - 1][0], f[i - 1][1] - 0.6, f[i][0], f[i][1] - 0.6, leafR[0]);
        g.ell(14.6, 13.6, 1.4, 1.4, RAMP_X.bark); g.ell(17.4, 13.8, 1.4, 1.4, RAMP_X.bark); g.ell(16, 15, 1.3, 1.3, RAMP_X.bark);
        g.outline();
        for (let y = 16; y < 41; y += 3) for (let x = 0; x < 28; x++) if (g.get(x, y) === TR[1] || g.get(x, y) === TR[0]) g.set(x, y, TR[2]);
        g.px([[14, 13], [17, 13]], '#c48a5c'); g.set(16, 11, leafR[2]);
        break;
      }
      case 'sandcastle': {
        g = new Grid(24, 20);
        const S = theme === 'candy' ? ['#fff0f8', '#ffd0e4', '#e090b8'] : ['#fff0c0', '#f2d49a', '#c8a060'];
        g.rect(2, 12, 20, 7, S[1]); g.rect(3, 7, 5, 6, S[1]); g.rect(16, 7, 5, 6, S[1]); g.rect(9, 5, 6, 8, S[1]);
        for (const x of [3, 5, 7, 16, 18, 20]) g.rect(x, 6, 1, 1, S[1]);
        for (const x of [9, 11, 13]) g.rect(x, 4, 1, 1, S[1]);
        g.px([[11, 1], [11, 2], [11, 3]], '#8f563b'); g.px([[12, 1], [13, 1], [12, 2]], '#d24552');
        g.outline();
        for (let y = 0; y < 20; y++) for (let x = 0; x < 24; x++) { const c = g.get(x, y); if (c !== S[1]) continue; if (g.get(x + 1, y) === INK) g.set(x, y, S[2]); else if (g.get(x, y - 1) === INK || g.get(x - 1, y) === INK) g.set(x, y, S[0]); }
        g.rect(11, 14, 2, 5, '#8f563b'); g.px([[11, 13], [12, 13]], '#8f563b'); g.px([[5, 9], [18, 9], [11, 8], [12, 8]], '#8f563b');
        g.px([[4, 16], [8, 17], [16, 15], [19, 17]], S[2]); g.px([[7, 17]], '#f7b6c8');
        break;
      }
      case 'umbrella': {
        g = new Grid(22, 28);
        const st = theme === 'candy' ? ['#f07a9a', '#fff4f8'] : theme === 'night' ? ['#9a6ad0', '#fbf3dc'] : ['#e8404a', '#ffffff'];
        g.rect(10, 8, 2, 19, '#fbf3dc');
        g.ell(11, 10, 10, 7, st[0], 0, (x, y) => y <= 9);
        g.px([[10, 2], [11, 2]], '#f6c83a');
        g.outline();
        for (let y = 0; y < 10; y++) for (let x = 0; x < 22; x++) if (g.filled(x, y) && y >= 3) { const a = Math.atan2(y + 0.5 - 11, x + 0.5 - 11), sct = Math.floor((a + Math.PI) / (Math.PI / 6)); const dark = x > 15; g.set(x, y, sct % 2 ? (dark ? '#c8c8d8' : st[1]) : (dark ? '#a02c3a' : st[0])); }
        g.px([[5, 5], [6, 4]], '#ffffff'); g.px([[11, 8], [11, 12], [11, 18], [11, 24]], '#d9c9a8');
        for (let x = 1; x < 21; x += 3) if (g.get(x, 10) === null) g.set(x, 10, st[0]);
        break;
      }
      case 'shells':
        g = new Grid(14, 7);
        g.ell(4, 4.6, 2.8, 2.4, ['#ffd0dc', '#f7a6c0', '#c86a8a'], 0, (x, y) => y <= 5); g.rect(3, 5, 2, 1, '#f7a6c0');
        g.ell(10.2, 4.4, 2, 1.7, RAMP_X.cream); g.poly([[11.6, 3.4], [13, 3.4], [12, 5]], '#f4e6c8');
        g.px([[7, 5], [6, 5], [8, 5], [7, 4]], '#f08a6a');
        g.outline();
        g.px([[3, 3], [3, 4], [5, 3], [5, 4]], '#c86a8a'); g.px([[9, 4], [10, 3], [10, 4]], '#c8b08a');
        break;
      case 'rockpool':
        g = new Grid(24, 10);
        g.ell(12, 3.6, 3, 1.6, RAMPS.slate);
        g.ell(12, 6, 8.5, 2.8, ['#b8f0f8', '#5fcde4', '#306082']);
        g.ell(3.6, 6.2, 3, 2.6, RAMPS.slate); g.ell(20.4, 6.2, 3, 2.4, RAMPS.slate); g.ell(8, 8, 2.6, 1.3, RAMPS.slate); g.ell(16, 8.2, 2.8, 1.2, RAMPS.slate);
        g.outline();
        g.px([[13, 6], [12, 7], [14, 7], [13, 5], [12, 6], [14, 6]].slice(0, 5), '#f08a6a'); g.px([[9, 5], [10, 5], [17, 5]], '#ffffff'); g.px([[3, 5], [19, 5]], '#dfe8fb'); g.px([[6, 4]], '#6abe30');
        break;
      case 'glowtree': {
        g = new Grid(40, 48); g.dither = false;
        const CR2 = theme === 'candy' ? ['#c878c0', '#8a3a8a', '#5a1c5a'] : ['#4a70b8', '#2c3c78', '#1c2450'];
        g.poly([[16.5, 48], [17.5, 30], [22.5, 30], [23.5, 48]], '#3a2a50'); g.rect(18, 30, 1, 18, '#524b6e');
        g.poly([[17.5, 36], [12, 31], [13, 30], [18.5, 34]], '#3a2a50');
        g.ell(20, 20, 13.5, 11, CR2); g.ell(10, 27, 8, 6, CR2); g.ell(30, 27, 8, 6, CR2); g.ell(20, 10, 9, 7, CR2);
        g.outline();
        foliage(g, CR2, 0.045, 9); bark(g, ['#3a2a50'], '#2a1c3a', 3);
        g.px([[13, 14], [14, 13], [15, 13], [24, 17], [25, 16], [7, 24], [8, 23], [28, 23], [18, 5], [19, 5]], CR2[0]);
        const fruits = [[12, 18], [22, 12], [28, 20], [17, 25], [8, 28], [31, 29], [24, 27], [16, 9]];
        fruits.forEach(([x, y], i) => { const c = i % 3 === 2 ? '#9ff8ff' : '#fff27a'; g.px([[x, y], [x + 1, y], [x, y + 1], [x + 1, y + 1]], c); g.set(x, y, '#ffffff'); g.set(x + 1, y + 1, i % 3 === 2 ? '#5fcde4' : '#f6c83a'); for (const [dx, dy] of [[-1, -1], [2, -1], [-1, 2], [2, 2]]) if (g.filled(x + dx, y + dy)) g.set(x + dx, y + dy, CR2[0]); });
        for (const [x, y] of [[3, 16], [37, 18], [8, 5], [33, 8], [2, 34]]) g.set(x, y, '#fff27a');
        break;
      }
      case 'glowshroom': {
        g = new Grid(14, 15);
        const GR = theme === 'candy' ? ['#ffe0f4', '#f78ad0', '#b8508a'] : ['#c8fff8', '#5fe8e0', '#2f8f98'];
        g.rect(4, 8, 3, 6, '#f0e8d8'); g.rect(10, 11, 2, 3, '#f0e8d8');
        g.ell(5.5, 7.4, 4.6, 3.8, GR, 0, (x, y) => y <= 7.5); g.ell(11, 10.8, 2.8, 2.4, GR, 0, (x, y) => y <= 10.5);
        g.outline();
        g.px([[3, 5], [6, 4], [7, 6], [10, 9]], '#ffffff'); g.px([[4, 12], [10, 12]], '#c8bca8'); g.px([[4, 7], [5, 7], [6, 7]], GR[2]);
        for (const [x, y] of [[0, 3], [12, 5], [13, 8], [1, 10], [9, 2]]) if (!g.get(x, y)) g.set(x, y, GR[0]);
        break;
      }
      case 'crystal': {
        g = new Grid(14, 21);
        const CX = theme === 'candy' ? ['#ffe8f4', '#f7a6d0', '#c0508a'] : theme === 'day' ? ['#e8fcff', '#8ee0f0', '#3f8fc0'] : ['#f0e0ff', '#c09af0', '#7a50c0'];
        g.poly([[5, 18], [5, 6], [7, 2], [9, 6], [9, 18]], CX[1]);
        g.poly([[1.6, 18], [2, 11], [3.6, 8.4], [5.2, 11], [5.2, 18]], CX[1]);
        g.poly([[9, 18], [9, 12], [10.8, 9.6], [12.4, 12], [12.4, 18]], CX[1]);
        g.ell(7, 18.4, 6.4, 1.6, RAMPS.slate);
        g.outline();
        for (let y = 0; y < 18; y++) for (let x = 0; x < 14; x++) if (g.get(x, y) === CX[1]) { if (x === 6 || x === 2 || x === 9) g.set(x, y, CX[0]); else if (x === 8 || x === 4 || x === 11 || x === 12) g.set(x, y, CX[2]); }
        g.px([[6, 4], [6, 5], [6, 7]], '#ffffff'); g.px([[0, 4], [12, 5], [13, 2]], '#ffffff'); g.px([[10, 7]], CX[0]);
        break;
      }
      case 'lantern': {
        g = new Grid(11, 28);
        const lit = theme === 'day' ? ['#fff8e0', '#ffe08a', '#e0a040'] : ['#fffbd0', '#fbd23a', '#df7126'];
        g.rect(5, 11, 1, 14, '#595a70'); g.rect(3, 25, 5, 2, '#595a70');
        g.rect(3, 3, 5, 1, '#595a70'); g.rect(4, 2, 3, 1, '#595a70'); g.rect(4, 11, 3, 1, '#595a70');
        g.ell(5.5, 7.4, 3.2, 3.4, lit);
        g.outline();
        g.px([[4, 5], [4, 6], [4, 7], [4, 8], [4, 9], [7, 5], [7, 6], [7, 7], [7, 8], [7, 9]], lit[2]); g.px([[5, 6], [5, 7]], '#ffffff');
        g.px([[2, 25], [8, 25]].filter(([x, y]) => g.filled(x, y)), '#8c93a8');
        for (const [x, y] of [[0, 4], [10, 6], [0, 10], [10, 11]]) if (!g.get(x, y)) g.set(x, y, lit[0]);
        break;
      }
      case 'lollitree': {
        g = new Grid(28, 42);
        const LC = theme === 'night' ? ['#c9a2f0', '#fff4f8', '#7d8cf0'] : ['#f07a9a', '#fff4f8', '#9fd8ff'];
        g.rect(13, 18, 2, 23, '#fbf3dc');
        g.ell(14, 11, 10.2, 9.6, '#fff');
        g.ell(11.6, 21.6, 2, 1.2, '#9a6ad0', 0.4); g.ell(16.4, 21.6, 2, 1.2, '#9a6ad0', -0.4); g.ell(14, 21.6, 1, 1, '#c9a2f0');
        g.outline();
        for (let y = 0; y < 22; y++) for (let x = 0; x < 28; x++) if (g.get(x, y) === '#fff') {
          const dx = x + 0.5 - 14, dy = y + 0.5 - 11, r = Math.hypot(dx, dy), a = Math.atan2(dy, dx);
          const band = Math.floor(((a / (2 * Math.PI)) * 3 + r * 0.32) % 3 + 3) % 3;
          const c = LC[band]; g.set(x, y, (dx + dy > 9 && band !== 1) ? (band === 0 ? '#c0506a' : '#5f98d0') : c);
        }
        for (let y = 23; y < 41; y++) for (let x = 13; x < 15; x++) if ((x + y) % 4 < 2) g.set(x, y, '#f07a9a');
        g.px([[8, 6], [9, 5], [8, 7]], '#ffffff');
        break;
      }
      case 'candycane':
        g = new Grid(12, 26);
        stroke(g, [[8, 23.4], [8, 7], [7.6, 4.4], [6, 3], [4, 3], [2.8, 4.4], [2.8, 6.6]], 1.55, 1.55, '#ffffff');
        g.outline();
        for (let y = 0; y < 26; y++) for (let x = 0; x < 12; x++) if (g.get(x, y) === '#ffffff' && ((x + y) % 4 + 4) % 4 < 2) g.set(x, y, '#e8404a');
        for (let y = 6; y < 25; y++) if (g.get(9, y) === '#ffffff') g.set(9, y, '#d8d8e8'); else if (g.get(9, y) === '#e8404a') g.set(9, y, '#a02c3a');
        break;
      case 'cupcake': {
        g = new Grid(26, 25);
        const Wr = theme === 'night' ? ['#c8b0f8', '#9a7ae8', '#6a4ab8'] : ['#b8e8ff', '#7ac8f0', '#3f8fc0'], Fr = ['#fff0f8', '#ffc3dc', '#e08cb8'];
        g.poly([[4, 14], [22, 14], [20, 23.6], [6, 23.6]], Wr[1]);
        g.ell(13, 12.6, 10, 4.4, Fr); for (const [x, r] of [[5.6, 1.6], [10, 1.8], [15.4, 1.6], [20, 1.6]]) g.ell(x, 16, r, r + 0.4, Fr[1]);
        g.ell(13, 8, 6.4, 3.2, Fr); g.ell(13, 4.8, 3.4, 2, Fr);
        g.ell(14.4, 2.6, 1.6, 1.6, RAMPS.berry);
        g.outline();
        for (let y = 17; y < 24; y++) for (let x = 0; x < 26; x++) if (g.get(x, y) === Wr[1] && x % 3 === 0) g.set(x, y, Wr[2]);
        g.rect(11, 18, 4, 6, '#8f563b'); g.px([[11, 17], [12, 17], [13, 17], [14, 17]].slice(1, 3), '#8f563b'); g.px([[14, 21]], '#fbf236');
        g.px([[6, 18], [7, 18], [6, 19], [7, 19], [18, 18], [19, 18], [18, 19], [19, 19]], '#fff27a');
        g.px([[7, 11], [11, 9], [16, 10], [19, 12], [10, 13], [14, 6], [5, 13]].filter(([x, y]) => g.filled(x, y)), '#5fcde4'); g.px([[9, 11], [17, 8], [13, 12], [21, 13]].filter(([x, y]) => g.filled(x, y)), '#fbf236'); g.px([[12, 4], [15, 12]].filter(([x, y]) => g.filled(x, y)), '#99e550');
        g.px([[14, 2]], '#ffffff');
        break;
      }
      case 'gumdrops':
        g = new Grid(20, 10);
        g.ell(10, 9, 4.2, 6.6, ['#c8f0a0', '#6abe30', '#37946e'], 0, (x, y) => y <= 8);
        g.ell(4.4, 9, 3.4, 5, RAMPS.berry, 0, (x, y) => y <= 8); g.ell(15.6, 9, 3.4, 5.2, RAMPS.sun, 0, (x, y) => y <= 8);
        g.outline();
        g.px([[3, 6], [5, 5], [9, 4], [11, 6], [10, 3], [15, 5], [17, 7], [14, 7]].filter(([x, y]) => g.filled(x, y)), '#ffffff');
        break;
      case 'fence': {
        g = new Grid(26, 14);
        const WD = theme === 'candy' ? ['#ffffff', '#fbe4f0', '#e8a2c4'] : theme === 'night' ? ['#8a90b8', '#626890', '#44486a'] : ['#e4b27a', '#c08040', '#8f563b'];
        for (const x of [2, 12, 22]) { g.rect(x, 3, 3, 10, WD[1]); g.set(x + 1, 2, WD[1]); }
        g.rect(0, 5, 26, 2, WD[1]); g.rect(0, 9, 26, 2, WD[1]);
        g.outline();
        for (const x of [2, 12, 22]) { for (let y = 2; y < 13; y++) { if (g.filled(x, y)) g.set(x, y, WD[0]); if (g.filled(x + 2, y)) g.set(x + 2, y, WD[2]); } g.set(x + 1, 6, WD[2]); g.set(x + 1, 10, WD[2]); }
        for (let x = 0; x < 26; x++) { if (g.get(x, 5) === WD[1]) g.set(x, 5, WD[0]); if (g.get(x, 9) === WD[1]) g.set(x, 9, WD[0]); if (g.get(x, 6) === WD[1] && x % 5 === 1) g.set(x, 6, WD[2]); }
        if (theme === 'candy') { for (let y = 0; y < 14; y++) for (let x = 0; x < 26; x++) if (g.filled(x, y) && g.get(x, y) !== WD[2] && (x + y) % 4 === 0) g.set(x, y, '#f07a9a'); }
        else { g.px([[6, 6], [17, 10]].filter(([x, y]) => g.filled(x, y)), WD[2]); if (theme === 'day') g.px([[13, 12], [14, 12], [3, 12]].filter(([x, y]) => g.filled(x, y)), '#6abe30'); }
        break;
      }
      case 'stump': {
        g = new Grid(18, 13);
        const BK = ['#b8804e', '#8f563b', '#5a3322'], RG = ['#fbe0b0', '#e8c088', '#c89a60'];
        g.ell(3, 11.4, 2.2, 1.2, BK); g.ell(15, 11.4, 2.2, 1.2, BK);
        g.rect(3, 5, 12, 7, BK[1]); g.ell(9, 11.2, 6, 1.6, BK[1]);
        g.ell(9, 5, 6, 2.4, RG);
        g.outline();
        for (let y = 5; y < 13; y++) for (let x = 0; x < 18; x++) { const c = g.get(x, y); if (c !== BK[1] && c !== BK[0] && c !== BK[2]) continue; if (g.get(x - 1, y) === INK) g.set(x, y, BK[0]); else if (g.get(x + 1, y) === INK || x > 12) g.set(x, y, BK[2]); else if ((x === 6 || x === 10) && y > 6) g.set(x, y, BK[2]); }
        g.px([[7, 5], [8, 5], [9, 5], [10, 5], [11, 4], [6, 4]].filter(([x, y]) => g.filled(x, y)), RG[2]); g.px([[8, 4], [9, 4], [10, 4]].filter(([x, y]) => g.filled(x, y)), RG[1]); g.set(9, 5, '#a07040'); g.px([[5, 4], [6, 3]].filter(([x, y]) => g.filled(x, y)), '#fff4d8');
        g.px([[13, 9], [13, 8]], '#ec4c64'); g.set(12, 9, '#ec4c64'); g.set(14, 9, '#ec4c64'); g.set(13, 10, '#fbf3dc'); g.set(13, 8, '#ffffff');
        g.px([[4, 8], [4, 9]], '#6abe30'); g.set(5, 7, '#99e550');
        break;
      }
      case 'mushrooms': {
        g = new Grid(14, 11);
        const CP = theme === 'night' ? ['#c8fff8', '#5fe8e0', '#2f8f98'] : theme === 'candy' ? ['#ffd8ec', '#f78ad0', '#b8508a'] : ['#ff9aa0', '#e8404a', '#a02c3a'];
        g.rect(3, 6, 2, 4, '#f4ead8'); g.rect(9, 4, 2, 6, '#f4ead8'); g.rect(12, 8, 1, 2, '#f4ead8');
        g.ell(4, 6, 3.2, 2.4, CP, 0, (x, y) => y <= 6); g.ell(10, 4.2, 3.8, 3, CP, 0, (x, y) => y <= 4); g.ell(12.4, 8, 1.6, 1.4, CP, 0, (x, y) => y <= 8);
        g.outline();
        g.px([[9, 2], [11, 3], [8, 4], [3, 5], [5, 4]].filter(([x, y]) => g.filled(x, y)), theme === 'night' ? '#ffffff' : '#fff8f0');
        g.px([[4, 9], [10, 9], [11, 8]].filter(([x, y]) => g.filled(x, y)), '#c8bca8');
        g.px([[1, 10], [6, 10], [7, 10]].filter(([x, y]) => !g.get(x, y)), theme === 'candy' ? '#f7b6c8' : theme === 'night' ? '#2f8078' : '#6abe30');
        break;
      }
      case 'driftwood': {
        g = new Grid(24, 9);
        const DW = ['#e0d4bc', '#b8a888', '#86785e'];
        stroke(g, [[2, 6], [9, 5.6], [16, 6], [21.5, 5.2]], 1.9, 1.5, DW[1]);
        stroke(g, [[12, 5], [14.6, 2.2]], 0.8, 0.6, DW[1]);
        g.outline();
        for (let y = 0; y < 9; y++) for (let x = 0; x < 24; x++) { const c = g.get(x, y); if (c !== DW[1]) continue; if (g.get(x, y - 1) === INK) g.set(x, y, DW[0]); else if (g.get(x, y + 1) === INK) g.set(x, y, DW[2]); else if ((x * 3 + y) % 7 === 0) g.set(x, y, DW[2]); }
        g.px([[8, 6], [9, 6]], '#5a4a3a'); g.set(8, 5, DW[2]);
        g.px([[3, 8], [17, 8]].filter(([x, y]) => !g.get(x, y)), '#e2c47e');
        break;
      }
      case 'surfboard': {
        g = new Grid(10, 25);
        const SB = theme === 'night' ? ['#c9a2f0', '#9a6ad0', '#5e3a8e'] : ['#9fe8ff', '#4fb8e8', '#2a78b8'];
        g.ell(5, 7, 3.2, 6, SB); g.rect(2, 7, 7, 14, SB[1]); g.ell(5, 20, 3.2, 2.4, SB[1]);
        g.outline();
        for (let y = 0; y < 25; y++) for (let x = 0; x < 10; x++) { const c = g.get(x, y); if (!c || c === INK) continue; if (x === 5) g.set(x, y, '#ffffff'); else if (x <= 3 && g.get(x - 1, y) === INK) g.set(x, y, SB[0]); else if (x >= 7) g.set(x, y, SB[2]); else if (y > 7) g.set(x, y, SB[1]); }
        g.px([[4, 11], [6, 11], [4, 12], [6, 12]], '#f6c83a'); g.set(3, 4, '#ffffff');
        g.rect(1, 21, 8, 1, null); g.rect(1, 22, 8, 3, null);
        g.px([[1, 21], [2, 21], [3, 21], [4, 21], [5, 21], [6, 21], [7, 21], [8, 21]], '#e2c47e'); g.px([[0, 21], [9, 21]], '#d9bd7c');
        break;
      }
      case 'bucket': {
        g = new Grid(16, 13);
        const BU = ['#9fd8ff', '#639bff', '#3f55b8'];
        g.poly([[2, 5], [10, 5], [9, 12], [3, 12]], BU[1]);
        g.ell(6, 5, 4, 1.3, BU[0]);
        stroke(g, [[12.4, 12], [12.4, 6]], 0.6, 0.6, '#f6c83a'); g.ell(12.4, 4.6, 1.6, 2, '#e8404a');
        g.outline();
        for (let y = 5; y < 13; y++) for (let x = 0; x < 11; x++) { const c = g.get(x, y); if (c !== BU[1]) continue; if (g.get(x - 1, y) === INK) g.set(x, y, BU[0]); else if (g.get(x + 1, y) === INK) g.set(x, y, BU[2]); }
        g.px([[4, 5], [5, 5], [6, 5], [7, 5]], '#e2c47e'); g.px([[5, 4], [6, 4]], '#f3dc9c');
        g.px([[1, 3], [2, 2], [3, 1], [4, 1], [5, 1], [6, 1], [7, 1], [8, 1], [9, 2], [10, 3]], '#595a70');
        g.px([[3, 8], [7, 9]], '#ffffff'); g.set(12, 4, '#ff9aa0');
        break;
      }
      case 'moonstone': {
        g = new Grid(14, 21);
        const ST2 = ['#b8bcd8', '#8a8eb0', '#5a5e80'];
        g.poly([[3, 20], [2.4, 8], [4, 3], [7, 1.4], [10, 3], [11.4, 8], [11, 20]], ST2[1]);
        g.ell(7, 19.6, 6, 1.4, '#3f6a60');
        g.outline();
        shade(g, 5.4, 8, 6, 10, ST2);
        const RU = theme === 'candy' ? '#f78ad0' : '#7ff0ff';
        g.px([[7, 6], [7, 7], [7, 8], [6, 9], [8, 9], [7, 10], [7, 11], [6, 12], [8, 12], [7, 13]], RU); g.set(7, 5, '#ffffff');
        g.px([[4, 5], [5, 4], [4, 6]].filter(([x, y]) => g.filled(x, y)), '#dfe2f4');
        g.px([[3, 16], [4, 17], [10, 15], [9, 17], [3, 18], [10, 18]].filter(([x, y]) => g.filled(x, y)), '#4f8a6a');
        for (const [x, y] of [[0, 4], [13, 7], [12, 2]]) if (!g.get(x, y)) g.set(x, y, RU);
        break;
      }
      case 'fern': {
        g = new Grid(20, 13);
        const FR = theme === 'night' ? ['#6ad0a8', '#2f8f78', '#1f5a50'] : theme === 'candy' ? ['#c8fff0', '#7ee4c4', '#3fa890'] : ['#99e550', '#5cb43a', '#2f7a4a'];
        const fronds = [[[10, 12], [5, 7], [1.6, 7.6]], [[10, 12], [6.4, 4], [3.4, 2.6]], [[10, 12], [10, 4.4], [10.4, 1.4]], [[10, 12], [13.6, 4], [16.6, 2.6]], [[10, 12], [15, 7], [18.4, 7.6]]];
        for (const f of fronds) piece(g, t => stroke(t, f, 1.7, 0.8, FR[1]));
        for (const f of fronds) { line(g, f[0][0], f[0][1] - 1, f[1][0], f[1][1] - 0.6, FR[0]); line(g, f[1][0], f[1][1] - 0.6, f[2][0], f[2][1] - 0.5, FR[0]); }
        for (let y = 0; y < 13; y++) for (let x = 0; x < 20; x++) if (g.get(x, y) === FR[1] && g.get(x, y + 1) === INK && (x + y) & 1) g.set(x, y, FR[2]);
        g.px([[9, 12], [10, 12], [11, 12]].filter(([x, y]) => g.filled(x, y)), FR[2]);
        if (theme === 'night') g.px([[2, 7], [4, 2], [10, 1], [16, 2], [18, 7]].filter(([x, y]) => g.filled(x, y)), '#b8fff0');
        break;
      }
      case 'towel': {
        g = new Grid(22, 9);
        const TW = theme === 'night' ? ['#c9a2f0', '#9fd8ff'] : ['#f07a84', '#fff4dc'];
        g.poly([[1.4, 7.8], [4, 1.2], [21, 1.2], [18.6, 7.8]], TW[1]);
        g.outline();
        for (let y = 0; y < 9; y++) for (let x = 0; x < 22; x++) if (g.get(x, y) === TW[1] && Math.floor((x - y * 0.4) / 3) % 2 === 0) g.set(x, y, TW[0]);
        for (let x = 0; x < 22; x++) if (g.filled(x, 7)) g.set(x, 7, mixHex(g.get(x, 7), INK, 0.2));
        g.px([[2, 8], [5, 8], [8, 8], [12, 8], [16, 8]].filter(([x, y]) => !g.get(x, y)), '#fff4dc');
        g.px([[16, 2], [17, 2], [16, 3]], '#ffffff');
        break;
      }
      // ---- pet storage houses (one per area; ~44x42, anchor bottom-centre; door/window spots in PX.HOMES) ----
      case 'shroomhouse': {
        g = new Grid(44, 42);
        const CR3 = ['#fffbf0', '#f4e6c8', '#c8b08a'], CAP = ['#ff8a90', '#e8404a', '#a02c3a'];
        piece(g, t => { t.poly([[10, 41.6], [11.4, 21], [32.6, 21], [34, 41.6]], CR3[1]); for (let y = 0; y < 42; y++) for (let x = 0; x < 44; x++) if (t.get(x, y)) t.set(x, y, x < 15 ? CR3[0] : x > 29 ? CR3[2] : CR3[1]); });
        piece(g, t => t.ell(22, 21, 21.4, 14.4, CAP, 0, (x, y) => y <= 22));
        g.rect(4, 22, 36, 1, '#c86a5a'); g.rect(9, 23, 26, 1, '#b8a07a');
        for (const [x, y, r] of [[13, 12, 2.6], [24, 9, 3.2], [33, 15, 2.2], [7, 18, 1.6], [19, 17, 1.8], [36, 20, 1.3], [29, 5, 1.6]]) g.ell(x, y, r, r * 0.8, ['#ffffff', '#fbf0f0', '#e8d0d0'], 0, (x2, y2) => CAP.includes(g.get(x2, y2)));
        piece(g, t => { t.ell(22, 33, 4, 4, '#8f563b', 0, (x, y) => y <= 33); t.rect(18, 33, 8, 9, '#8f563b'); });
        for (let y = 29; y < 42; y++) { if (g.get(20, y) === '#8f563b') g.set(20, y, '#663931'); if (g.get(23, y) === '#8f563b') g.set(23, y, '#663931'); if (g.get(19, y) === '#8f563b') g.set(19, y, '#a8703a'); }
        g.px([[24, 36], [24, 37]], '#fbf236');
        piece(g, t => { t.ell(30.5, 29.5, 2.8, 2.8, '#9fd8ff'); });
        g.px([[30, 28], [30, 29], [30, 30], [30, 31], [28, 29], [29, 29], [31, 29], [32, 29]].filter(([x, y]) => g.get(x, y) === '#9fd8ff'), '#8f563b'); g.set(29, 28, '#ffffff');
        g.rect(27, 33, 8, 2, '#8f563b'); g.px([[28, 32], [30, 32], [32, 32], [34, 32]], '#f7b6c8'); g.px([[29, 32], [33, 32]], '#6abe30'); g.set(31, 32, '#fbf236');
        g.px([[12, 38], [13, 36], [14, 39], [31, 39], [32, 37]].filter(([x, y]) => g.filled(x, y)), '#6abe30');
        g.px([[9, 41], [8, 41], [35, 41], [36, 41], [7, 40]].filter(([x, y]) => !g.get(x, y)), '#6abe30');
        g.px([[8, 14], [9, 12], [11, 10]].filter(([x, y]) => CAP.includes(g.get(x, y))), '#ffb0b4');
        break;
      }
      case 'beachhut': {
        g = new Grid(42, 42);
        const PL = ['#d8f4ff', '#9fd8ff', '#5f98d0'], ST3 = ['#fff0b0', '#f0d284', '#c8a050'];
        piece(g, t => { t.rect(7, 20, 28, 22, PL[1]); });
        for (let y = 20; y < 42; y++) for (let x = 7; x < 35; x++) if (g.get(x, y) === PL[1]) { if ((x - 7) % 4 === 3) g.set(x, y, PL[2]); else if ((x - 7) % 8 < 3) g.set(x, y, '#ffffff'); if (x > 31) g.set(x, y, PL[2]); }
        piece(g, t => { t.poly([[1.4, 23.6], [21, 3.4], [40.6, 23.6]], ST3[1]); shade(t, 17, 12, 16, 13, ST3); });
        for (let y = 4; y < 24; y++) for (let x = 0; x < 42; x++) if (ST3.includes(g.get(x, y)) && (x + y * 2) % 5 === 0) g.set(x, y, ST3[2]);
        for (let x = 2; x < 41; x += 3) if (g.get(x, 23) && g.get(x, 23) !== INK) g.set(x, 24, ST3[2]);
        piece(g, t => { t.rect(17, 28, 8, 14, '#f07a84'); });
        for (let y = 28; y < 42; y++) { if (g.get(18, y) === '#f07a84') g.set(18, y, '#ff9aa8'); if (g.get(24, y) === '#f07a84') g.set(24, y, '#c8485a'); }
        g.px([[23, 35]], '#fbf236');
        piece(g, t => t.rect(9, 27, 5, 5, '#9fd8ff')); piece(g, t => t.rect(28, 27, 5, 5, '#9fd8ff'));
        g.px([[9, 27], [28, 27], [10, 27]], '#ffffff'); g.px([[11, 27], [11, 28], [11, 29], [11, 30], [11, 31], [30, 27], [30, 28], [30, 29], [30, 30], [30, 31]], '#5f98d0');
        g.ell(12, 36.5, 2.4, 2.4, '#ffffff'); g.set(12, 36, '#5f98d0'); g.set(12, 37, '#5f98d0'); g.px([[10, 36], [14, 37], [12, 34], [12, 39]], '#e8404a');
        g.px([[30, 35], [29, 36], [30, 36], [31, 36], [30, 37], [29, 38], [31, 38]], '#f08a6a');
        g.px([[21, 2], [20, 1]], '#d24552'); g.set(21, 1, '#d24552'); g.set(20, 2, INK);
        break;
      }
      case 'crystalcave': {
        g = new Grid(46, 42);
        const RK = ['#9a9ec0', '#6a6e96', '#44466a'], CXa = ['#f0e0ff', '#c09af0', '#7a50c0'], CXb = ['#e0ffff', '#7ff0ff', '#2a98b8'];
        const spire = (pts, C) => piece(g, t => { t.poly(pts, C[1]); for (let y = 0; y < 42; y++) for (let x = 0; x < 46; x++) if (t.get(x, y)) { const xs = pts.map(p => p[0]), mid = (Math.min(...xs) + Math.max(...xs)) / 2; t.set(x, y, x < mid - 0.5 ? C[0] : x > mid + 0.5 ? C[2] : C[1]); } });
        spire([[12, 22], [13, 9], [15.5, 5], [17.5, 10], [18, 22]], CXa);
        spire([[26, 22], [27, 12], [29, 8.5], [31, 12], [32, 22]], CXb);
        spire([[19, 20], [20.5, 3], [23, 0.4], [25, 3], [26, 20]], CXa);
        piece(g, t => t.ell(23, 30, 22, 13, RK, 0, (x, y) => y <= 41));
        for (let y = 0; y < 42; y++) for (let x = 0; x < 46; x++) if (RK.includes(g.get(x, y)) && (x * 5 + y * 3) % 11 === 0) g.set(x, y, RK[2]);
        piece(g, t => { t.ell(23, 34, 6, 6, '#241a36', 0, (x, y) => y <= 34); t.rect(17, 34, 13, 8, '#241a36'); });
        for (let y = 29; y < 42; y++) for (let x = 17; x < 30; x++) if (g.get(x, y) === '#241a36' && y > 36 && (x + y) & 1) g.set(x, y, '#3a2a58');
        g.px([[20, 40], [21, 39], [26, 40], [25, 41], [23, 38]], '#7ff0ff'); g.px([[22, 41], [23, 41], [24, 41]], '#c8fff8');
        piece(g, t => t.ell(35, 30.5, 2.4, 2.4, '#7ff0ff')); g.set(34, 29, '#ffffff');
        g.px([[6, 27], [7, 26], [9, 25], [38, 26], [40, 28], [11, 38], [36, 37]].filter(([x, y]) => g.filled(x, y)), '#4f8a6a');
        g.px([[6, 28], [8, 26], [39, 27]].filter(([x, y]) => g.filled(x, y)), '#6ad0a8');
        g.px([[14, 7], [20, 5], [28, 11]].filter(([x, y]) => g.filled(x, y)), '#ffffff');
        break;
      }
      case 'gingerhouse': {
        g = new Grid(42, 42);
        const GB = ['#f0b880', '#c8844a', '#8a5028'];
        piece(g, t => t.rect(6, 20, 30, 22, GB[1]));
        for (let y = 20; y < 42; y++) for (let x = 6; x < 36; x++) if (g.get(x, y) === GB[1]) { if (x < 9) g.set(x, y, GB[0]); else if (x > 32) g.set(x, y, GB[2]); }
        piece(g, t => t.rect(29, 6, 4, 9, '#8a5028'));
        piece(g, t => { t.poly([[1.4, 23.4], [21, 4], [40.6, 23.4]], '#6a3a2a'); shade(t, 17, 12, 16, 13, ['#8a5040', '#6a3a2a', '#48241c']); });
        for (let x = 1; x < 41; x++) for (let y = 4; y < 25; y++) { const c = g.get(x, y); if (c && c !== INK && g.get(x, y + 1) === INK) { g.set(x, y, '#ffffff'); if (x % 3 === 0 && y + 1 < 42 && g.get(x, y + 1) === INK) g.set(x, y + 1, '#ffffff'); break; } }
        for (let y = 4; y < 24; y++) { const r = 21 - (y - 4) * 19.6 / 19.4; for (const x of [Math.round(r), Math.round(42 - r)]) if (g.filled(x, y)) g.set(x, y, '#ffffff'); }
        g.px([[29, 6], [30, 6], [31, 6], [32, 6]], '#ffffff');
        for (const [x, y, c] of [[14, 16, '#e8404a'], [21, 11, '#99e550'], [27, 17, '#fff27a'], [18, 19, '#5fcde4'], [24, 20, '#f07aa0'], [10, 21, '#fff27a'], [32, 21, '#99e550']]) if (g.filled(x, y)) { g.set(x, y, c); if (g.filled(x + 1, y)) g.set(x + 1, y, c); }
        piece(g, t => { t.ell(21, 32, 4, 3.6, '#f7b6c8', 0, (x, y) => y <= 32); t.rect(17, 32, 8, 10, '#f7b6c8'); });
        for (let y = 28; y < 42; y++) { if (g.get(18, y) === '#f7b6c8') g.set(18, y, '#ffd8e8'); if (g.get(24, y) === '#f7b6c8') g.set(24, y, '#e07ba0'); }
        g.set(23, 36, '#fff27a');
        piece(g, t => t.rect(9, 27, 5, 5, '#9fd8ff')); piece(g, t => t.rect(28, 27, 5, 5, '#9fd8ff'));
        for (const x0 of [8, 27]) { for (let x = x0; x < x0 + 7; x++) { g.set(x, 26, '#ffffff'); g.set(x, 32, '#ffffff'); } g.set(x0 + 3, 29, '#ffffff'); g.set(x0 + 2, 29, '#ffffff'); g.set(x0 + 4, 29, '#ffffff'); }
        for (let y = 23; y < 42; y += 2) { if (g.filled(6, y)) g.set(6, y, (y >> 1) % 2 ? '#e8404a' : '#ffffff'); if (g.filled(35, y)) g.set(35, y, (y >> 1) % 2 ? '#e8404a' : '#ffffff'); }
        g.px([[12, 36], [11, 37], [13, 37], [30, 36], [29, 37], [31, 37]], '#ffffff');
        break;
      }
      case 'donut': {
        g = new Grid(22, 13);
        const DO = ['#f6c890', '#d8964e', '#a06430'], IC = theme === 'night' ? ['#e4d0ff', '#c09af0', '#8a6ad0'] : ['#ffd8ec', '#ff8ac4', '#d0508c'];
        g.ell(11, 7.4, 10, 4.8, DO);
        g.outline();
        g.ell(11, 6.4, 8.6, 3.6, IC, 0, (x, y) => g.filled(x, y));
        for (const x of [4, 8, 13, 17]) if (g.get(x, 9) && g.get(x, 9) !== INK) g.set(x, 9, IC[1]);
        g.ell(11, 6.6, 2.9, 1.6, '#5a3322'); g.ell(11, 7.4, 2.4, 0.9, DO[1], 0, (x, y) => g.get(x, y) === '#5a3322' && y >= 7); g.px([[9, 6], [10, 6], [11, 6], [12, 6]].filter(([x, y]) => g.get(x, y) === '#5a3322'), INK);
        g.px([[5, 5], [8, 4], [14, 4], [16, 6], [7, 7], [15, 8], [11, 3], [4, 7]].filter(([x, y]) => g.filled(x, y)), '#fff27a'); g.px([[6, 6], [13, 8], [10, 8], [17, 5]].filter(([x, y]) => g.filled(x, y)), '#5fcde4'); g.px([[9, 4], [12, 8], [18, 7]].filter(([x, y]) => g.filled(x, y)), '#99e550');
        g.px([[5, 4], [6, 4]].filter(([x, y]) => g.filled(x, y)), '#ffffff');
        break;
      }
      case 'lollipop': {
        g = new Grid(12, 25);
        const LP = theme === 'night' ? ['#c9a2f0', '#7d8cf0'] : [['#f07a9a', '#ffe070'], ['#9fd8ff', '#f7b6c8']][0];
        g.rect(5, 10, 2, 14, '#fff4f8');
        g.ell(6, 6, 5.2, 5.2, '#fff');
        g.outline();
        for (let y = 0; y < 12; y++) for (let x = 0; x < 12; x++) if (g.get(x, y) === '#fff') { const dx = x + 0.5 - 6, dy = y + 0.5 - 6, a = Math.atan2(dy, dx), r = Math.hypot(dx, dy); const b = Math.floor(((a / (2 * Math.PI)) * 2 + r * 0.62) % 2 + 2) % 2; g.set(x, y, b ? '#ffffff' : (dx + dy > 4 ? mixHex(LP[0], INK, 0.25) : LP[0])); }
        for (let y = 12; y < 24; y++) if ((y % 4) < 2) g.set(6, y, '#f7b6c8');
        g.px([[3, 3], [4, 2]], '#ffffff'); g.set(3, 4, '#ffe4ee');
        break;
      }
      case 'icecream': {
        g = new Grid(14, 22);
        const S1 = theme === 'night' ? ['#e4d0ff', '#c09af0', '#8a6ad0'] : ['#ffe0ec', '#ffb0cc', '#e07ba0'], S2 = ['#fff8e0', '#f6e0a0', '#d8b060'], S3 = ['#c8f8e8', '#7ee4c4', '#3fa890'];
        g.poly([[3, 11], [11, 11], [7, 21.4]], '#e8b060');
        g.ell(7, 10, 4.4, 2.6, S2); g.ell(7, 7, 3.8, 3, S1); g.ell(7, 3.6, 2.8, 2.4, S3);
        g.set(7, 0, '#e8404a'); g.set(8, 0, '#e8404a');
        g.outline();
        for (let y = 11; y < 22; y++) for (let x = 0; x < 14; x++) if (g.get(x, y) === '#e8b060' && ((x + y) % 3 === 0 || (x - y + 30) % 3 === 0)) g.set(x, y, '#b87830');
        g.px([[5, 2], [5, 6], [4, 9]].filter(([x, y]) => g.filled(x, y)), '#ffffff'); g.px([[9, 7], [6, 11], [8, 4]].filter(([x, y]) => g.filled(x, y)), '#f07a84'); g.set(9, 11, '#5fcde4');
        break;
      }
      default:
        g = new Grid(12, 10); g.ell(6, 6, 5, 3.6, leafR); g.outline();
    }
    return (propCache[key] = g.canvas());
  }

  // Draw a sprite canvas into ctx anchored at bottom-centre (x,y in the same pixel space), optional flip.
  // canvases from hi-res grids carry .k: they are drawn at (width / k) x (height / k) art pixels (scenes draw on a k-times buffer)
  const artW = c => (c.k ? c.width / c.k : c.width), artH = c => (c.k ? c.height / c.k : c.height);
  function blit(ctx, c, x, y, flip, ax, ay) {
    const w = artW(c), h = artH(c);
    ax = ax == null ? Math.floor(w / 2) : ax; ay = ay == null ? h : ay;
    x = Math.round(x); y = Math.round(y);
    if (flip) { ctx.save(); ctx.translate(x, 0); ctx.scale(-1, 1); ctx.drawImage(c, -(w - ax), y - ay, w, h); ctx.restore(); }
    else ctx.drawImage(c, x - ax, y - ay, w, h);
  }
  // a derived canvas (tinted / outlined / rotated copy) keeps the source's resolution tag
  const keepK = (src, out) => { if (src && src.k) out.k = src.k; return out; };
  // the resolution scenes should draw at: 2 = every art pixel is 2 x 2 buffer pixels (so hi-res sprites show all their detail)
  const SCENE_K = 2;

  // ---------------- Chiptune feedback sounds ----------------
  const Sound = (() => {
    let ac = null, muted = false, held = false, primed = false, recent = [];
    let pitchK = 1; // play(name, { pitch }) raises / lowers every frequency of that one sound (1 = as designed)
    // audio.js (music and cries) listens here for 'unlock' / 'suspend' / 'resume' / 'mute'; a listener may answer 'suspend' with
    // how many ms it needs to fade out before the context is paused
    const subs = [];
    function emit(k) { let r = 0; for (const f of subs) { try { r = Math.max(r, +f(k) || 0); } catch (e) { /* listener optional */ } } return r; }
    function ctx() {
      if (ac && ac.state === 'closed') ac = null;
      if (!ac) { const A = window.AudioContext || window.webkitAudioContext; if (A) { try { ac = new A(); } catch (e) { ac = null; } } }
      return ac;
    }
    // resume whenever the context isn't running: iOS reports 'suspended', or 'interrupted' after a call / backgrounding
    function wake(a) {
      if (!a || a.state === 'running' || a.state === 'closed') return;
      try { const p = a.resume(); if (p && p.catch) p.catch(() => {}); } catch (e) { /* not allowed yet: the next tap tries again */ }
    }
    // Every sound unplugs its nodes when it ends. (iPad Safari keeps finished nodes that are still plugged in, and the audio
    // thread keeps working on them: in a busy Survival match that grew until the whole game lagged and froze for minutes.)
    let live = 0; // sounds still playing
    const unplug = (src, nodes) => { live++; src.onended = () => { live = Math.max(0, live - 1); for (const nd of nodes) { try { nd.disconnect(); } catch (e) { /* already */ } } }; };
    function tone(f0, f1, dur, type, vol, delay) {
      if (muted || held) return; // held: page hidden, so nothing queues up to burst out on return
      const a = ctx(); if (!a) return;
      const t0 = a.currentTime + (delay || 0);
      const o = a.createOscillator(), gn = a.createGain();
      f0 *= pitchK; f1 *= pitchK;
      o.type = type || 'square'; o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
      gn.gain.setValueAtTime(0.0001, t0); gn.gain.exponentialRampToValueAtTime(vol || 0.05, t0 + 0.008); gn.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(gn); gn.connect(a.destination); unplug(o, [o, gn]); o.start(t0); o.stop(t0 + dur + 0.02);
    }
    // the hiss for each length is made once and reused (it used to be rebuilt for every single sound)
    const hiss = new Map();
    function hissBuf(a, dur) {
      const n = Math.max(1, Math.floor(a.sampleRate * dur)), key = a.sampleRate + ':' + n;
      let b = hiss.get(key);
      if (!b) { b = a.createBuffer(1, n, a.sampleRate); const d = b.getChannelData(0); let v = 0; for (let i = 0; i < n; i++) { if (i % 6 === 0) v = Math.random() * 2 - 1; d[i] = v * (1 - i / n); } if (hiss.size < 64) hiss.set(key, b); }
      return b;
    }
    function noise(dur, vol, freq, delay) {
      if (muted || held) return;
      const a = ctx(); if (!a) return;
      const s = a.createBufferSource(); s.buffer = hissBuf(a, dur); const f = a.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = (freq || 900) * pitchK;
      const gn = a.createGain(); gn.gain.value = vol || 0.15; s.connect(f); f.connect(gn); gn.connect(a.destination); unplug(s, [s, f, gn]); s.start(a.currentTime + (delay || 0));
    }
    // a hiss whose pitch slides (rolling balls, doors, a crowd cheer)
    function sweep(dur, vol, f0, f1, delay, q) {
      if (muted || held) return;
      const a = ctx(); if (!a) return;
      const t0 = a.currentTime + (delay || 0), s = a.createBufferSource(), f = a.createBiquadFilter(), gn = a.createGain();
      s.buffer = hissBuf(a, dur); f.type = 'bandpass'; f.Q.value = q || 1.2;
      f.frequency.setValueAtTime(f0 * pitchK, t0); f.frequency.exponentialRampToValueAtTime(Math.max(40, f1 * pitchK), t0 + dur);
      gn.gain.setValueAtTime(0.0001, t0); gn.gain.exponentialRampToValueAtTime(vol || 0.1, t0 + dur * 0.35); gn.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      s.connect(f); f.connect(gn); gn.connect(a.destination); unplug(s, [s, f, gn]); s.start(t0);
    }
    // a note that wobbles (the silly zombie "uhhh-uh?"): oscillator + vibrato, through a soft tone filter
    function wobble(f0, f1, dur, type, vol, rate, depth, delay, cut) {
      if (muted || held) return;
      const a = ctx(); if (!a) return;
      const t0 = a.currentTime + (delay || 0), o = a.createOscillator(), gn = a.createGain(), lfo = a.createOscillator(), lg = a.createGain(), fl = a.createBiquadFilter();
      o.type = type || 'sawtooth'; o.frequency.setValueAtTime(f0 * pitchK, t0); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1 * pitchK), t0 + dur);
      lfo.frequency.value = rate || 6; lg.gain.value = (depth || 8) * pitchK; lfo.connect(lg); lg.connect(o.frequency);
      fl.type = 'lowpass'; fl.frequency.value = (cut || 700) * pitchK;
      gn.gain.setValueAtTime(0.0001, t0); gn.gain.exponentialRampToValueAtTime(vol || 0.05, t0 + 0.05); gn.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(fl); fl.connect(gn); gn.connect(a.destination); unplug(o, [o, lfo, lg, fl, gn]); o.start(t0); lfo.start(t0); o.stop(t0 + dur + 0.05); lfo.stop(t0 + dur + 0.05);
    }
    // a cartoon voice: a buzzy note through two vowel filters ("aah" closing to "uh") with a wiggle: the silly "braaains!"
    function vowel(f0, f1, f2, dur, vol, delay) {
      if (muted || held) return;
      const a = ctx(); if (!a) return;
      const t0 = a.currentTime + (delay || 0), o = a.createOscillator(), lfo = a.createOscillator(), lg = a.createGain();
      const b1 = a.createBiquadFilter(), b2 = a.createBiquadFilter(), gn = a.createGain();
      o.type = 'sawtooth'; o.frequency.setValueAtTime(f0 * pitchK, t0); o.frequency.exponentialRampToValueAtTime(f1 * pitchK, t0 + dur * 0.3); o.frequency.exponentialRampToValueAtTime(Math.max(20, f2 * pitchK), t0 + dur);
      lfo.frequency.value = 7; lg.gain.value = 35; lfo.connect(lg); lg.connect(o.detune);
      b1.type = 'bandpass'; b1.Q.value = 3; b1.frequency.setValueAtTime(800, t0); b1.frequency.linearRampToValueAtTime(520, t0 + dur);
      b2.type = 'bandpass'; b2.Q.value = 5; b2.frequency.value = 1250;
      gn.gain.setValueAtTime(0.0001, t0); gn.gain.exponentialRampToValueAtTime(vol || 0.2, t0 + 0.05); gn.gain.setValueAtTime(vol || 0.2, t0 + dur * 0.7); gn.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
      o.connect(b1); o.connect(b2); b1.connect(gn); b2.connect(gn); gn.connect(a.destination);
      unplug(o, [o, lfo, lg, b1, b2, gn]); o.start(t0); lfo.start(t0); o.stop(t0 + dur + 0.05); lfo.stop(t0 + dur + 0.05);
    }
    let eggN = 0, eggT = 0; // egg taps climb in pitch, and start low again after a pause
    // PVZ Garden sounds: soft bloops, marimba knocks and leafy rustles (the Solunar Sprouts set was square-wave chiptune)
    const fx = {
      pop: () => { tone(520, 820, 0.08, 'sine', 0.07); tone(1040, 1300, 0.04, 'triangle', 0.02, 0.02); },
      coo: () => { const b = 600 + Math.random() * 160; tone(b, b * 1.35, 0.07, 'sine', 0.05); tone(b * 1.35, b * 1.8, 0.07, 'triangle', 0.035, 0.07); },
      chime: () => { tone(784, 784, 0.12, 'triangle', 0.06); tone(1175, 1175, 0.2, 'triangle', 0.05, 0.08); tone(2350, 2350, 0.12, 'sine', 0.015, 0.08); },
      level: () => { [659, 880, 1047, 1319].forEach((f, i) => { tone(f, f, 0.14, 'sine', 0.06, i * 0.06); tone(f * 2, f * 2, 0.06, 'triangle', 0.015, i * 0.06); }); },
      munch: () => { noise(0.06, 0.22, 500); tone(160, 90, 0.07, 'triangle', 0.08); },
      splash: () => { noise(0.32, 0.18, 1300); tone(300, 900, 0.18, 'sine', 0.03, 0.04); },
      crack: () => { tone(420, 180, 0.06, 'triangle', 0.08); noise(0.04, 0.2, 3200); },
      thud: () => tone(130, 48, 0.15, 'sine', 0.16),
      whoosh: () => noise(0.28, 0.09, 450),
      tick: () => tone(1800, 1600, 0.025, 'triangle', 0.035),
      go: () => { tone(784, 784, 0.12, 'triangle', 0.06); tone(1047, 1047, 0.3, 'triangle', 0.07, 0.13); },
      miss: () => tone(320, 210, 0.16, 'sawtooth', 0.025),
      evolve: () => { tone(400, 1600, 0.6, 'sine', 0.05); [1047, 1319, 1568, 2093].forEach((f, i) => tone(f, f, 0.12, 'triangle', 0.035, 0.35 + i * 0.08)); },
      snap: () => { noise(0.07, 0.25, 2600); tone(1500, 700, 0.05, 'square', 0.02); },
      // zombies: silly, never scary. The groan is a cartoon "uhhh-uh?" (soft triangle moan, then a little questioning hop up)
      groan: () => { const b = 165 + Math.random() * 55; wobble(b, b * 0.82, 0.42, 'triangle', 0.1, 5.5, b * 0.05, 0, 1500); wobble(b * 0.85, b * 1.3, 0.24, 'square', 0.03, 7, b * 0.04, 0.36, 1700); },
      brains: () => { const b = 160 + Math.random() * 40; vowel(b, b * 1.25, b * 0.85, 0.62, 0.22); noise(0.12, 0.05, 5200, 0.56); },
      'zombie-step': () => { const v = Math.random() < 0.5; noise(0.06, 0.08, v ? 380 : 300); tone(v ? 95 : 80, 55, 0.07, 'sine', 0.07); },
      boom: () => { noise(0.45, 0.3, 300); tone(90, 30, 0.4, 'sine', 0.2); },
      zap: () => { tone(1300, 250, 0.12, 'square', 0.03); noise(0.08, 0.12, 4000); },
      sun: () => { [880, 1175, 1568].forEach((f, i) => tone(f, f, 0.1, 'sine', 0.05, i * 0.05)); },
      plant: () => { tone(220, 110, 0.09, 'sine', 0.12); noise(0.12, 0.12, 2400); },
      chomp: () => { noise(0.05, 0.3, 700); tone(200, 80, 0.08, 'square', 0.04); noise(0.05, 0.25, 600, 0.11); },
      freeze: () => { [2093, 2637, 3136].forEach((f, i) => tone(f, f * 0.98, 0.15, 'sine', 0.025, i * 0.04)); },
      // mini-games
      bowl: () => { sweep(0.55, 0.12, 260, 110, 0, 1.6); tone(110, 70, 0.5, 'triangle', 0.09); tone(190, 120, 0.06, 'square', 0.02); },
      bonk: () => { tone(760, 240, 0.09, 'square', 0.03); tone(520, 330, 0.13, 'triangle', 0.1); noise(0.03, 0.15, 1800); },
      whack: () => { noise(0.05, 0.22, 1500); tone(300, 110, 0.1, 'triangle', 0.1); tone(1200, 500, 0.04, 'square', 0.02); },
      smash: () => { noise(0.18, 0.19, 3600); noise(0.12, 0.14, 5200, 0.04); noise(0.1, 0.1, 2600, 0.09); tone(260, 120, 0.1, 'triangle', 0.08); [2637, 3520, 3136].forEach((f, i) => tone(f, f * 0.97, 0.12, 'triangle', 0.03, 0.03 + i * 0.05)); },
      star: () => { [1568, 2093, 2637, 3136].forEach((f, i) => tone(f, f, 0.14, 'triangle', 0.04, i * 0.05)); tone(3136, 4186, 0.3, 'sine', 0.015, 0.2); },
      candy: () => { noise(0.04, 0.16, 2800); tone(1319, 1319, 0.08, 'triangle', 0.05, 0.03); tone(1760, 1760, 0.16, 'triangle', 0.05, 0.1); tone(3520, 3520, 0.08, 'sine', 0.012, 0.1); },
      // battle
      encounter: () => { [1319, 988, 1319, 1760].forEach((f, i) => tone(f, f * 0.99, 0.06, 'square', 0.025, i * 0.05)); tone(1760, 1760, 0.2, 'triangle', 0.05, 0.2); },
      hit: () => { noise(0.09, 0.26, 1100); tone(240, 90, 0.08, 'square', 0.035); },
      hitsuper: () => { noise(0.2, 0.3, 700); noise(0.08, 0.2, 3200); tone(320, 55, 0.16, 'square', 0.04); tone(160, 40, 0.18, 'sine', 0.12); },
      hitweak: () => { noise(0.06, 0.12, 450); tone(170, 120, 0.07, 'triangle', 0.08); },
      crit: () => { tone(2400, 900, 0.05, 'square', 0.03); noise(0.05, 0.2, 4200); noise(0.14, 0.26, 900, 0.03); tone(300, 60, 0.14, 'square', 0.04, 0.03); },
      faint: () => { tone(900, 90, 0.7, 'square', 0.022); tone(450, 45, 0.7, 'triangle', 0.05); },
      lowhp: () => { [0, 0.22, 0.44].forEach(d => tone(988, 988, 0.08, 'sine', 0.045, d)); }, // three soft beeps, then it stops
      heal: () => { [1047, 1319, 1568, 2093, 2637].forEach((f, i) => tone(f, f * 1.01, 0.16, 'triangle', 0.04, i * 0.07)); tone(523, 1047, 0.4, 'sine', 0.02); },
      // menus and world
      coin: () => { tone(1760, 1760, 0.05, 'square', 0.02); tone(2637, 2637, 0.16, 'triangle', 0.05, 0.05); },
      select: () => tone(1047, 1047, 0.04, 'square', 0.022),
      back: () => { tone(880, 880, 0.035, 'square', 0.02); tone(587, 587, 0.05, 'square', 0.02, 0.04); },
      bump: () => { tone(150, 85, 0.09, 'triangle', 0.13); noise(0.03, 0.08, 400); },
      door: () => { sweep(0.22, 0.09, 1800, 400); tone(392, 392, 0.06, 'square', 0.02, 0.02); tone(523, 523, 0.08, 'square', 0.02, 0.09); },
      step: () => { const v = Math.random() < 0.5; noise(v ? 0.05 : 0.04, 0.05, v ? 2600 : 3400); }, // two quiet grass rustles
      // egg / seed-packet taps climb in pitch by themselves; a caller that passes { pitch } (or { step }) sets the climb instead
      eggtap: o => {
        const now = performance.now(), mine = !o || !(+o.pitch > 0 || o.step != null);
        const n = mine ? (eggN = now - eggT > 2500 ? 0 : Math.min(eggN + 1, 9)) : +o.pitch > 0 ? 0 : Math.max(0, Math.min(9, o.step | 0));
        eggT = now; const f = 520 * Math.pow(1.122, n); tone(f, f * 0.75, 0.06, 'triangle', 0.08); noise(0.025, 0.12, 2500);
      },
      eggcrack: () => { noise(0.07, 0.25, 3000); tone(500, 160, 0.08, 'triangle', 0.08); noise(0.06, 0.2, 2200, 0.09); tone(420, 140, 0.07, 'triangle', 0.06, 0.09); },
      crank: () => { [0, 0.07, 0.14, 0.21].forEach((d, i) => { tone(700 - i * 40, 500 - i * 40, 0.025, 'square', 0.02, d); noise(0.02, 0.12, 2000, d); }); tone(180, 120, 0.25, 'triangle', 0.05); },
      countdown: () => tone(660, 660, 0.14, 'square', 0.03),
      cheer: () => { sweep(0.7, 0.07, 900, 2400, 0, 0.8); [784, 988, 1175, 1568].forEach((f, i) => tone(f, f, 0.1, 'triangle', 0.04, i * 0.06)); },
    };
    // (no more than 8 sounds start in any quarter second: a big wave of zombies all chomping at once stays a soft munch)
    // Only when the audio is really running: an iPad Home Screen app often leaves it paused ('suspended' / 'interrupted'), and
    // sounds queued on a paused clock never end, so they piled up by the thousand and froze the game once a battle got busy.
    function allow() {
      if (muted || held || !ac) return false;
      if (ac.state !== 'running') { wake(ac); return false; }
      const now = performance.now(); recent = recent.filter(x => now - x < 250);
      if (recent.length >= 8 || live > 24) return false;
      recent.push(now); return true;
    }
    return {
      // play(name) or play(name, { pitch }): pitch multiplies the sound's frequencies (0.25-4; e.g. combo pops climb)
      play(n, o) {
        try {
          if (!fx[n] || !allow()) return;
          pitchK = o && +o.pitch > 0 ? Math.max(0.25, Math.min(4, +o.pitch)) : 1;
          fx[n](o);
        } catch (e) { /* audio optional */ } finally { pitchK = 1; }
      },
      allow, unplug, // audio.js: cries share these limits and the unplug-when-done rule
      // call from a tap: creates / resumes the context (and on first use plays a silent blip, which older iOS needs)
      unlock() {
        held = false;
        try {
          const a = ctx(); if (!a) return;
          wake(a);
          if (!primed) { primed = true; const b = a.createBuffer(1, 1, 22050), s = a.createBufferSource(); s.buffer = b; s.connect(a.destination); s.start(0); }
        } catch (e) { /* audio optional */ }
        emit('unlock');
      },
      // page hidden -> suspend (saves battery, stops stray notes); page shown -> resume. The music gets ~0.1 s to fade first.
      suspend() {
        held = true;
        const wait = emit('suspend');
        const go = () => { try { if (held && ac && ac.state === 'running') { const p = ac.suspend(); if (p && p.catch) p.catch(() => {}); } } catch (e) { /* audio optional */ } };
        if (wait > 0) setTimeout(go, wait); else go();
      },
      resume() { held = false; try { if (ac) wake(ac); } catch (e) { /* audio optional */ } emit('resume'); },
      on(f) { if (typeof f === 'function') subs.push(f); },
      get ctx() { return ac && ac.state !== 'closed' ? ac : null; }, // the shared context (never created here: only a tap does)
      get held() { return held; },
      get live() { return live; },
      get state() { return ac ? ac.state : 'none'; },
      get muted() { return muted; }, set muted(v) { const was = muted; muted = !!v; if (was !== muted) emit('mute'); },
      names: Object.keys(fx),
      // dev only (test page): render one sound offline and measure it
      _render(n, o) {
        const OC = window.OfflineAudioContext || window.webkitOfflineAudioContext;
        if (!OC || !fx[n]) return Promise.resolve(null);
        const keep = [ac, muted, held, live], off = new OC(1, 44100 * 1.6, 44100);
        ac = off; muted = false; held = false;
        try { pitchK = o && +o.pitch > 0 ? +o.pitch : 1; fx[n](o); } finally { pitchK = 1; ac = keep[0]; muted = keep[1]; held = keep[2]; live = keep[3]; }
        return off.startRendering().then(b => {
          const x = b.getChannelData(0); let pk = 0, ss = 0, nan = 0, end = 0;
          for (let i = 0; i < x.length; i++) { const v = x[i]; if (v !== v) { nan++; continue; } const av = Math.abs(v); if (av > pk) pk = av; ss += v * v; if (av > 1e-4) end = i; }
          return { name: n, peak: +pk.toFixed(4), rms: +Math.sqrt(ss / x.length).toFixed(4), nan, end: +(end / 44100).toFixed(2) };
        });
      },
    };
  })();
  function buzz(ms) { try { navigator.vibrate && navigator.vibrate(ms || 10); } catch (e) {} }

  window.PX = { PAL, RAMPS, INK, BELLY, Grid, fromStrings, artW, artH, keepK, SCENE_K, inEll, shadeOf, sprig, buildSprig, SPRIG_AX, SPRIG_AY, emote, critter, critterSwim, critterFrames, PLANT_IDS: Object.keys(PLANTS), item, fruit, fx, prop, blit, SPRIG_W, SPRIG_H, FLOWER_IDS: Object.keys(FLO).filter(k => !k.endsWith('D')), stroke, line, starPts, DEFAULT_LOOK, cloneLook, clamp, lerp, Sound, buzz,
    gumballMachine, gumballColors: GUM.map(r => r[1]),
    // pet houses: door (bottom centre) and window centres, relative to the bottom-centre anchor
    HOMES: { shroomhouse: { door: [0, 0], win: [[8, -12]], w: 36, h: 40 }, beachhut: { door: [0, 0], win: [[-10, -13], [9, -13]], w: 30, h: 38 },
      crystalcave: { door: [0, 0], win: [[12, -12]], w: 42, h: 30 }, gingerhouse: { door: [0, 0], win: [[-10, -13], [9, -13]], w: 32, h: 36 } }, GUMBALL_W: 40, GUMBALL_H: 60, SKIN_IDS, SPOOKY_SKINS, HAT_IDS, EXTRA_IDS, SKIN_FX,
    PATTERN_IDS: ['spots', 'stripes', 'twotone', 'mask', 'star', 'freckles', 'heart', 'socks', 'zigzag', 'patches', 'tiger', 'moonmark'],
    EYE_IDS: ['round', 'sparkle', 'dot', 'sleepy', 'brave', 'star', 'wink', 'big'], // styles a Sprout can hatch with (pose eyes like happy/blink are separate)
    // soft rim light + core shade on Sprout bodies (on by default); setting it clears the sprite cache so the change shows at once
    get RIM() { return RIM; }, set RIM(v) { v = !!v; if (v !== RIM) { RIM = v; cache.clear(); } },
  };
})();
