// race.js — PVZ Garden Race screen (race zombies, or other gardeners' plants): race hub (series x 3 tiers, Daily Cup, Time Trials), the race itself, and results.
// Scene contract: PS.scenes.race = { mount(root), show(params), hide(), frame(dt, t) } + unlockAll() for the parent tools.
// The race engine evolves prototypes/3-race.html: stacked lanes, camera follows the player, run/swim/climb/fly
// segments (a climb is always followed by a downhill glide), stamina + tired state, and the Cheer Ring timing tap.
//
// What lives where (search for the banner comments):
//   EXTRA SERIES   Coral Deep + Cloud Circuit. They are not in data.js, so their progress/rewards are handled here
//                  (finishExtra) with the same shape as state.finishRace. The 5 original series still go through
//                  PS.state.finishRace exactly as before.
//   ITEMS          item boxes on the track: Speed Carrot, Bubble Shield, Honey Puddle, Rainbow Star (+ rival AI).
//   DAILY CUP      one race per real day (seeded by the local date) with a twist modifier (MODS).
//   TIME TRIAL     solo run vs a ghost of your best run, bronze/silver/gold medal times (MEDAL_COINS).
// Save data: everything new lives in PS.S.progress.raceExtra = { series:{}, trials:{}, daily:{}, hint:{} }, created lazily
// by xs(). Old saves without it work unchanged (reads fall back to defaults and never write).
(function () {
  'use strict';
  const D = PS.D, ST = PS.state;
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  let rng0 = Math.random; // swapped for a seeded rng while computing medal times, so they never change
  const rnd = (a, b) => a + rng0() * (b - a);
  const ORD = ['1st', '2nd', '3rd', '4th'];
  // the finish-line stamp: gold / silver / bronze, soft blue for 4th
  const STAMP_COL = ['#ffd23a', '#e6ebf2', '#eaa66a', '#a9d2f5'];
  const RM = (() => { try { return matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } })();
  // back on the race menus after a race: the hub music comes back (app.js)
  const hubMusic = () => { try { if (PS.ui.music) PS.ui.music(); } catch (e) { /* optional */ } };
  const music = id => { try { if (PX.Music && PX.Music.play) PX.Music.play(id); } catch (e) { /* optional */ } };
  const SEGS = ['run', 'swim', 'climb', 'fly'];
  const SEG_META = {
    run: { label: 'Run', color: '#6abe30' }, swim: { label: 'Swim', color: '#639bff' },
    climb: { label: 'Climb', color: '#a0a6ba' }, fly: { label: 'Glide', color: '#c9a2f0' },
  };
  const INK = PX.INK;

  // =====================================================================
  // TUNING — every race-feel number lives here (economy lives in data.js / state.js).
  // =====================================================================
  const TUNING = {
    base: { run: 38, swim: 28, climb: 16, fly: 46 },       // world px/s at multiplier 1
    speedLo: 0.55, speedK: 0.09, speedMin: 0.5, speedMax: 2.2, // mult = clamp(lo + k * rating)
    stamBase: 50, stamPer: 8,                               // max stamina = stamBase + stamPer * staminaRating
    drain: { run: 2.9, swim: 4.4, climb: 5.2, fly: 1.0 },   // stamina per second
    tired: { mul: 0.55, regen: 9, until: 0.3 },             // tired speed mult; regen/s; recover at 30 % of max
    // Cheer Ring: taps before the Good window are ignored; a late tap is a MISS (stumble); no tap = no boost, no stumble.
    ring: { every: [3.5, 5], first: 2.2, r0: 28, target: 13, shrink: 13, endR: 6, perfect: 1.6, good: 4.5, goodBeg: 5 },
    perfect: { mul: 1.45, t: 2.8, stam: 12 },
    good: { mul: 1.25, t: 2.0, stam: 6 },
    miss: { mul: 0.45, t: 0.5 },
    // Course length: an evenly matched race (player ≈ tier's mid rival rating) lasts about
    // targetSec * (series.length / 1100) ^ targetExp seconds. Mix weights are shares of that time.
    targetSec: 41, targetExp: 0.9,
    minRunSec: 1.4,
    finishJog: 16,
  };
  const T = TUNING;
  const mulOf = rating => clamp(T.speedLo + T.speedK * rating, T.speedMin, T.speedMax);
  const mulRating = m => (m - T.speedLo) / T.speedK; // the rating that gives speed multiplier m
  // Good window half-width (ring px): a little wider on Beginner courses (not the Daily Cup)
  const goodOf = (tier, mode) => (tier === 0 && mode !== 'cup' ? T.ring.goodBeg : T.ring.good);
  // a tap when the ring's radius is r: 'early' (ignored) | 'perfect' | 'good' | 'late' (MISS)
  function judge(r, good) { const d = r - T.ring.target; return d > good ? 'early' : d < -good ? 'late' : Math.abs(d) <= T.ring.perfect ? 'perfect' : 'good'; }

  // =====================================================================
  // EXTRA SERIES (not in data.js). seed keeps their courses stable even if data.js gains races.
  // eggs: first-win egg per tier. mult: prize multiplier (the originals use 1 + index * 0.15).
  // =====================================================================
  // eggs: the seed packet a first win gives when that tier has no new plant to unlock (data.js UNLOCKS 'race:<id>-<tier>')
  const EXTRA_RACES = [
    { id: 'desert', name: 'Egypt Sand Sprint', area: 'egypt', extra: true, seed: 1, blurb: 'Dunes, ruins and an oasis',
      mix: { run: 4, swim: 1, climb: 3, fly: 2 }, length: 1250, unlock: { race: 'pirate', tier: 0 }, eggs: ['normal', 'normal', 'golden'], mult: 1.45 },
    { id: 'rooftop', name: 'Rooftop Rally', area: 'cloud', extra: true, seed: 2, blurb: 'Hop across the rooftops in the sky',
      mix: { run: 2, climb: 3, fly: 5 }, length: 1300, unlock: { race: 'desert', tier: 0 }, eggs: ['normal', 'galaxy', 'golden'], mult: 1.6 },
    // the long grind, after the Zombie Grand Prix. ratingMul makes rivals (and the course pace) faster than the base tiers.
    { id: 'jungle', name: 'Jurassic Marsh', area: (PX.RACE_MAPS || {}).jurassic ? 'jurassic' : 'jungle', extra: true, seed: 3, blurb: 'Vines, ferns and swampy swims',
      mix: { run: 3, swim: 3, climb: 3, fly: 1 }, length: 1300, unlock: { race: 'rooftop', tier: 0 }, eggs: ['normal', 'ghost', 'rainbow'], mult: 1.65, ratingMul: 1.06 },
    { id: 'volcano', name: 'Lava Rock Run', area: 'volcano', extra: true, seed: 4, blurb: 'Hot rocks and steamy springs',
      mix: { run: 4, swim: 2, climb: 4, fly: 1 }, length: 1350, unlock: { race: 'jungle', tier: 1 }, eggs: ['normal', 'zombie', 'golden'], mult: 1.75, ratingMul: 1.13 },
    { id: 'snowy', name: 'Frostbite Caves', area: (PX.RACE_MAPS || {}).frostbite ? 'frostbite' : 'snowy', extra: true, seed: 5, blurb: 'Icy climbs and sledding',
      mix: { run: 2, swim: 1, climb: 4, fly: 4 }, length: 1400, unlock: { race: 'volcano', tier: 1 }, eggs: ['normal', 'crystal', 'golden'], mult: 1.85, ratingMul: 1.21 },
    { id: 'starlight', name: 'Far Future Skyway', area: (PX.RACE_MAPS || {}).farfuture ? 'farfuture' : 'starlight', extra: true, seed: 6, blurb: 'A race through the future sky',
      mix: { run: 2, swim: 1, climb: 2, fly: 6 }, length: 1450, unlock: { race: 'snowy', tier: 1 }, eggs: ['normal', 'galaxy', 'rainbow'], mult: 2.0, ratingMul: 1.3 },
  ];
  // more zombie series on the newer garden maps' courses (their scenery comes from art-world2.js; a series only shows once its
  // scenery exists). First wins on the Pro tiers give garden maps (data.js UNLOCKS).
  const MORE_RACES = [
    { id: 'west', name: 'Wild West Wagon Dash', area: 'wildwest', extra: true, seed: 7, blurb: 'Dusty trails and rolling wagons',
      mix: { run: 5, swim: 1, climb: 3, fly: 1 }, length: 1350, unlock: { race: 'desert', tier: 1 }, eggs: ['normal', 'zombie', 'golden'], mult: 1.7, ratingMul: 1.1 },
    { id: 'beachz', name: 'Big Wave Beach Bash', area: 'bigwave', extra: true, seed: 8, blurb: 'Surf, sand and splashy swims',
      mix: { run: 2, swim: 5, climb: 1, fly: 2 }, length: 1350, unlock: { race: 'west', tier: 0 }, eggs: ['normal', 'ghost', 'golden'], mult: 1.8, ratingMul: 1.15 },
    { id: 'lostz', name: 'Lost City Temple Run', area: 'lostcity', extra: true, seed: 9, blurb: 'Golden ruins and steep climbs',
      mix: { run: 3, swim: 1, climb: 5, fly: 1 }, length: 1400, unlock: { race: 'beachz', tier: 0 }, eggs: ['normal', 'crystal', 'golden'], mult: 1.9, ratingMul: 1.2 },
    { id: 'darkz', name: 'Dark Ages Castle Chase', area: 'darkages', extra: true, seed: 10, blurb: 'Castle walls, moats and towers',
      mix: { run: 3, swim: 2, climb: 3, fly: 2 }, length: 1450, unlock: { race: 'lostz', tier: 0 }, eggs: ['normal', 'ghost', 'rainbow'], mult: 2.05, ratingMul: 1.26 },
    { id: 'neonz', name: 'Neon Night Run', area: 'neon', extra: true, seed: 11, blurb: 'Bright lights and a booming beat',
      mix: { run: 4, swim: 1, climb: 2, fly: 3 }, length: 1500, unlock: { race: 'darkz', tier: 1 }, eggs: ['normal', 'galaxy', 'rainbow'], mult: 2.2, ratingMul: 1.33 },
    // the sixth wave: courses on the newest garden maps (art-world3.js). First wins unlock the fifth-wave plants (data.js UNLOCKS).
    { id: 'poolz', name: 'Pool Party Splash Race', area: 'poolside', extra: true, seed: 12, blurb: 'Diving boards, pool floats and splashes',
      mix: { run: 2, swim: 6, climb: 1, fly: 1 }, length: 1500, unlock: { race: 'neonz', tier: 0 }, eggs: ['normal', 'crystal', 'golden'], mult: 2.3, ratingMul: 1.36 },
    { id: 'foggyz', name: 'Foggy Night Fright Run', area: 'foggynight', extra: true, seed: 13, blurb: 'Misty paths, lanterns and a spooky pond',
      mix: { run: 4, swim: 2, climb: 2, fly: 2 }, length: 1550, unlock: { race: 'poolz', tier: 0 }, eggs: ['normal', 'ghost', 'rainbow'], mult: 2.4, ratingMul: 1.4 },
    { id: 'roofz', name: 'Rooftop Chimney Chase', area: 'rooftop', extra: true, seed: 14, blurb: 'Roof tiles, chimneys and big jumps',
      mix: { run: 3, swim: 1, climb: 4, fly: 3 }, length: 1550, unlock: { race: 'foggyz', tier: 0 }, eggs: ['normal', 'zombie', 'golden'], mult: 2.5, ratingMul: 1.44 },
    { id: 'candyz', name: 'Candy Land Sugar Rush', area: 'candyland', extra: true, seed: 15, blurb: 'Gumdrop hills and a lemonade lake',
      mix: { run: 4, swim: 2, climb: 3, fly: 2 }, length: 1600, unlock: { race: 'roofz', tier: 1 }, eggs: ['normal', 'galaxy', 'rainbow'], mult: 2.65, ratingMul: 1.5 },
  ].filter(R => (PX.RACE_MAPS || {})[R.area]);
  // PLANT races (the "race plants" side): other gardeners' plants on their own courses, with their own prizes. Every win adds a
  // fruit bundle (Beginner), an element core (Pro) or a fusion item (Master) to the coins, and first wins unlock the newer plants.
  const PLANT_RACES = [
    { id: 'p-meadow', name: 'Sunny Meadow Sprint', area: 'meadow', extra: true, plants: true, seed: 21, blurb: 'Flowers, hedges and a sunny path',
      mix: { run: 5, swim: 1, climb: 2, fly: 1 }, length: 1100, unlock: null, eggs: ['normal', 'normal', 'golden'], mult: 0.9, ratingMul: 0.85 },
    { id: 'p-backyard', name: 'Backyard Pool Paddle', area: 'backyard', extra: true, plants: true, seed: 22, blurb: 'Pool floats and garden hedges',
      mix: { run: 2, swim: 5, climb: 1, fly: 1 }, length: 1150, unlock: { race: 'p-meadow', tier: 0 }, eggs: ['normal', 'normal', 'rainbow'], mult: 1, ratingMul: 0.9 },
    { id: 'p-candy', name: 'Candy Garden Dash', area: 'candy', extra: true, plants: true, seed: 23, blurb: 'Lollipop trees and gumdrop hills',
      mix: { run: 4, swim: 1, climb: 3, fly: 2 }, length: 1200, unlock: { race: 'p-backyard', tier: 0 }, eggs: ['normal', 'galaxy', 'golden'], mult: 1.1, ratingMul: 0.95 },
    { id: 'p-moon', name: 'Moonlit Bloom Run', area: 'moonlit', extra: true, plants: true, seed: 24, blurb: 'Glowing mushrooms under the moon',
      mix: { run: 3, swim: 1, climb: 3, fly: 3 }, length: 1250, unlock: { race: 'p-candy', tier: 0 }, eggs: ['normal', 'ghost', 'golden'], mult: 1.2, ratingMul: 1 },
    { id: 'p-coral', name: 'Coral Reef Splash', area: 'coral', extra: true, plants: true, seed: 25, blurb: 'Swim through the coral reef',
      mix: { run: 1, swim: 6, climb: 1, fly: 2 }, length: 1250, unlock: { race: 'p-moon', tier: 1 }, eggs: ['normal', 'crystal', 'golden'], mult: 1.35, ratingMul: 1.05 },
    { id: 'p-cloud', name: 'Cloud Garden Glide', area: 'cloud', extra: true, plants: true, seed: 26, blurb: 'Hop and glide over the clouds',
      mix: { run: 2, swim: 1, climb: 2, fly: 6 }, length: 1300, unlock: { race: 'p-coral', tier: 0 }, eggs: ['normal', 'galaxy', 'rainbow'], mult: 1.5, ratingMul: 1.1 },
    { id: 'p-beach', name: 'Seaside Petal Rally', area: 'beach', extra: true, plants: true, seed: 27, blurb: 'Sandcastles, shells and waves',
      mix: { run: 3, swim: 3, climb: 2, fly: 2 }, length: 1350, unlock: { race: 'p-cloud', tier: 1 }, eggs: ['normal', 'ghost', 'golden'], mult: 1.65, ratingMul: 1.16 },
    { id: 'p-star', name: 'Starry Garden Gala', area: 'starlight', extra: true, plants: true, seed: 28, blurb: 'A race among the stars',
      mix: { run: 3, swim: 2, climb: 3, fly: 4 }, length: 1450, unlock: { race: 'p-beach', tier: 1 }, eggs: ['normal', 'galaxy', 'rainbow'], mult: 1.85, ratingMul: 1.24 },
    // the sixth wave: other gardeners on the newer garden maps' courses. First wins unlock the fifth-wave plants (data.js UNLOCKS).
    { id: 'p-west', name: 'Wild West Flower Rodeo', area: 'wildwest', extra: true, plants: true, seed: 29, blurb: 'Cactus trails and tumbleweeds',
      mix: { run: 5, swim: 1, climb: 3, fly: 1 }, length: 1450, unlock: { race: 'p-star', tier: 0 }, eggs: ['normal', 'zombie', 'golden'], mult: 1.95, ratingMul: 1.3 },
    { id: 'p-snow', name: 'Frosty Petal Slalom', area: 'frostbite', extra: true, plants: true, seed: 30, blurb: 'Snowy slopes and icy caves',
      mix: { run: 2, swim: 1, climb: 4, fly: 4 }, length: 1500, unlock: { race: 'p-west', tier: 0 }, eggs: ['normal', 'crystal', 'golden'], mult: 2.05, ratingMul: 1.36 },
    { id: 'p-jungle', name: 'Jurassic Jungle Dash', area: 'jurassic', extra: true, plants: true, seed: 31, blurb: 'Ferns, dino bones and swampy swims',
      mix: { run: 3, swim: 3, climb: 3, fly: 1 }, length: 1500, unlock: { race: 'p-snow', tier: 0 }, eggs: ['normal', 'ghost', 'rainbow'], mult: 2.15, ratingMul: 1.42 },
    { id: 'p-volcano', name: 'Volcano Bloom Blaze', area: 'volcano', extra: true, plants: true, seed: 32, blurb: 'Hot rocks and steamy springs',
      mix: { run: 4, swim: 2, climb: 4, fly: 1 }, length: 1550, unlock: { race: 'p-jungle', tier: 1 }, eggs: ['normal', 'galaxy', 'rainbow'], mult: 2.3, ratingMul: 1.5 },
  ].filter(R => !['wildwest', 'frostbite', 'jurassic'].includes(R.area) || (PX.RACE_MAPS || {})[R.area]);
  const PLANT_WIN_PRIZE = ['fruit', 'core', 'fitem']; // what every plant-race win adds, by tier
  EXTRA_RACES.push(...MORE_RACES, ...PLANT_RACES);
  PS.raceNames = Object.fromEntries(EXTRA_RACES.map(R => [R.id, R.name]));
  const WILD_RACES = []; // (Solunar plants raced island animals here)
  const FRIEND_COINS = [20, 50, 120]; // instead of the animal when the pouch is full
  const ALL = D.RACES.concat(EXTRA_RACES, WILD_RACES);
  const byId = id => ALL.find(R => R.id === id);
  const tierRating = (R, tier) => { const r = D.RACE_TIERS[tier].rating, k = R.ratingMul || 1; return [r[0] * k, r[1] * k]; };
  // hub order: the original area series, Coral + Cloud, the Grand Prix, then the late-game series
  const HUB_ORDER = (() => {
    const o = []; D.RACES.forEach((R, i) => { if (R.id !== 'grand') o.push(i); });
    EXTRA_RACES.slice(0, 2).forEach(R => o.push(ALL.indexOf(R)));
    D.RACES.forEach((R, i) => { if (R.id === 'grand') o.push(i); });
    EXTRA_RACES.slice(2).filter(R => !R.plants).forEach(R => o.push(ALL.indexOf(R)));
    return o;
  })();
  const PLANT_ORDER = PLANT_RACES.map(R => ALL.indexOf(R));
  // the series list for the side you race against (zombies or other gardeners' plants)
  const sideOrder = () => (ST.raceVs() === 'plants' ? PLANT_ORDER : HUB_ORDER);
  const WILD_ORDER = WILD_RACES.map(R => ALL.indexOf(R));
  // themed words for the segment pop-ups
  const SEG_POP = { egypt: { climb: 'Pyramid climb!', swim: 'Oasis swim!' }, cloud: { climb: 'Roof climb!', fly: 'Glide!' }, graveyard: { climb: 'Tombstone hop!' }, pirate: { swim: 'Splash!', climb: 'Up the mast!' },
    jungle: { climb: 'Vine climb!', swim: 'River swim!', fly: 'Swing!' }, volcano: { swim: 'Hot spring!', climb: 'Lava rocks!' },
    snowy: { climb: 'Icy climb!', fly: 'Sled down!', swim: 'Brrr, chilly!' }, starlight: { fly: 'Fly to the stars!', swim: 'Star pool!' } };
  SEG_POP.jurassic = SEG_POP.jungle; SEG_POP.frostbite = SEG_POP.snowy; SEG_POP.farfuture = SEG_POP.starlight;
  SEG_POP.poolside = { swim: 'Cannonball!', climb: 'Up the ladder!', fly: 'Diving board!' }; SEG_POP.foggynight = { swim: 'Spooky pond!', climb: 'Gravestone hop!' };
  SEG_POP.rooftop = { climb: 'Chimney climb!', fly: 'Roof jump!', swim: 'Rain barrel!' }; SEG_POP.candyland = { swim: 'Lemonade lake!', climb: 'Gumdrop hill!', fly: 'Bounce!' };

  // =====================================================================
  // ITEMS. Odds depend on your place (1st .. 4th): leaders get defence, stragglers get speed.
  // =====================================================================
  const ITEMS = {
    carrot: { name: 'Speed Carrot', mul: 1.4, t: 2.0, stam: 8, pop: 'Zoom!', color: '#ffa94d' },
    shield: { name: 'Bubble Shield', t: 10, pop: 'Bubble!', color: '#9fd8ff' },
    honey: { name: 'Honey Puddle', mul: 0.55, t: 1.3, pop: 'Splat!', color: '#f6c83a' },
    star: { name: 'Rainbow Star', mul: 1.65, t: 2.4, pop: 'Super star!', color: '#fbf236' },
  };
  const ITEM_ODDS = [
    { carrot: 3, shield: 3, honey: 4, star: 0 },
    { carrot: 4, shield: 3, honey: 3, star: 0.5 },
    { carrot: 4, shield: 2, honey: 2, star: 1.5 },
    { carrot: 4, shield: 2, honey: 1, star: 3 },
  ];
  const RIVAL_PICKUP = 0.7; // rivals grab a box this often ("sometimes")

  // =====================================================================
  // DAILY CUP twists
  // =====================================================================
  const MODS = {
    lowgrav: { name: 'Low Gravity', desc: 'Big, floaty jumps!', segMul: { run: 1.06, climb: 1.3, fly: 1.1 } },
    rain: { name: 'Rainy Day', desc: 'Slippery puddles. Watch out!', segMul: { run: 0.96 } },
    giant: { name: 'Giant Mode', desc: 'Everyone is HUGE today!', segMul: { run: 1.1, swim: 0.92 } },
    reverse: { name: 'Backwards Day', desc: 'The course runs the other way!' },
    night: { name: 'Night Race', desc: 'Lanterns light the way.' },
    party: { name: 'Item Party', desc: 'Lots of item boxes!', boxes: 6 },
  };
  const CUP_COINS = [60, 40, 28, 18];       // by place, x (1 + 0.5 * bestTier)
  const CUP_XP = [10, 16, 22, 32];          // by bestTier (like a tier's xp)
  const CUP_EGG_CHANCE = [0.15, 0.05, 0.05, 0.05];
  // =====================================================================
  // TIME TRIAL medals: [bronze, silver, gold] first-time coins per tier (x the series' prize multiplier), and XP once per
  // medal: MEDAL_XP x the tier's race XP, split like race XP (so gold is about half a race win's XP)
  // =====================================================================
  const MEDAL_COINS = [[5, 10, 20], [10, 20, 40], [20, 40, 80]];
  const MEDAL_XP = [0.3, 0.4, 0.5];
  const MEDAL_NAMES = ['Bronze', 'Silver', 'Gold'];
  const GHOST_DT = 0.25;

  // ---------------- small helpers ----------------
  function mulberry(a) { return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function hash(n) { n = (n | 0) * 374761393; n = (n ^ (n >>> 13)) * 1274126177; return ((n ^ (n >>> 16)) >>> 0); }
  function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ramp = body => (PX.RAMPS[body] || PX.RAMPS.mint);
  const nightAmt = () => { try { return PS.clock.night(); } catch (e) { return 0; } };
  const mod = (a, n) => ((a % n) + n) % n;
  const tri = v => Math.abs(mod(v, 2) - 1);
  function safeProp(kind, theme) { try { return PX.prop ? PX.prop(kind, theme) : null; } catch (e) { return null; } }
  function safeItem(kind, id) {
    try { if (PX.item) return PX.item(kind, id); } catch (e) { /* fall through */ }
    return kind === 'egg' ? safeProp('egg') : null;
  }
  function safeCritter(kind, f) { try { return PX.critter(kind, f || 0); } catch (e) { return null; } }
  const sprigAX = () => (PX.SPRIG_AX == null ? 16 : PX.SPRIG_AX);
  const sprigAY = () => (PX.SPRIG_AY == null ? 31 : PX.SPRIG_AY);
  function sprig(look, pose) { return PX.sprig(look, pose || {}); }
  const eggName = kind => (D.SEEDS[kind] ? D.SEEDS[kind].name : 'Seed packet');
  // the first-win prize of a tier: { plant } (a species it unlocks) or { seed } (a seed packet kind)
  function firstPrize(R, tier) {
    const un = D.UNLOCKS['race:' + R.id + '-' + tier];
    if (un === 'starter') return { plant: D.STARTERS.find(x => !ST.isUnlocked(x)) || D.STARTERS.find(x => x !== PS.S.starter) || D.STARTERS[0] };
    if (un && un.startsWith('map:')) return { map: un.slice(4) };
    if (un) return { plant: un };
    return { seed: R.extra ? R.eggs[tier] : (tier === 2 && R.id === 'grand' ? 'golden' : 'normal') };
  }
  const prizeName = (R, tier) => { const fp = firstPrize(R, tier); return fp.plant ? (ST.isUnlocked(fp.plant) ? `${D.PLANTS[fp.plant].name} seeds` : 'a new plant') : fp.map ? `the ${D.GARDEN_MAPS[fp.map].name} map` : eggName(fp.seed); };
  function pickW(odds, r) { const ks = Object.keys(odds), tot = ks.reduce((a, k) => a + odds[k], 0); let x = r * tot; for (const k of ks) { x -= odds[k]; if (x <= 0 && odds[k] > 0) return k; } return ks[0]; }

  // =====================================================================
  // Save data for the new features (PS.S.progress.raceExtra). Reads never create it.
  // =====================================================================
  function xsRead() { const p = PS.S && PS.S.progress, x = p && p.raceExtra; return x && typeof x === 'object' ? x : null; }
  function xs() {
    if (!PS.S.progress || typeof PS.S.progress !== 'object') PS.S.progress = { races: {}, leagues: {} };
    let x = PS.S.progress.raceExtra;
    if (!x || typeof x !== 'object') x = PS.S.progress.raceExtra = {};
    for (const k of ['series', 'trials', 'daily', 'hint']) if (!x[k] || typeof x[k] !== 'object') x[k] = {};
    return x;
  }
  const blankProg = () => ({ runs: 0, wins: 0, best: null });
  function prog(R, tier) {
    if (!R.extra) return ST.raceProgress(R.id, tier);
    const x = xsRead(), p = x && x.series && x.series[R.id + '-' + tier];
    return p && typeof p === 'object' ? Object.assign(blankProg(), p) : blankProg();
  }
  function unlocked(R, tier) {
    if (!R) return false;
    if (!R.extra) return ST.raceUnlocked(R.id, tier);
    if (tier > 0 && !prog(R, tier - 1).wins) return false;
    if (!R.unlock) return true;
    const U = byId(R.unlock.race); return !!U && prog(U, R.unlock.tier).wins > 0;
  }
  const seriesMult = R => (R.extra ? R.mult : 1 + D.RACES.indexOf(R) * 0.15);
  const prizeOf = (R, tier) => Math.round(D.RACE_TIERS[tier].coins * seriesMult(R));
  const medalCoins = (R, tier, k) => Math.round(MEDAL_COINS[tier][k] * seriesMult(R));

  function trialRec(R, tier) { const x = xsRead(), t = x && x.trials && x.trials[R.id + '-' + tier]; return t && typeof t === 'object' ? t : { best: null, m: 0 }; }
  function dayKey(ms) { const d = new Date(ms || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function cupToday(key) { const x = xsRead(), d = x && x.daily; return d && d.day === (key || dayKey()) ? d : { day: key || dayKey(), best: null, runs: 0 }; }
  function msToMidnight() { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1) - n; }
  function fmtWait(ms) { const m = Math.max(1, Math.ceil(ms / 60000)), h = Math.floor(m / 60); return h ? `${h}h ${m % 60}m` : `${m}m`; }

  // =====================================================================
  // Themes (per series area). Colours are DawnBringer-ish to match pixel.js.
  // far2/near/ambient keys add parallax detail; style 'reef' / 'island' change how the track is drawn.
  // =====================================================================
  const TH = {
    meadow: { prop: 'day', sky: ['#9ed5f5', '#b6e0f7', '#cfeaf8', '#e6f5fa'], far: 'hills', farC: ['#c8eac0', '#9fcfa2'], nearC: ['#a9dc9e', '#7fbe86', '#93d38c', '#71b474'],
      far2: 'mountains', far2C: ['#d6e2f6', '#bccae8', '#ffffff', '#a6b6dc'], near: 'trees', birds: true, fence: 'wood',
      top: ['#addf83', '#9cd273', '#86c066', '#f4d6b0'], soil: ['#ecc9a0', '#dcb48a'], soilDot: '#f6dcbc', tuft: '#86c066', dots: ['#ffd3e2', '#fff2a6'],
      water: ['#e8fbff', '#a2dcf4', '#80c8ec', '#ffffff'], rock: ['#e4e2f0', '#c4c2da', '#f4f2fc', '#ffffff', '#a8dc90'],
      cloud: ['#ffffff', '#f4f8ff', '#dce6f8'], puff: ['#ffffff', '#e2eafb', '#a8badf'], crowd: ['hare', 'squirrel', 'duck', 'frog', 'sparrow', 'bee'],
      props: [['bush', 4], ['flowerbed', 2], ['rock', 2], ['tree', 1]] },
    beach: { prop: 'day', sky: ['#8dd2f5', '#a7dcf6', '#c3e8f8', '#e0f4fb'], far: 'sea', farC: ['#93daf2', '#c8eab8', '#ffffff', '#72c8ea', '#a8dca8'], nearC: ['#c8f0fa', '#9adcf2'],
      boat: true, birds: true, fence: 'rope',
      top: ['#fcebc8', '#f7e0b6', '#e9cd9c', '#f2d8ac'], soil: ['#f6dcb0', '#ecca98'], soilDot: '#fff0d4', tuft: null, dots: ['#ffffff', '#ffc4d6'],
      water: ['#e8fbff', '#9ae0f2', '#74c8ea', '#ffffff'], rock: ['#f2d4a8', '#dcb484', '#fbe6c4', '#fff4dc', '#a8dc90'],
      cloud: ['#ffffff', '#f4f8ff', '#dce6f8'], puff: ['#ffffff', '#e2eafb', '#a8badf'], crowd: ['crab', 'seal', 'seagull', 'otter', 'pelican', 'starfish'],
      props: [['palm', 3], ['umbrella', 2], ['sandcastle', 2], ['shells', 2], ['rock', 1]] },
    moonlit: { prop: 'night', dark: true, sky: ['#3d4188', '#4a4f9a', '#5a5fab', '#6c6fba'], far: 'peaks', farC: ['#4e58a0', '#3e4888'], nearC: ['#4a7c9c', '#3a6684', '#5c93b0', '#467690'],
      far2: 'aurora', near: 'pines', fireflies: true,
      top: ['#74c6b2', '#64b6a4', '#4f9c8e', '#8a86c8'], soil: ['#7a78bc', '#6a68ac'], soilDot: '#9894d4', tuft: '#4f9c8e', dots: ['#d8c2ff', '#bfe8ff'],
      water: ['#e2d4ff', '#8c8ad8', '#7072c4', '#ffffff'], rock: ['#9a9ccc', '#7e80b4', '#b4b6dc', '#d4d6f0', '#8fe0c8'],
      cloud: ['#8a88d0', '#a4a2e0', '#7472bc'], puff: null, crowd: ['owl', 'raccoon', 'hedgehog', 'moondeer', 'wolf', 'moth'],
      props: [['glowshroom', 4, 1], ['crystal', 2, 1], ['lantern', 1, 1], ['bush', 2]] },
    candy: { prop: 'candy', sky: ['#ffc4db', '#ffd2e4', '#ffdfeb', '#ffeef4'], far: 'gumdrops', farC: ['#ffa6cc', '#c8b0f4', '#a8e8a0', '#fff0a0'], nearC: ['#a8e6cc', '#86ccb0'],
      far2: 'softserve', far2C: ['#fff4f8', '#ffc4da', '#ffe0b8'], fence: 'cane', birds: true,
      top: ['#fff2f7', '#ffdeeb', '#f2bcd4', '#ffe6f0'], soil: ['#f6d2a8', '#ecc092'], soilDot: '#fff4e0', tuft: null, dots: ['#fff08a', '#9fd0ff', '#a8e88a', '#ff9ec4'], sprinkles: true,
      water: ['#fffae8', '#9eeadc', '#7cd6c6', '#ffffff'], rock: ['#ffc4da', '#ec9cbe', '#ffe4ee', '#ffffff', '#ffffff'], stripes: true,
      cloud: ['#ffffff', '#fff2f8', '#f6d4e6'], puff: ['#ffffff', '#ffe2f0', '#e6a8c8'], crowd: ['gummybear', 'cottonsheep', 'marshbunny', 'chocomouse', 'sugarfinch', 'lollisnail'],
      props: [['lollitree', 3], ['candycane', 3], ['gumdrops', 3], ['cupcake', 1]] },
    coral: { prop: 'day', style: 'reef', noSun: true, rays: true, fish: true, bubbles: true, surface: true,
      sky: ['#8adcec', '#74cce4', '#62bcdc', '#54acd2'], far2: 'reefs', far2C: ['#6ab8d8', '#7cc4e0'], far: 'reef', farC: ['#ffa6b8', '#ffc49a', '#d0b0f4', '#fff0c4'], nearC: ['#7cd0a8', '#5cb88e'], near: 'kelp',
      top: ['#fdf0d0', '#f6e4bc', '#e8d0a0', '#f0dcb0'], soil: ['#f0dcb0', '#e2c898'], soilDot: '#fff4dc', tuft: null, dots: ['#ffffff', '#ffb0a0'],
      water: ['#e8fcff', '#7cc8e4', '#5cb0d8', '#ffffff'], rock: ['#ffb0a0', '#ec8c84', '#ffd4c4', '#ffe8e0', '#ffb8d8'],
      cloud: ['#bfeef8', '#e8fcff', '#9edcee'], puff: null, crowd: ['seahorse', 'pufferfish', 'starfish', 'crab', 'sodafish', 'jellyocto'],
      props: [['r:kelp', 4], ['r:coral', 3], ['r:brain', 2], ['r:anemone', 2], ['r:clam', 1], ['r:chest', 0.5], ['c:starfish', 1]] },
    cloud: { prop: 'day', style: 'island', birds: true,
      sky: ['#8ccdf4', '#a6d9f6', '#c2e6f8', '#e0f2fb'], far2: 'isles', far: 'cloudsea', farC: ['#ffffff', '#e4ecfa', '#c8d6f0'], nearC: ['#ffffff', '#e8f0fc', '#ccd8f0'], near: 'clouds',
      top: ['#c4f09a', '#b0e486', '#94cc72', '#e8d4b8'], soil: ['#e8d4b8', '#d8c0a2'], soilDot: '#c4ac8e', tuft: '#94cc72', dots: ['#ffd3e2', '#fff2a6'],
      water: ['#eefaff', '#b4e2fc', '#94ccf4', '#ffffff'], rock: ['#ff9fb4', '#ffc68e', '#fff09a', '#b8ec9a', '#9fd0ff', '#c8aaf0'],
      cloud: ['#ffffff', '#f4f8ff', '#dce6f8'], puff: ['#ffffff', '#e8effc', '#b4c4e4'], crowd: ['sparrow', 'butterfly', 'seagull', 'bee', 'cottonsheep', 'sugarfinch'],
      props: [['bush', 2], ['flowerbed', 3], ['r:windmill', 1], ['r:pillar', 1.5], ['r:balloon', 2]] },
    jungle: { prop: 'day', birds: true, parrots: true, vines: true, fence: null,
      sky: ['#a2d9cc', '#b6e1cc', '#cdeacd', '#e5f2d3'], far2: 'canopy', far2C: ['#a8dcb0', '#90cc9e', '#78b48a'], far: 'hills', farC: ['#86c896', '#6aac7e'], nearC: ['#6eb47c', '#56986a', '#8ccf8e', '#6aae78'], near: 'trees',
      top: ['#a8dc7c', '#96ce6c', '#7cb85e', '#c8a07a'], soil: ['#cfa47e', '#be9270'], soilDot: '#e2bc96', tuft: '#7cb85e', dots: ['#ffb8c8', '#fff09a'],
      water: ['#e6f8e2', '#94d6c0', '#74c0a8', '#ffffff'], rock: ['#c4c6dc', '#a4a6c4', '#dcdeee', '#eeeefa', '#9cd884'], moss: true,
      cloud: ['#c8ecc4', '#e4f6e0', '#a8d8a4'], puff: ['#ffffff', '#e4f2ea', '#a6c8b8'], crowd: ['frog', 'squirrel', 'butterfly', 'bee', 'raccoon', 'dinosaur'],
      props: [['r:fern', 3], ['r:bigleaf', 3], ['r:bamboo', 2], ['r:totem', 1], ['flowerbed', 1]] },
    volcano: { prop: 'day', noSun: true, embers: true, steam: true, cracks: true,
      sky: ['#5c3c72', '#7a4b80', '#a65f82', '#d98483'], far2: 'volcanoes', far2C: ['#8a6290', '#74507e', '#ffc078'], far: 'peaks', farC: ['#7e5a88', '#664872'], nearC: ['#8c6c92', '#72587c'],
      top: ['#a88aa6', '#9a7c9a', '#80668a', '#8c7090'], soil: ['#8c7090', '#7e6284'], soilDot: '#ffb07a', tuft: null, dots: ['#ffb07a', '#fff09a'],
      water: ['#eefff8', '#9ce2d2', '#7ccabc', '#ffffff'], rock: ['#9e82a0', '#806684', '#b89cb8', '#ccb4cc', '#ffb07a'], lava: true,
      cloud: ['#c4b0c8', '#ddd0e0', '#a894b0'], puff: ['#e6dcec', '#c8b8d4', '#9a88aa'], crowd: ['dinosaur', 'ram', 'hedgehog', 'fox', 'dragon', 'phoenix'],
      props: [['r:lavarock', 3], ['r:vent', 2], ['r:charred', 2], ['r:obsidian', 2, 1]] },
    snowy: { prop: 'day', snow: true, sled: true, birds: false,
      sky: ['#a7cdf2', '#bcd9f4', '#d2e6f7', '#e8f2fb'], far2: 'mountains', far2C: ['#d4e0f6', '#b8c8ea', '#ffffff', '#a2b2dc'], far: 'hills', farC: ['#f2f6fd', '#c8d6ee'], nearC: ['#9ccfc0', '#7cb4a6', '#b8e6d6', '#86c8b4'], near: 'pines', nearTop: '#ffffff',
      top: ['#ffffff', '#eef4fd', '#cddaf0', '#d8e4f6'], soil: ['#c8d4ee', '#b4c2e2'], soilDot: '#e2eafa', tuft: null, dots: ['#cfe6ff', '#ffffff'],
      water: ['#f2fcff', '#a4dcf4', '#84c8ec', '#ffffff'], rock: ['#d4f0fa', '#a8d8ee', '#eefaff', '#ffffff', '#cfeeff'], ice: true,
      cloud: ['#ffffff', '#f4f8ff', '#dce6f8'], puff: ['#ffffff', '#e8eef8', '#b0c0dc'], crowd: ['yeti', 'seal', 'wolf', 'owl', 'hare', 'moondeer'],
      props: [['r:snowpine', 4], ['r:snowman', 2], ['r:igloo', 1], ['rock', 1]] },
    starlight: { prop: 'night', dark: true, shooting: true, sparkleFloor: true,
      sky: ['#2e2a6e', '#3a3482', '#4a4296', '#5c50a8'], far2: 'planets', far: 'peaks', farC: ['#5a4ea6', '#4a3e92'], nearC: ['#6a5cb6', '#5a4ca4'],
      top: ['#f2e8ff', '#e2d2fc', '#c4aef0', '#9e8ad8'], soil: ['#8a78cc', '#7a68bc'], soilDot: '#fff3a0', tuft: null, dots: ['#fff3a0', '#bfe8ff'],
      water: ['#f6e4ff', '#c4a4f0', '#a888e0', '#ffffff'], rock: ['#b4b0dc', '#9894c8', '#d0ccec', '#e8e6f8', '#fff3a0'],
      cloud: ['#8e80d0', '#aa9ee0', '#7464bc'], puff: null, crowd: ['fairy', 'unicorn', 'moth', 'firefly', 'owl', 'moondeer'],
      props: [['r:starlamp', 2, 1], ['crystal', 3, 1], ['r:moonrock', 3], ['glowshroom', 1, 1]] },
  };
  // the crowd at the start and finish: element sprites
  const CROWD_EL = { meadow: ['normal', 'fire', 'rock', 'electric'], beach: ['water', 'rock', 'electric', 'fire'], moonlit: ['dark', 'poison', 'magic', 'ice'], candy: ['magic', 'normal', 'water'],
    coral: ['water', 'ice', 'magic'], cloud: ['electric', 'normal', 'magic'], jungle: ['poison', 'rock', 'water'], volcano: ['fire', 'rock', 'dark'], snowy: ['ice', 'water', 'normal'], starlight: ['laser', 'robot', 'magic'] };
  for (const [k, list] of Object.entries(CROWD_EL)) if (TH[k]) TH[k].crowd = list.map(e => 'el:' + e);
  TH.frontyard = Object.assign({}, TH.meadow, { props: [['hedge', 4], ['flowerbed', 2], ['gnome', 1], ['mailbox', 1], ['bush', 2], ['tree', 1]] });
  TH.backyard = Object.assign({}, TH.meadow, { props: [['hedge', 4], ['poolchair', 2], ['lifering', 1], ['flowerpot_bloom', 2], ['tree', 1]], water: ['#eefcff', '#8ee2f4', '#6ccfec', '#ffffff'] });
  TH.graveyard = Object.assign({}, TH.moonlit, { top: ['#86c0b4', '#76b0a6', '#5e968e', '#8a86c8'], props: [['gravestone', 4, 1], ['gravestone2', 3, 1], ['glowshroom', 2, 1], ['deadtree', 1, 1], ['lantern', 1, 1]] });
  TH.pirate = Object.assign({}, TH.beach, { props: [['palm', 3], ['barrel', 2], ['cannon', 1], ['treasure', 1], ['shells', 2]] });
  TH.egypt = Object.assign({}, TH.beach, { far: 'hills', farC: ['#f6e0ae', '#e0c48c'], nearC: ['#efd196', '#d4b074'], boat: false, fence: 'rope', pyramids: true,
    top: ['#f9e6b4', '#f2da9e', '#e2c68a', '#f2d8a4'], soil: ['#f2d8a4', '#e6c890'], soilDot: '#fff0cc', crowd: ['el:fire', 'el:rock', 'el:laser', 'el:magic'],
    water: ['#eefcff', '#8ee0ec', '#6ccce0', '#ffffff'], props: [['datepalm', 3], ['obelisk', 2], ['urn', 2], ['pyramid', 1], ['rock', 1]] });
  const GRAND_ZONES = ['frontyard', 'graveyard', 'pirate', 'egypt'];
  // race scenery for the newer garden maps (art-world2.js): same keys as above, crowd given as 'el:<element>' ids
  for (const [k, th] of Object.entries(PX.RACE_MAPS || {})) if (!TH[k]) TH[k] = th;


  // =====================================================================
  // Course: generated from the series mix + length, seeded by series & tier.
  // opt (Daily Cup): { R, m, seed, reverse, boxes, segMul, mods }
  // =====================================================================
  function buildCourse(ri, tier, opt) {
    opt = opt || {};
    const R = opt.R || ALL[ri], Tr = D.RACE_TIERS[tier] || D.RACE_TIERS[0];
    const si = R.extra ? 40 + R.seed : ri;
    const rng = mulberry(opt.seed != null ? opt.seed : 9001 + si * 131 + tier * 17);
    const mix = R.mix, W = SEGS.reduce((a, k) => a + (mix[k] || 0), 0) || 1;
    const TR = tierRating(R, D.RACE_TIERS[tier] ? tier : 0), m = opt.m || mulOf((TR[0] + TR[1]) / 2);
    const dur = T.targetSec * Math.pow(R.length / 1100, T.targetExp);
    const time = k => dur * (mix[k] || 0) / W;
    let nS = mix.swim ? clamp(Math.round(time('swim') / 6), 1, 5) : 0;
    let nC = (mix.climb || mix.fly) ? clamp(Math.round((time('climb') + time('fly')) / 9), 1, 4) : 0;
    while (nS + nC > 1 && time('run') / (nS + nC + 1) < T.minRunSec) { if (nS >= nC) nS--; else nC--; }
    const blocks = [];
    for (let i = 0; i < nS; i++) blocks.push('swim');
    for (let i = 0; i < nC; i++) blocks.push('cf');
    for (let i = blocks.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [blocks[i], blocks[j]] = [blocks[j], blocks[i]]; }
    for (let pass = 0; pass < 4; pass++) for (let i = 1; i < blocks.length; i++) if (blocks[i] === blocks[i - 1]) {
      const j = blocks.findIndex((b, k) => b !== blocks[i] && k !== i - 1 && (k === 0 || blocks[k - 1] !== blocks[i]) && (k + 1 >= blocks.length || blocks[k + 1] !== blocks[i]));
      if (j >= 0) [blocks[i], blocks[j]] = [blocks[j], blocks[i]];
    }
    const split = (total, n, jit, ends) => {
      if (!n) return [];
      const w = []; for (let i = 0; i < n; i++) w.push(1 - jit + 2 * jit * rng());
      if (ends && n > 1) { w[0] *= 1.35; w[n - 1] *= 1.2; }
      const s = w.reduce((a, b) => a + b, 0); return w.map(v => total * v / s);
    };
    const runs = split(time('run'), blocks.length + 1, 0.35, true);
    const swims = split(time('swim'), nS, 0.25), climbs = split(time('climb') || 1.5, nC, 0.25), flys = split(time('fly') || 1.5, nC, 0.25);
    const MIN = { run: 34, swim: 50, climb: 26, fly: 60 };
    let segs = []; let x = 0, si2 = 0, ci = 0;
    const push = (type, sec) => { const len = Math.max(MIN[type], Math.round(sec * T.base[type] * m)); segs.push({ type, x0: x, x1: x + len, len }); x += len; };
    push('run', runs[0]);
    blocks.forEach((b, i) => {
      if (b === 'swim') push('swim', swims[si2++]);
      else { push('climb', climbs[ci]); push('fly', flys[ci]); ci++; }
      push('run', runs[i + 1]);
    });
    if (opt.reverse) { // same pieces, other order (every climb still leads into its glide)
      segs.reverse();
      for (let i = 0; i < segs.length - 1; i++) if (segs[i].type === 'fly' && segs[i + 1].type === 'climb') { const a = segs[i]; segs[i] = segs[i + 1]; segs[i + 1] = a; i++; }
      x = 0; for (const s of segs) { s.x0 = x; s.x1 = x + s.len; x = s.x1; }
    }
    const LEN = x;
    // theme zones
    let zones;
    if (R.id === 'grand') {
      const bounds = [];
      for (let k = 1; k < 4; k++) {
        const want = LEN * k / 4; let best = null;
        for (const s of segs) if (s.type === 'run' && s.x0 > 0) { const mid = Math.round((s.x0 + s.x1) / 2); if (!best || Math.abs(mid - want) < Math.abs(best - want)) best = mid; }
        bounds.push(best == null ? Math.round(want) : best);
      }
      zones = GRAND_ZONES.map((th, k) => ({ th, x0: k ? bounds[k - 1] : -1e9, x1: k < 3 ? bounds[k] : 1e9 }));
    } else zones = [{ th: R.area in TH ? R.area : 'frontyard', x0: -1e9, x1: 1e9 }];
    const C = { ri, tier, R, segs, LEN, zones, decor: [], segMul: opt.segMul || null, mods: opt.mods || {} };
    C.after = { type: 'run', x0: LEN, x1: 1e9, len: 1e9, after: true };
    // decor in run stretches (and a little before the start line)
    const drng = mulberry(opt.seed != null ? opt.seed + 77 : 77 + si * 1009 + tier * 7);
    const places = [{ x0: -120, x1: -8 }].concat(segs.filter(s => s.type === 'run').map(s => ({ x0: s.x0 + 10, x1: s.x1 - 10 })), [{ x0: LEN + 30, x1: LEN + 200 }]);
    for (const p of places) {
      let px = p.x0 + Math.floor(drng() * 18);
      while (px < p.x1) {
        if (Math.abs(px - LEN) > 16 && Math.abs(px) > 10) {
          const th = TH[themeAt(C, px)], tot = th.props.reduce((a, q) => a + q[1], 0);
          let r = drng() * tot, pick = th.props[0];
          for (const q of th.props) { r -= q[1]; if (r <= 0) { pick = q; break; } }
          C.decor.push({ x: px, kind: pick[0], glow: !!pick[2], th: themeAt(C, px), flip: drng() < 0.4 });
        }
        px += 34 + Math.floor(drng() * 46);
      }
    }
    // item boxes (a row across all lanes) and the cheering crowd — separate rngs so old courses stay identical
    const brng = mulberry((opt.seed != null ? opt.seed : si * 31 + tier * 7) + 4242);
    const nb = opt.boxes || 3; C.boxes = [];
    for (let k = 1; k <= nb; k++) C.boxes.push(Math.round(clamp(LEN * k / (nb + 1) + (brng() - 0.5) * LEN * 0.08, 70, LEN - 50)));
    C.crowd = [];
    const thS = TH[themeAt(C, -10)], thF = TH[themeAt(C, LEN + 10)];
    for (let k = 0; k < 3; k++) C.crowd.push({ x: -36 - k * 15, kind: thS.crowd[Math.floor(brng() * thS.crowd.length)], flip: false, ph: brng() * 6 });
    for (let k = 0; k < 4; k++) C.crowd.push({ x: LEN + 30 + k * 15, kind: thF.crowd[Math.floor(brng() * thF.crowd.length)], flip: true, ph: brng() * 6 });
    return C;
  }
  function themeAt(C, x) { const z = C.zones; for (let i = 0; i < z.length; i++) if (x < z[i].x1) return z[i].th; return z[z.length - 1].th; }
  function segAtC(C, x) { if (x < 0) return C.segs[0]; const s = C.segs; for (let i = 0; i < s.length; i++) if (x < s[i].x1) return s[i]; return C.after; }

  // =====================================================================
  // Racers & simulation (pure: also used headless for balance checks and medal times)
  // =====================================================================
  function makeRacer(d) {
    const sm = T.stamBase + T.stamPer * d.stamR;
    const mul = {}; for (const k of SEGS) mul[k] = mulOf(d.rating[k]);
    return { name: d.name, look: d.look, rating: d.rating, mul, isPlayer: !!d.isPlayer, cheer: d.cheer || null,
      color: ramp(d.look && d.look.body)[1], x: 0, si: 0, stam: sm, stamMax: sm, tired: false, boostT: 0, boostMul: 1, stumbleT: 0,
      finished: false, time: 0, projTime: 0, nextBoost: rnd(1.5, 3.5), emote: null, emoteT: 0, animT: Math.random() * 3,
      prevType: 'run', lane: 0, tiredCount: 0, cheers: { perfect: 0, good: 0, miss: 0 },
      item: null, useIn: 0, holdT: 0, itemT: 0, itemMul: 1, shieldT: 0, starT: 0, slowT: 0, slowMul: 1, slipIn: 2 + Math.random() * 3 };
  }
  function segOf(C, r) {
    if (r.x < 0) return C.segs[0];
    while (r.si < C.segs.length && r.x >= C.segs[r.si].x1) r.si++;
    return r.si < C.segs.length ? C.segs[r.si] : C.after;
  }
  function curSpeed(C, r) {
    if (r.finished) return r.x < C.LEN + T.finishJog ? 20 : 0;
    const seg = segOf(C, r);
    let v = T.base[seg.type] * r.mul[seg.type];
    if (C.segMul && C.segMul[seg.type]) v *= C.segMul[seg.type];
    if (r.tired) v *= T.tired.mul;
    // cheer boost and item boost don't fully stack: the bigger one counts, the smaller adds a quarter
    const b = r.boostT > 0 ? r.boostMul : 1, it = r.itemT > 0 ? r.itemMul : 1;
    v *= Math.max(b, it) + 0.25 * (Math.min(b, it) - 1);
    if (r.stumbleT > 0) v *= T.miss.mul;
    if (r.slowT > 0) v *= r.slowMul;
    return v;
  }
  function setEmote(r, k, t) { r.emote = k; r.emoteT = t; }
  // a Rainbow Star or Bubble Shield stops the next slowdown. Returns true when blocked.
  function guard(r, ctx) {
    if (r.starT > 0) return true;
    if (r.shieldT > 0) {
      r.shieldT = 0;
      if (ctx.fx) { ring(r, '#bff4ff', 10); if (r.isPlayer) { PX.Sound.play('crack'); pop('Blocked!', '#9fd8ff', 22); } }
      return true;
    }
    return false;
  }
  function applyCheer(r, kind, ctx) {
    r.cheers[kind]++;
    if (kind === 'miss') { if (guard(r, ctx)) return; r.stumbleT = T.miss.t; if (ctx.fx) setEmote(r, '?', 0.9); return; }
    const c = T[kind];
    r.boostMul = Math.max(r.boostT > 0 ? r.boostMul : 1, c.mul); r.boostT = Math.max(r.boostT, c.t);
    r.stam = Math.min(r.stamMax, r.stam + c.stam);
    if (kind === 'perfect' && r.tired) { r.tired = false; r.stam = Math.max(r.stam, 16); }
    if (r.emote === 'swirl' && !r.tired) r.emote = null;
    if (ctx.fx) {
      if (r.isPlayer) setEmote(r, kind === 'perfect' ? 'sparkle' : 'heart', 0.8);
      else if (kind === 'perfect') setEmote(r, '!', 0.6);
      burst(r, kind === 'perfect' ? 7 : 3);
    }
  }
  // ---------------- items ----------------
  function pickup(r, ctx) {
    if (r.item) return;
    if (!r.isPlayer && ctx.rng() > RIVAL_PICKUP) return;
    const place = clamp(ctx.placeOf ? ctx.placeOf(r) : 1, 0, 3);
    const odds = Object.assign({}, ITEM_ODDS[place]);
    if (ctx.C.mods && ctx.C.mods.party) odds.star += 1;
    r.item = pickW(odds, ctx.rng()); r.useIn = rnd(0.8, 3.2); r.holdT = 0;
    if (ctx.fx) {
      sparkle(r, ['#f07a84', '#fbf236', '#99e550', '#639bff', '#c9a2f0'], 8);
      if (r.isPlayer) { PX.Sound.play('chime'); PX.buzz(10); pop(ITEMS[r.item].name + '!', ITEMS[r.item].color, 20, 1.4, true); itemHint(); }
    }
  }
  function activate(r, kind, ctx) {
    r.item = null;
    const I = ITEMS[kind];
    if (kind === 'carrot') { r.itemMul = Math.max(r.itemT > 0 ? r.itemMul : 1, I.mul); r.itemT = Math.max(r.itemT, I.t); r.stam = Math.min(r.stamMax, r.stam + I.stam); }
    else if (kind === 'shield') r.shieldT = I.t;
    else if (kind === 'honey') { if (ctx.W) ctx.W.honey.push({ x: Math.round(r.x) - 5, owner: r, hit: [], t: 0 }); }
    else if (kind === 'star') {
      r.starT = I.t; r.itemMul = I.mul; r.itemT = Math.max(r.itemT, I.t); r.slowT = 0; r.stumbleT = 0;
      if (r.tired) { r.tired = false; r.stam = Math.max(r.stam, r.stamMax * 0.35); if (r.emote === 'swirl') r.emote = null; }
    }
    if (ctx.fx) {
      if (kind === 'carrot') sparkle(r, ['#ffa94d', '#fff27a'], 6);
      if (kind === 'shield') ring(r, '#9fd8ff', 8);
      if (kind === 'honey') for (let i = 0; i < 6; i++) race.parts.push({ lane: r.lane, x: r.x - 4 + rnd(-3, 3), y: -rnd(4, 10), vx: rnd(-16, 4), vy: rnd(-30, -10), g: 110, life: 0.5, spr: PX.fx('drop', '#f6c83a'), rel: true });
      if (kind === 'star') sparkle(r, ['#f07a84', '#fbf236', '#99e550', '#639bff', '#c9a2f0'], 12);
      if (r.isPlayer) {
        pop(I.pop, I.color, 26);
        if (kind === 'carrot') { PX.Sound.play('whoosh'); PX.Sound.play('go'); }
        else if (kind === 'shield') PX.Sound.play('snap');
        else if (kind === 'honey') { PX.Sound.play('munch'); PX.Sound.play('splash'); }
        else PX.Sound.play('level');
        PX.buzz(15);
      } else if (kind !== 'shield') setEmote(r, kind === 'honey' ? 'note' : '!', 0.7);
    }
  }
  function aiUse(r, ctx) {
    const k = r.item;
    if (k === 'honey') {
      const behind = ctx.W.racers.some(o => o !== r && !o.finished && o.x < r.x && r.x - o.x < 90);
      if (!behind && r.holdT < 6) { r.useIn = 0.6; r.holdT += 0.6; return; }
    }
    if (k === 'carrot' && r.boostT > 0 && r.holdT < 4) { r.useIn = 0.5; r.holdT += 0.5; return; }
    activate(r, k, ctx);
  }
  function stepRacer(r, dt, ctx) {
    const C = ctx.C;
    r.animT += dt;
    if (r.emoteT > 0) { r.emoteT -= dt; if (r.emoteT <= 0) r.emote = r.tired ? 'swirl' : null; }
    if (r.finished) { r.x = Math.min(C.LEN + T.finishJog, r.x + 20 * dt); return; }
    const seg = segOf(C, r);
    if (seg.type !== r.prevType) { if (ctx.fx) onSegEnter(r, seg); r.prevType = seg.type; }
    const v = curSpeed(C, r);
    r.boostT = Math.max(0, r.boostT - dt); r.stumbleT = Math.max(0, r.stumbleT - dt);
    if (r.itemT > 0) r.itemT = Math.max(0, r.itemT - dt);
    if (r.slowT > 0) r.slowT = Math.max(0, r.slowT - dt);
    if (r.starT > 0) r.starT = Math.max(0, r.starT - dt);
    if (r.shieldT > 0) r.shieldT = Math.max(0, r.shieldT - dt);
    if (r.tired) {
      r.stam += T.tired.regen * dt;
      if (r.stam >= r.stamMax * T.tired.until) { r.tired = false; if (r.emote === 'swirl') r.emote = null; }
    } else {
      if (r.starT <= 0) r.stam -= T.drain[seg.type] * dt;
      if (r.stam <= 0) {
        if (guard(r, ctx)) r.stam = r.stamMax * 0.35;
        else { r.stam = 0; r.tired = true; r.tiredCount++; r.emote = 'swirl'; r.emoteT = 0; if (ctx.fx && r.isPlayer) PX.Sound.play('miss'); }
      }
    }
    if (r.cheer) {
      r.nextBoost -= dt;
      if (r.nextBoost <= 0) {
        r.nextBoost = rnd(T.ring.every[0], T.ring.every[1]);
        const u = ctx.rng(), c = r.cheer;
        const kind = u < c.p ? 'perfect' : u < c.p + c.g ? 'good' : u < c.p + c.g + c.m ? 'miss' : null;
        if (kind) applyCheer(r, kind, ctx);
      }
    }
    // rainy day: run stretches are slippery for everyone
    if (C.mods.rain && seg.type === 'run' && !seg.after) {
      r.slipIn -= dt;
      if (r.slipIn <= 0) {
        r.slipIn = rnd(3.5, 6.5);
        if (!guard(r, ctx)) {
          r.slowT = 0.6; r.slowMul = 0.5;
          if (ctx.fx) { setEmote(r, '!', 0.6); for (let i = 0; i < 5; i++) race.parts.push({ lane: r.lane, x: r.x + rnd(-4, 4), y: -1, vx: rnd(-18, 18), vy: rnd(-30, -12), g: 110, life: 0.45, spr: PX.fx('drop', '#b8d4ff'), rel: true }); if (r.isPlayer) { PX.Sound.play('splash'); pop('Slip!', '#9fd8ff', 20); } }
        }
      }
    }
    if (ctx.W && r.item && !r.isPlayer) { r.useIn -= dt; if (r.useIn <= 0) aiUse(r, ctx); }
    const nx = r.x + v * dt;
    if (ctx.items && C.boxes) for (const bx of C.boxes) if (r.x < bx && nx >= bx) pickup(r, ctx);
    if (ctx.W && ctx.W.honey.length) for (const h of ctx.W.honey) {
      if (h.owner === r || h.hit.indexOf(r) >= 0 || !(r.x < h.x && nx >= h.x)) continue;
      h.hit.push(r);
      if (!guard(r, ctx)) {
        r.slowT = ITEMS.honey.t; r.slowMul = ITEMS.honey.mul;
        if (ctx.fx) { setEmote(r, '?', 0.9); if (r.isPlayer) { PX.Sound.play('thud'); pop('Sticky!', '#f6c83a', 22); } }
      }
    }
    if (nx >= C.LEN) { r.time = ctx.t - dt + dt * (C.LEN - r.x) / (nx - r.x); r.finished = true; r.x = nx; ctx.onFinish && ctx.onFinish(r); }
    else r.x = nx;
  }
  const finalTime = r => (r.finished ? r.time : r.projTime || 999);
  const cheerOf = arr => ({ p: arr[0], g: arr[1], m: arr[2] });
  function playerRatings(s) { const o = {}; for (const k of SEGS) o[k] = ST.raceRating(s, k); return o; }
  // rivals for the extra series: same recipe as state.raceRivals, own seed
  function extraRivals(R, tier) {
    const Tr = D.RACE_TIERS[tier], TR = tierRating(R, tier);
    let seed = (40 + R.seed) * 97 + tier * 13; const sr = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
    const used = new Set();
    return [0, 1, 2].map(i => {
      const base = TR[0] + (TR[1] - TR[0]) * (i / 2);
      const rt = () => +Math.min(TR[1], base * (0.8 + sr() * 0.4)).toFixed(2); // never stronger than the tier's stated range
      const side = R.plants ? 'plants' : 'zombies';
      let rl = ST.rivalLook(sr, tier, side); for (let k = 0; k < 4 && used.has(JSON.stringify(rl.look)); k++) rl = ST.rivalLook(sr, tier, side); used.add(JSON.stringify(rl.look));
      return { name: rl.name, look: rl.look, rating: { run: rt(), swim: rt(), climb: rt(), fly: rt(), stamina: rt() }, cheer: Tr.cheerSkill };
    });
  }
  // ---------------- wild animal rivals ----------------
  // Each animal's speed per segment comes from what it's good at (D.ANIMALS gives; climb uses power) and where it lives.
  const WHERE_MUL = {
    water: { run: 0.7, climb: 0.75, swim: 1.15, fly: 0.85 },
    air: { run: 0.95, climb: 0.9, swim: 0.75, fly: 1.12 },
    land: { run: 1, climb: 1, swim: 0.85, fly: 1 },
    coast: { run: 1, climb: 1, swim: 1.05, fly: 1 },
  };
  function animalFactors(id) {
    const a = D.ANIMALS[id] || {}, g = a.gives || {}, wm = WHERE_MUL[a.where] || WHERE_MUL.land, f = {};
    for (const k of SEGS) f[k] = clamp(0.8 + (g[D.RACE_STAT[k]] || 0) * 0.03, 0.6, 1.3) * wm[k];
    f.stamina = clamp(0.85 + (g.stamina || 0) * 0.025, 0.7, 1.25);
    return f;
  }
  // Beginner animals are poor fits for the course and Master ones are specialists, so the level is nudged to keep the curve fair
  const WILD_TIER_K = [1.12, 1.0, 0.92];
  const wildLevel = (R, tier) => tierRating(R, tier).map(v => v * WILD_TIER_K[tier]);
  const wildCache = {};
  // the 3 animals of a wild race tier: slow-fitting animals in Beginner, the best fits for this course in Master
  function wildAnimals(R, tier) {
    const key = R.id; if (!wildCache[key]) {
      const W = SEGS.reduce((a, k) => a + (R.mix[k] || 0), 0);
      const ids = Object.keys(D.ANIMALS).filter(id => D.ANIMALS[id].area === R.area);
      const fit = id => { const f = animalFactors(id); return SEGS.reduce((a, k) => a + f[k] * (R.mix[k] || 0) / W, 0); };
      wildCache[key] = ids.sort((a, b) => fit(a) - fit(b) || (a < b ? -1 : 1));
    }
    const list = wildCache[key], n = list.length; if (!n) return [];
    const start = [0, Math.max(0, Math.round(n / 2) - 2), Math.max(0, n - 3)][tier];
    const out = []; for (let i = 0; i < 3; i++) out.push(list[Math.min(n - 1, start + i)]);
    return out;
  }
  const friendOf = (R, tier) => { const a = wildAnimals(R, tier); return a[a.length - 1]; };
  const animalColor = {};
  function critterColor(id) {
    if (animalColor[id]) return animalColor[id];
    let best = '#8c93a8';
    try {
      const c = safeCritter(id), d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data, n = {};
      for (let i = 0; i < d.length; i += 4) if (d[i + 3] > 200 && !(d[i] === 34 && d[i + 1] === 32 && d[i + 2] === 52)) { const k = '#' + [d[i], d[i + 1], d[i + 2]].map(v => v.toString(16).padStart(2, '0')).join(''); n[k] = (n[k] || 0) + 1; }
      best = Object.keys(n).sort((a, b) => n[b] - n[a])[0] || best;
    } catch (e) { /* canvas may be unavailable headless */ }
    return (animalColor[id] = best);
  }
  function wildRivals(R, tier) {
    const TR = wildLevel(R, tier), cheer = cheerOf(D.RACE_TIERS[tier].cheerSkill);
    return wildAnimals(R, tier).map((id, i) => {
      const base = TR[0] + (TR[1] - TR[0]) * (i / 2), f = animalFactors(id), rating = {};
      for (const k of SEGS) rating[k] = +(base * f[k]).toFixed(2);
      const r = makeRacer({ name: (D.ANIMALS[id] || {}).name || id, look: PX.DEFAULT_LOOK, rating, stamR: base * f.stamina, cheer });
      r.animal = id; r.color = critterColor(id);
      return r;
    });
  }
  // ---------------- rival levels ----------------
  // Difficulty rises with series order inside a tier: the tier's range is scaled from SERIES_RAMP (Meadow Dash) up to x1
  // (Grand Prix); the late series scale on with ratingMul. Rivals sit at the bottom / middle / top of that range. Their rolled
  // ratings only move strength between segments (half the spread, normalised so each runs this course exactly like its
  // level), and no rating passes the top. So the strongest rival is always exactly the series' top level.
  const SERIES_RAMP = 0.9;
  const courses = {}, levelCache = {};
  const courseOf = (ri, tier) => courses[ri + '-' + tier] || (courses[ri + '-' + tier] = buildCourse(ri, tier));
  function seriesPos(R) { const n = HUB_ORDER.indexOf(ALL.indexOf(R)), g = HUB_ORDER.indexOf(D.RACES.findIndex(x => x.id === 'grand')); return n < 0 || g <= 0 ? 1 : Math.min(1, n / g); }
  function rivalLevels(R, tier) {
    const TR = tierRating(R, tier), k = R.ratingMul ? 1 : SERIES_RAMP + (1 - SERIES_RAMP) * seriesPos(R);
    return [TR[0] * k, (TR[0] + TR[1]) / 2 * k, TR[1] * k];
  }
  // course speed multiplier for per-segment ratings (time-weighted, like a flat rating would give)
  function courseMul(C, rating) { let t = 0, t0 = 0; for (const s of C.segs) { const b = T.base[s.type]; t += s.len / (b * mulOf(rating[s.type])); t0 += s.len / b; } return t0 / t; }
  function levelled(C, rolled, lv, top) {
    const avg = SEGS.reduce((a, k) => a + rolled[k], 0) / 4, out = {};
    for (const k of SEGS) out[k] = Math.min(top, lv * (1 + (rolled[k] / avg - 1) * 0.5));
    for (let it = 0; it < 6; it++) { // scale the uncapped segments until this course runs like a flat lv
      const c = mulOf(lv) / courseMul(C, out); if (Math.abs(c - 1) < 1e-4) break;
      for (const k of SEGS) if (out[k] < top) out[k] = Math.min(top, mulRating(mulOf(out[k]) * c));
    }
    for (const k of SEGS) out[k] = +out[k].toFixed(2);
    out.stamina = +Math.min(top, lv * (1 + ((rolled.stamina || avg) / avg - 1) * 0.5)).toFixed(2);
    return out;
  }
  function rivalRacers(R, tier) {
    if (R.wild) return wildRivals(R, tier);
    const key = R.id + '-' + tier;
    if (!levelCache[key]) {
      const list = R.extra ? extraRivals(R, tier) : ST.raceRivals(R.id, tier), lv = rivalLevels(R, tier), C = courseOf(ALL.indexOf(R), tier);
      levelCache[key] = list.map((rv, i) => ({ rv, rating: levelled(C, rv.rating, lv[Math.min(i, 2)], lv[2]) }));
    }
    return levelCache[key].map(({ rv, rating }) => makeRacer({ name: rv.name, look: rv.look, rating, stamR: rating.stamina, cheer: cheerOf(rv.cheer || D.RACE_TIERS[tier].cheerSkill) }));
  }
  // Headless race. who = {rating, stamR} ; skill = [perfect, good, miss] chance per ring for the player.
  function simRace(who, ri, tier, skill, items) {
    const R = ALL[ri], C = buildCourse(ri, tier);
    const pl = makeRacer({ name: 'You', look: PX.DEFAULT_LOOK, rating: who.rating, stamR: who.stamR, isPlayer: true, cheer: cheerOf(skill) });
    pl.nextBoost = T.ring.first + 1;
    const all = [pl].concat(rivalRacers(R, tier));
    all.forEach((r, i) => { r.lane = i; });
    const W = { honey: [], racers: all };
    const placeOf = r => all.slice().sort((a, b) => b.x - a.x).indexOf(r);
    const ctx = { C, t: 0, rng: Math.random, fx: false, W: items ? W : null, items: !!items, placeOf }, dt = 1 / 60;
    while (all.some(r => !r.finished) && ctx.t < 400) {
      ctx.t += dt;
      for (const r of all) stepRacer(r, dt, ctx);
      if (items && pl.item) { pl.useIn -= dt; if (pl.useIn <= 0) activate(pl, pl.item, ctx); } // the headless player uses items too
    }
    const order = all.slice().sort((a, b) => a.time - b.time);
    return { place: order.indexOf(pl), time: pl.time, tired: pl.tiredCount, winner: order[0].time, order: order.map(r => r.name + ' ' + r.time.toFixed(1)) };
  }
  function simMany(who, ri, tier, skill, n, items) {
    n = n || 200; let win = 0, t = 0, tired = 0, top2 = 0, wt = 0;
    for (let i = 0; i < n; i++) { const s = simRace(who, ri, tier, skill, items); if (s.place === 0) win++; if (s.place < 2) top2++; t += s.time; wt += s.winner; tired += s.tired; }
    return { win: +(win / n).toFixed(2), top2: +(top2 / n).toFixed(2), avgTime: +(t / n).toFixed(1), winnerTime: +(wt / n).toFixed(1), tiredPerRace: +(tired / n).toFixed(2) };
  }
  const flat = (v, st) => ({ rating: { run: v, swim: v, climb: v, fly: v }, stamR: st == null ? v : st });
  // Solo run with a fixed seed (medal times must never change between sessions)
  function simSolo(ri, tier, v, skill, seed) {
    const prev = rng0; rng0 = mulberry(seed);
    try {
      const C = buildCourse(ri, tier);
      const pl = makeRacer({ name: 'm', look: PX.DEFAULT_LOOK, rating: { run: v, swim: v, climb: v, fly: v }, stamR: v, isPlayer: true, cheer: skill ? cheerOf(skill) : null });
      pl.nextBoost = T.ring.first + 1;
      const ctx = { C, t: 0, rng: rng0, fx: false }, dt = 1 / 60;
      while (!pl.finished && ctx.t < 400) { ctx.t += dt; stepRacer(pl, dt, ctx); }
      return pl.time;
    } finally { rng0 = prev; }
  }
  const medalCache = {};
  // [bronze, silver, gold] seconds for a course: a low / mid / top rival of that tier running alone
  function medalTimes(ri, tier) {
    const key = ri + '-' + tier; if (medalCache[key]) return medalCache[key];
    const TR = tierRating(ALL[ri], tier), lo = TR[0], hi = TR[1], mid = (lo + hi) / 2;
    const up = v => Math.ceil(v * 2) / 2;
    const b = up(simSolo(ri, tier, lo, [0.05, 0.3, 0.15], 101 + key.length)), s = up(simSolo(ri, tier, mid, [0.2, 0.35, 0.1], 202)), g = up(simSolo(ri, tier, hi, [0.4, 0.35, 0.05], 303));
    return (medalCache[key] = [Math.max(b, s + 0.5), Math.max(s, g + 0.5), g]);
  }
  const medalOf = (mt, time) => (time <= mt[2] ? 3 : time <= mt[1] ? 2 : time <= mt[0] ? 1 : 0);

  // =====================================================================
  // DAILY CUP: seeded by the local date, so it's the same all day.
  // =====================================================================
  function cupBase(key) { const r = mulberry(hashStr('cup:' + key)), ids = Object.keys(MODS); return { r, ids, mod: ids[Math.floor(r() * ids.length)] }; }
  function dailyInfo(key) {
    key = key || dayKey();
    const seed = hashStr('cup:' + key), b = cupBase(key);
    const yd = dayKey(new Date(key + 'T12:00:00').getTime() - 864e5);
    let modId = b.mod; if (modId === cupBase(yd).mod) modId = b.ids[(b.ids.indexOf(modId) + 1) % b.ids.length]; // no repeat two days running
    if (DBG.cupMod && MODS[DBG.cupMod]) modId = DBG.cupMod; // testing only
    const r = mulberry(seed + 7);
    // course pool: the first 7 series until the late-game series shipped (keeps each past day's cup the same), then every non-wild series
    const pool = key < '2026-09-27' ? ALL.slice(0, D.RACES.length + 2) : ALL.filter(x => !x.wild);
    const R = pool[Math.floor(r() * pool.length)];
    const egg = 'normal'; // a lucky seed packet of a plant you've unlocked
    return { key, seed, R, ri: ALL.indexOf(R), mod: modId, M: MODS[modId], egg };
  }
  const cupCoins = place => Math.round(CUP_COINS[place] * (1 + 0.5 * Math.min(3, PS.S.bestTier || 0)));
  function avgRating(s, R) { const W = SEGS.reduce((a, k) => a + (R.mix[k] || 0), 0) || 1; let p = 0; for (const k of SEGS) p += ST.raceRating(s, k) * (R.mix[k] || 0) / W; return p; }
  function cupCourse(info, s) {
    return buildCourse(info.ri, 0, { R: info.R, m: mulOf(avgRating(s, info.R)), seed: info.seed, reverse: info.mod === 'reverse', boxes: info.M.boxes || 3, segMul: info.M.segMul, mods: { [info.mod]: true } });
  }
  // Rivals are matched to your racer's SPEED on each segment (not its rating, so the cup is just as fair at any level):
  // a bit slower / even / a bit faster (CUP_F, never faster than the top factor), cheering like Beginner rivals.
  // Their extra stamina (+0.3 share) offsets how much good cheering helps low-level plants that tire. From sims: an average
  // young tapper wins about half the cups and a random tapper about a quarter, at any level.
  const CUP_F = [0.94, 1.0, 1.06], CUP_CHEER = [0.12, 0.3, 0.15];
  function cupRivals(info, s) {
    const r = mulberry(info.seed + 99), pr = playerRatings(s), st = ST.staminaRating(s);
    const f = CUP_F.slice().sort(() => r() - 0.5);
    return [0, 1, 2].map(i => {
      const rating = {}; for (const k of SEGS) rating[k] = +mulRating(Math.min(CUP_F[2], f[i] * (0.98 + r() * 0.04)) * mulOf(pr[k])).toFixed(2);
      const rl = ST.rivalLook(r, 1, ST.raceVs());
      return makeRacer({ name: rl.name, look: rl.look, rating, stamR: st * (f[i] + 0.3), cheer: cheerOf(CUP_CHEER) });
    });
  }

  // =====================================================================
  // DOM + CSS
  // =====================================================================
  const CSS = `
  .r-root{position:absolute;inset:0}
  .r-root .label{font-family:var(--f-ui);font-weight:600;font-size:14px;letter-spacing:0;text-transform:none;color:var(--ink-soft)}
  /* the heading, tabs and Race-against switch stay on top; your racer and the series scroll in the box below, with a scroll bar */
  .r-hub{position:absolute;inset:0;display:flex;flex-direction:column}
  .r-pin{flex:0 0 auto;padding:12px 28px 0 12px}
  .r-box{padding:0 0 22px 12px}
  @media (max-height:560px){.r-pin .r-head{display:none}} /* (a phone on its side: the list needs the room) */
  .r-head{display:flex;align-items:flex-end;justify-content:space-between;gap:8px;margin:2px 4px 10px}
  .r-head h2{font-size:28px;margin:2px 0 0;color:var(--ink)}
  .r-head .r-count{font-family:var(--f-ui);font-weight:600;font-size:14px;color:var(--ink-soft);background:var(--slot);border:2px solid var(--line);border-radius:10px;padding:3px 9px;white-space:nowrap}
  .r-tabs{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:0 0 12px}
  .r-tab{position:relative;display:flex;flex-direction:column;align-items:center;gap:1px;min-height:64px;font-family:var(--f-ui);font-weight:700;font-size:15px;line-height:1.1;white-space:nowrap;
    background:var(--panel);border:2px solid var(--line);border-bottom-width:5px;border-radius:16px;color:var(--ink-soft);padding:6px 2px 5px}
  .r-tab canvas{width:32px;height:32px}
  .r-tab[aria-selected="true"]{background:var(--sun);border-color:var(--sun-edge);color:#4a3210}
  .r-tab:active{transform:translateY(3px);border-bottom-width:2px;margin-bottom:3px}
  .r-tab .r-badge{position:absolute;top:5px;right:9px;width:13px;height:13px;border-radius:50%;background:var(--berry);border:2px solid var(--panel)}
  .r-partner{display:grid;grid-template-columns:80px 1fr;gap:10px;align-items:center;padding:10px 12px 10px 10px;margin-bottom:14px}
  .r-partner .r-pc{width:80px;height:80px;background:var(--slot);border-radius:16px;box-shadow:inset 0 -3px 0 var(--line)}
  .r-ptop{display:flex;align-items:center;justify-content:space-between;gap:8px}
  .r-pname{font-family:var(--f-px);font-weight:700;font-size:21px;line-height:1;color:var(--ink)}
  .r-pform{font-size:14px;color:var(--ink-soft);margin:2px 0 7px;line-height:1.2}
  .r-change{min-height:44px;font-size:15px;padding:6px 12px}
  .r-rates{display:grid;grid-template-columns:repeat(5,1fr);gap:4px}
  .r-rate{background:var(--field);border:2px solid var(--line);border-radius:9px;padding:2px 0 1px;text-align:center;line-height:1.05}
  .r-rate small{display:block;font-family:var(--f-ui);font-weight:600;font-size:13px;color:var(--ink-soft)}
  .r-rate b{font-family:var(--f-ui);font-weight:700;font-size:16px;font-variant-numeric:tabular-nums}
  .r-card{margin-bottom:14px;overflow:hidden}
  .r-banner{position:relative;background:var(--slot);border-bottom:3px solid var(--line);line-height:0;overflow:hidden}
  .r-banner canvas{display:block;margin:0 auto}
  .r-card.locked .r-banner canvas{filter:grayscale(.75) brightness(.95);opacity:.75}
  .r-num{position:absolute;left:10px;top:8px;font-family:var(--f-ui);font-weight:700;font-size:13px;line-height:1;background:var(--panel);border:2px solid var(--edge);border-radius:8px;padding:3px 7px;color:var(--ink)}
  .r-new{position:absolute;right:10px;top:8px;font-family:var(--f-ui);font-weight:700;font-size:13px;line-height:1;background:var(--berry);color:#fff;border:2px solid var(--berry-edge);border-radius:8px;padding:3px 7px}
  .r-lockchip{position:absolute;right:10px;top:8px;display:flex;align-items:center;gap:5px;font-family:var(--f-ui);font-weight:700;font-size:13px;line-height:1;background:var(--ink);color:var(--panel);border-radius:8px;padding:4px 8px}
  .r-body{padding:10px 12px 12px}
  .r-title{font-family:var(--f-px);font-weight:700;font-size:23px;line-height:1.05;color:var(--ink)}
  .r-sub{font-size:14px;color:var(--ink-soft);margin:2px 0 8px;line-height:1.3}
  .r-mixbar{display:flex;height:8px;border-radius:5px;overflow:hidden;border:2px solid var(--line);margin-bottom:6px}
  .r-mixbar i{display:block;height:100%}
  .r-mix{display:flex;flex-wrap:wrap;gap:5px}
  .r-mixchip{display:inline-flex;align-items:center;gap:4px;font-family:var(--f-ui);font-weight:600;font-size:14px;background:var(--slot);border-radius:8px;padding:2px 8px 2px 4px;color:var(--ink)}
  .r-mixchip canvas{width:22px;height:22px;margin:-2px 0}
  .r-mixchip span{color:var(--ink-soft);font-weight:500}
  .r-tiers{display:grid;gap:7px;margin-top:10px}
  .r-tier{display:grid;grid-template-columns:1fr auto;align-items:center;gap:8px;min-height:58px;width:100%;text-align:left;background:var(--field);
    border:2px solid var(--line);border-bottom-width:5px;border-radius:15px;padding:6px 10px 6px 12px;color:var(--ink)}
  .r-tier:not([disabled]):active{transform:translateY(3px);border-bottom-width:2px;margin-bottom:3px}
  .r-tier:focus-visible,.r-tab:focus-visible{outline:3px solid var(--focus);outline-offset:2px}
  .r-tier[disabled]{background:var(--slot);border-style:dashed;border-bottom-width:2px;cursor:default;margin-bottom:3px}
  .r-tier[disabled] .r-tname,.r-tier[disabled] .r-prize{opacity:.55}
  .r-tname{font-family:var(--f-px);font-weight:700;font-size:18px;line-height:1.05;display:flex;align-items:center;gap:6px;flex-wrap:wrap}
  .r-tsub{font-size:14px;color:var(--ink);line-height:1.3;margin-top:2px}
  .r-tsub b{color:var(--ink);font-weight:600}
  .r-match{font-family:var(--f-ui);font-weight:700;font-size:13px;border-radius:7px;padding:2px 6px;color:#fff;line-height:1.2}
  .r-right{display:flex;align-items:center;gap:8px}
  .r-prize{display:flex;align-items:center;gap:4px;font-family:var(--f-ui);font-weight:700;font-size:16px;font-variant-numeric:tabular-nums}
  .r-prize canvas{width:18px;height:18px}
  .r-eggic{display:grid;place-items:center;width:30px;height:34px;background:#fff1b8;border:2px solid var(--sun-edge);border-radius:9px}
  .r-eggic.r-newplant{background:#e8f8d8;border-color:var(--accent);box-shadow:0 0 0 2px #b8f07a inset}
  .r-vsbar{display:flex;align-items:center;gap:6px;margin:0 2px 10px;font:800 14px var(--f-ui);color:var(--ink)}
  .r-vsb{display:inline-flex;align-items:center;gap:5px;border:2px solid var(--line);border-bottom-width:4px;border-radius:12px;background:var(--slot);padding:4px 10px 3px 6px;font:800 14px var(--f-ui);color:var(--ink-soft)}
  .r-vsb canvas{width:32px;height:32px}
  .r-vsb[aria-pressed="true"]{background:var(--panel);border-color:var(--accent-edge);color:var(--ink);box-shadow:inset 0 -3px 0 var(--accent)}
  .r-eggic canvas{width:20px;height:24px}
  .r-eggic canvas.r-mapic{width:26px;height:14px;border-radius:3px}
  .r-go{font-family:var(--f-ui);font-weight:700;font-size:16px;background:var(--accent);color:#fff;border-radius:10px;padding:8px 10px;box-shadow:inset 0 -3px 0 var(--accent-edge)}
  .r-lock{width:26px;height:26px;display:grid;place-items:center}
  .r-lock canvas{width:22px;height:24px}
  .r-medals{display:flex;gap:2px}
  .r-medals canvas{width:22px;height:28px}
  .r-vs{display:flex;align-items:center;gap:2px;margin-top:3px;font-family:var(--f-ui);font-weight:600;font-size:14px;color:var(--ink-soft)}
  .r-vs canvas{width:36px;height:36px;background:var(--slot);border-radius:8px}
  .r-friendic{background:#e4f6d8;border-color:#6abe30}
  .r-eggic.r-friendic{width:40px;height:40px}
  .r-friendic canvas{width:36px;height:36px}
  .r-tab canvas.r-tabcrit{width:36px;height:36px;margin:-2px 0}
  .r-lockline{display:flex;align-items:center;gap:6px;margin-top:4px}
  .r-medals canvas.off{opacity:.45}
  .r-empty{text-align:center;padding:22px 18px;margin-top:20px}
  .r-empty canvas{width:96px;height:112px;display:block;margin:0 auto 6px}
  .r-empty h3{font-family:var(--f-px);font-size:22px;margin:0 0 6px}
  .r-empty p{margin:0 0 14px;color:var(--ink);font-size:16px}
  .r-foot{font-size:14px;color:var(--ink-soft);text-align:center;margin:4px 12px 0;line-height:1.4}
  .r-intro{font-size:15px;color:var(--ink);text-align:center;margin:-4px 8px 12px;line-height:1.35}
  .r-twist{display:grid;grid-template-columns:52px 1fr;gap:10px;align-items:center;background:#efe4ff;border:2px solid #c9a2f0;border-radius:14px;padding:8px 10px;margin:4px 0 10px}
  .r-twist canvas{width:48px;height:48px}
  .r-twist b{display:block;font-family:var(--f-px);font-weight:700;font-size:19px;line-height:1.1;color:#4a2a78}
  .r-twist span{font-size:15px;color:#4a2a78}
  .r-cupprize{display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;font-family:var(--f-ui);font-weight:700;font-size:18px;margin:0 0 10px;color:var(--ink)}
  .r-cupprize canvas{width:18px;height:18px}
  .r-twist canvas.r-giantic{width:64px;height:64px;margin:-8px}
  .r-cupprize .r-eggic{width:28px;height:32px}
  .r-cupprize small{font-family:var(--f-ui);font-weight:600;font-size:14px;color:var(--ink)}
  .r-done{display:flex;align-items:center;justify-content:center;gap:8px;background:#eaf6df;border:2px solid #9fcf8a;border-radius:14px;padding:8px 10px;margin:0 0 10px;font-family:var(--f-ui);font-weight:700;font-size:16px;color:#2b6a33;text-align:center}
  .r-next{font-family:var(--f-ui);font-weight:600;font-size:15px;text-align:center;color:var(--ink-soft);margin:10px 0 0}
  .r-cupgo{min-height:60px}

  .r-race{position:absolute;inset:0;display:flex;flex-direction:column;background:${INK}}
  .r-hud{flex:none;display:grid;grid-template-columns:auto 1fr auto;gap:5px 10px;align-items:center;
    padding:calc(8px + env(safe-area-inset-top,0px)) 10px 8px 12px;background:var(--panel);border-bottom:4px solid var(--edge);position:relative;z-index:2}
  .r-place{grid-row:span 2;font-family:var(--f-px);font-weight:700;font-size:30px;line-height:1;min-width:62px;text-align:center;
    background:var(--sun);border:2px solid var(--sun-edge);border-bottom-width:5px;border-radius:14px;padding:6px 8px 4px;color:#4a3210}
  .r-place small{font-family:var(--f-ui);font-size:16px;margin-left:1px}
  .r-track{position:relative;height:22px}
  .r-rail{position:absolute;left:6px;right:22px;top:7px;height:8px;border:2px solid var(--line);border-radius:5px;overflow:hidden;display:flex;background:var(--slot)}
  .r-rail i{display:block;height:100%;opacity:.8}
  .r-dots{position:absolute;left:6px;right:22px;top:0;height:22px}
  .r-dot{position:absolute;top:5px;width:12px;height:12px;margin-left:-6px;border:2px solid ${INK};border-radius:3px}
  .r-dot.me{top:2px;width:16px;height:18px;margin-left:-8px;border-radius:4px;z-index:2;box-shadow:0 0 0 2px var(--sun)}
  .r-dot.ghost{opacity:.55;border-style:dashed}
  .r-flag{position:absolute;right:0;top:-1px;width:20px;height:24px}
  .r-hrow{display:flex;align-items:center;gap:8px}
  .r-hrow .bar{flex:1;height:12px}
  .r-hrow .bar i{transition:none;background:#6abe30}
  .r-hrow .num{min-width:56px;text-align:right;font-size:17px}
  .r-quit{grid-row:span 2;width:44px;height:44px;padding:0;display:grid;place-items:center;font-size:20px;border-radius:12px}
  .r-stage{flex:1;min-height:0;position:relative;touch-action:none;overflow:hidden}
  .r-cv{position:absolute;left:0;top:0;display:block;touch-action:none}
  .r-hint{bottom:calc(112px + env(safe-area-inset-bottom,0px));z-index:3}
  .r-ihint{right:12px;left:auto;transform:none;bottom:calc(112px + env(safe-area-inset-bottom,0px));z-index:3;max-width:220px}
  .r-skip{position:absolute;left:12px;bottom:calc(14px + env(safe-area-inset-bottom,0px));z-index:3;min-height:46px}
  .r-item{position:absolute;right:12px;bottom:calc(14px + env(safe-area-inset-bottom,0px));z-index:3;width:86px;height:86px;padding:0;border-radius:24px;
    display:grid;place-items:center;background:rgba(255,248,230,.55);border:3px solid rgba(205,181,126,.7);border-bottom-width:7px}
  .r-item canvas{width:45px;height:45px}
  .r-stage.mirror .r-item,.r-stage.mirror .r-ihint{left:12px;right:auto}
  .r-stage.mirror .r-skip{left:auto;right:12px}
  .r-item span{position:absolute;left:0;right:0;bottom:2px;font-family:var(--f-ui);font-weight:700;font-size:14px;color:#3a2408}
  .r-item.has{background:var(--sun);border-color:var(--sun-edge);animation:rPulse .9s ease-in-out infinite}
  .r-item:not(.has) canvas{opacity:.35}
  .r-item:active{transform:translateY(3px);border-bottom-width:4px}
  @keyframes rPulse{50%{transform:scale(1.07)}}
  @media (prefers-reduced-motion: reduce){.r-item.has{animation:none}}
  .r-ov{z-index:40}
  .r-ov .card{max-height:calc(100% - 8px);overflow-y:auto;touch-action:pan-y;padding:16px 16px 14px}
  .r-ov .card h1{font-size:28px;margin:4px 0 4px}
  .r-rows{display:grid;gap:4px;margin:6px 0 10px}
  .r-row{display:grid;grid-template-columns:34px 38px 1fr auto;align-items:center;gap:8px;background:var(--slot);border-radius:12px;padding:1px 12px 1px 8px;min-height:42px}
  .r-row.me{background:#fff1b8;box-shadow:inset 0 0 0 2px var(--sun-edge)}
  .r-row .pl{font-family:var(--f-ui);font-weight:700;font-size:17px;text-align:center}
  .r-row canvas{width:36px;height:36px}
  .r-row .nm{font-family:var(--f-ui);font-weight:700;font-size:16px;line-height:1.1;min-width:0;overflow:hidden;text-overflow:ellipsis}
  .r-row .nm small{display:block;white-space:nowrap;font-family:var(--f-ui);font-size:13px;color:var(--ink-soft);font-weight:600}
  .r-row .num{font-size:16px}
  .r-rew{background:#eaf6df;border:2px dashed #9fcf8a;border-radius:14px;padding:9px 10px;margin:0 0 10px;display:grid;gap:7px}
  .r-coins{display:flex;align-items:center;justify-content:center;gap:7px;font-family:var(--f-ui);font-weight:700;font-size:21px;color:var(--ink)}
  .r-coins canvas{width:22px;height:22px}
  .r-xp{display:flex;flex-wrap:wrap;justify-content:center;gap:5px}
  .r-xpchip{font-family:var(--f-ui);font-weight:700;font-size:14px;border-radius:8px;padding:3px 8px;color:#fff;line-height:1.2}
  .r-xpchip b{background:#fff27a;color:#4a3210;border-radius:5px;padding:0 4px;margin-left:4px}
  .r-eggbox{display:grid;grid-template-columns:44px 1fr;gap:10px;align-items:center;background:#fff1b8;border:2px solid var(--sun-edge);border-radius:14px;padding:8px 10px;margin:0 0 10px}
  .r-eggbox canvas{width:40px;height:48px}
  .r-eggbox canvas.r-friendcv{width:36px;height:36px}
  .r-eggbox b{font-family:var(--f-ui);font-weight:700;font-size:17px;display:block;line-height:1.1}
  .r-eggbox span{font-size:14px;color:var(--ink)}
  .r-note{font-size:15px;color:var(--ink);margin:0 0 10px;text-align:center;line-height:1.35}
  .r-note b{color:var(--accent)}
  .r-bigtime{font-family:var(--f-px);font-weight:700;font-size:44px;line-height:1;text-align:center;color:var(--ink);margin:4px 0 2px}
  .r-delta{text-align:center;font-family:var(--f-ui);font-weight:700;font-size:16px;margin:0 0 10px}
  .r-delta.good{color:#2b8243}.r-delta.bad{color:#b0572a}
  .r-mrow{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:0 0 10px}
  .r-mcell{display:grid;justify-items:center;gap:2px;background:var(--slot);border-radius:12px;padding:6px 2px 5px;font-family:var(--f-ui);font-weight:600;font-size:14px;color:var(--ink)}
  .r-mcell canvas{width:33px;height:42px}
  .r-mcell b{font-family:var(--f-ui);font-size:16px;color:var(--ink)}
  .r-mcell.got{background:#fff1b8;box-shadow:inset 0 0 0 2px var(--sun-edge)}
  .r-mcell.new{animation:rPulse .8s ease-in-out 3}
  .r-btns{display:grid;grid-template-columns:1fr 1.3fr;gap:10px}
  .r-btns .btn{min-height:52px}
  .r-btns.stack{grid-template-columns:1fr;gap:8px}
  .r-results .r-btns{position:sticky;bottom:-14px;z-index:1;background:var(--panel);padding:8px 0 10px;margin:0 0 -10px;box-shadow:0 -10px 10px -8px rgba(60,44,24,.25)}
  .r-ov p{text-wrap:pretty}
  .r-pause{cursor:pointer}
  .r-pause .card{display:grid;justify-items:center;text-align:center;padding:20px 18px 22px}
  .r-pause .r-play{width:120px;height:120px;margin:0 0 8px;animation:rPulse 1.1s ease-in-out infinite}
  .r-pause h1{margin:2px 0 0}
  .r-cheers{display:grid;grid-template-columns:repeat(4,1fr);gap:4px;margin:0 0 8px}
  .r-cstat{display:grid;grid-template-columns:auto auto;justify-content:center;align-items:center;column-gap:3px;background:var(--slot);border-radius:10px;padding:3px 2px 2px;
    font-family:var(--f-ui);font-weight:600;font-size:12px;line-height:1.1;color:var(--ink-soft)}
  .r-cstat canvas{width:26px;height:26px}
  .r-cstat b{font-size:19px;color:var(--ink);font-variant-numeric:tabular-nums}
  .r-cstat small{grid-column:1 / -1;text-align:center;font-size:12px}
  .r-tip{display:grid;grid-template-columns:36px 1fr;gap:9px;align-items:center;background:#e6f2ff;border:2px solid #9fc8ef;border-radius:12px;padding:4px 10px 4px 6px;margin:0 0 10px;
    font-family:var(--f-ui);font-weight:600;font-size:15px;line-height:1.25;color:#23476e;text-align:left}
  .r-tip canvas{width:36px;height:36px}
  .r-results .r-row{min-height:38px}
  /* results (the shared .pv-res window; these are the race's own parts). :where() = zero specificity: only a fallback */
  html body .r-ov.pv-res[hidden]{display:none!important}
  :where(.r-results.pv-res){position:absolute;inset:0;z-index:40;display:flex;align-items:center;justify-content:center;padding:14px;background:rgba(14,26,10,.66)}
  :where(.r-results .pv-res-win){width:100%;max-width:440px;max-height:100%;overflow-y:auto;background:var(--panel,#fff8e6);border:3px solid ${INK};border-radius:16px;padding:14px 14px 12px;text-align:center}
  :where(.r-results .pv-res-title){font:900 40px/1.05 var(--f-px);color:#ffd23a;margin:2px 0 8px;-webkit-text-stroke:2px ${INK};paint-order:stroke fill}
  :where(.r-results .pv-res-title.lose){color:#a9d2f5}
  :where(.r-results .pv-res-hero){display:flex;align-items:flex-end;justify-content:center;gap:10px;margin:0 auto 8px}
  :where(.r-results .pv-res-tiles){display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin:8px 0 4px}
  :where(.r-results .pv-res-tile){flex:1 1 0;min-width:88px;max-width:170px;display:grid;justify-items:center;gap:3px;background:var(--slot,#eef4e0);border:2px solid ${INK};border-radius:12px;padding:7px 6px 6px}
  :where(.r-results .pv-res-tile canvas){width:32px;height:32px}
  :where(.r-results .pv-res-tile b){font:900 26px/1 var(--f-ui);color:var(--ink)}
  :where(.r-results .pv-res-tile small){font:800 13px/1.2 var(--f-ui);color:var(--ink-soft)}
  :where(.r-results .pv-res-btns){display:flex;gap:10px;margin-top:14px}
  :where(.r-results .pv-res-btns .btn){flex:1 1 0;min-height:52px;font-size:18px}
  :where(.r-results .pv-res-btns .btn.go){flex-grow:1.5}
  html body .pv-res-title.r-silver{color:#e6ebf2}
  html body .pv-res-title.r-bronze{color:#eaa66a}
  html body .r-podium{gap:6px;min-height:150px;padding-bottom:0}
  html body .r-podium::before{display:none}
  .r-pod{position:relative;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;width:31%;max-width:132px}
  .r-pod canvas{height:76px;width:auto;max-width:100%;object-fit:contain;margin-bottom:-4px}
  .r-pod.p0 canvas{height:100px}
  .r-step{width:100%;border:2px solid ${INK};border-bottom:none;border-radius:10px 10px 0 0;display:grid;place-items:center;font:900 22px var(--f-ui);color:${INK}}
  .r-pod.p0 .r-step{height:52px;background:linear-gradient(#ffe46a,#f2b705)}
  .r-pod.p1 .r-step{height:38px;background:linear-gradient(#f6f8fb,#c4ccd8)}
  .r-pod.p2 .r-step{height:28px;background:linear-gradient(#f6caa2,#d08a4e)}
  .r-pod.me .r-step{box-shadow:inset 0 0 0 3px #fff}
  .r-you{font:900 12px/1 var(--f-ui);color:#fff;background:var(--mode,#de6a1c);border:2px solid ${INK};border-radius:8px;padding:2px 6px;margin:0 0 3px}
  html body .r-reswin .pv-res-tile canvas{object-fit:contain}
  html body .r-reswin .r-prizetile{background:#fff6cc}
  html body .r-reswin .eyebrow{text-align:center}
  .r-xps{display:grid;gap:5px;margin:8px 0 6px}
  .r-xprow{display:grid;grid-template-columns:64px minmax(0,1fr) auto;align-items:center;gap:8px}
  .r-xpname{font:900 13px/1 var(--f-ui);color:#fff;border-radius:7px;padding:4px 6px;text-align:center}
  .r-xpbar{display:block;height:12px;border-radius:6px;background:#eef0f4;border:2px solid ${INK};overflow:hidden}
  .r-xpbar i{display:block;height:100%;transition:width .6s ease-out .3s}
  .r-xprow small{font:800 13px var(--f-ui);color:var(--ink-soft);min-width:34px;text-align:right}
  .r-lvup{font:900 12px/1 var(--f-ui);font-style:normal;color:#fff;background:#3cc84a;border:2px solid #1f7a2a;border-radius:7px;padding:3px 5px;white-space:nowrap}
  .r-reswin .r-cheers{margin-top:8px}
  .r-reswin .r-note,.r-reswin .r-tip{margin-top:6px}
  @media (prefers-reduced-motion: reduce){.r-xpbar i{transition:none}}
  @media (prefers-reduced-motion: reduce){.r-pause .r-play{animation:none}}
  `;
  function injectCSS() {
    if (document.getElementById('r-style')) return;
    const st = document.createElement('style'); st.id = 'r-style'; st.textContent = CSS; document.head.appendChild(st);
  }

  // ---------------- tiny pixel icons ----------------
  // chibi sticker style: round chunky pastel shapes, one soft shade, a fine outline (hi-res grids); the Rainbow Star smiles
  const ICO = {};
  const RAINBOW = ['#ff9fb4', '#ffc68e', '#fff09a', '#b8ec9a', '#9fd0ff', '#c8aaf0'];
  const MEDAL_RAMPS = [['#ffe2c8', '#f6b88c', '#d8946a'], ['#ffffff', '#e2e8f2', '#b8c0d4'], ['#fffbe2', '#ffe07a', '#e8b850']];
  const QMARK = ['.###.', '#...#', '....#', '...#.', '..#..', '.....', '..#..'];
  function icon(kind) {
    if (ICO[kind]) return ICO[kind];
    const G = PX.Grid, A = PX.art, P = f => PX.piece(g, f), soft = (t, cx, cy, rx, ry, R, o) => A.softBody(t, cx, cy, rx, ry, R, o);
    let g, bold = false;
    switch (kind) {
      case 'run': g = new G(11, 9); for (const x0 of [1, 5.4]) P(t => t.poly([[x0, 1.2], [x0 + 2.4, 1.2], [x0 + 5, 4.5], [x0 + 2.4, 7.8], [x0, 7.8], [x0 + 2.6, 4.5]], '#a8e286')); g.dots([[2, 2], [6.5, 2]], '#e4fbc8'); break;
      case 'swim': g = new G(11, 9); for (const y0 of [2.6, 6.2]) P(t => PX.stroke(t, [[1, y0 + 0.6], [3, y0 - 0.8], [5.5, y0 + 0.6], [8, y0 - 0.8], [10, y0 + 0.6]], 0.7, 0.7, '#9fd0ff')); break;
      case 'climb': g = new G(11, 10); P(t => { t.poly([[0.6, 9.4], [5.5, 1.2], [10.4, 9.4]], '#d4d6ea'); t.poly([[5.5, 1.2], [10.4, 9.4], [5.5, 9.4]], '#b8bad6'); t.poly([[3.6, 4.4], [5.5, 1.2], [7.4, 4.4], [6.4, 5.2], [5.5, 4.4], [4.6, 5.2]], '#ffffff'); }); break;
      case 'fly': g = new G(11, 9); for (const [x, y, rx, ry, c] of [[4.2, 6.6, 3.6, 1.3, '#c4a6f0'], [5, 4.8, 4.2, 1.4, '#d4bcf8'], [5.8, 3, 4.4, 1.5, '#e6d8fe']]) P(t => t.ell(x, y, rx, ry, c, -0.38)); g.dots([[4, 2.4], [4.5, 2.4], [5, 2.2]], '#ffffff'); break; // a little wing of three feathers
      case 'lock': g = new G(11, 12); P(t => PX.stroke(t, [[3, 6], [3, 3.2], [5.5, 1.2], [8, 3.2], [8, 6]], 0.65, 0.65, '#cdd0e4')); P(t => { t.poly([[1.4, 5.6], [9.6, 5.6], [9.6, 11], [1.4, 11]], '#ffe39a'); t.poly([[1.4, 9.6], [9.6, 9.6], [9.6, 11], [1.4, 11]], '#f4c86e'); }); g.ell(5.5, 7.6, 0.8, 0.8, INK); PX.stroke(g, [[5.5, 7.8], [5.5, 9.2]], 0.3, 0.3, INK); bold = true; break;
      case 'flag':
        g = new G(10, 12); P(t => t.rect(1, 1, 1, 10, '#f2d4b0'));
        P(t => { for (let y = 0; y < 2; y++) for (let x = 0; x < 3; x++) t.rect(2 + x * 2, 1 + y * 2, 2, 2, (x + y) % 2 ? '#8e88c4' : '#ffffff'); }); break;
      case 'bigflag':
        g = new G(14, 26); P(t => t.rect(2, 3, 1, 22, '#f2d4b0')); P(t => t.ell(2.5, 2.5, 1.4, 1.4, '#ffe07a'));
        P(t => { for (let y = 0; y < 3; y++) for (let x = 0; x < 4; x++) t.rect(3 + x * 2, 4 + y * 2, 2, 2, (x + y) % 2 ? '#8e88c4' : '#ffffff'); }); bold = true; break;
      case 'coin': { const c = safeItem('coin'); if (c) return (ICO[kind] = c); g = new G(9, 9); P(t => soft(t, 4.5, 4.5, 3.6, 3.6, ['#fffbe2', '#ffe07a', '#e8b850'])); break; }
      // ---- tabs ----
      case 'tab-races': g = new G(16, 16); P(t => t.rect(3, 1, 1, 14, '#c8b4a0')); P(t => { t.poly([[4, 2], [13.4, 2.6], [13.4, 8.4], [4, 9]], '#ffffff'); for (let y = 0; y < 3; y++) for (let x = 0; x < 4; x++) if ((x + y) % 2) t.poly([[4 + x * 2.35, 2 + y * 2.3 + x * 0.15], [6.35 + x * 2.35, 2 + y * 2.3 + (x + 1) * 0.15], [6.35 + x * 2.35, 4.3 + y * 2.3 + (x + 1) * 0.15], [4 + x * 2.35, 4.3 + y * 2.3 + x * 0.15]], '#8e88c4'); }); bold = true; break;
      case 'tab-cup':
        g = new G(16, 16); P(t => { PX.stroke(t, [[3.4, 3], [1.6, 4.4], [3.4, 7]], 0.55, 0.55, '#ffe07a'); PX.stroke(t, [[12.6, 3], [14.4, 4.4], [12.6, 7]], 0.55, 0.55, '#ffe07a'); });
        P(t => soft(t, 8, 4.6, 5.2, 5, ['#fffbe2', '#ffe48a', '#f2c060'], { mask: (x, y) => y >= 1.6 })); P(t => t.rect(7, 9, 2, 3, '#f2c060')); P(t => { t.rect(4, 12, 8, 3, '#e8b48e'); t.rect(4, 14, 8, 1, '#d49a76'); }); g.dots([[5.5, 4], [5.5, 4.5], [6, 3.5]], '#ffffff'); bold = true; break;
      case 'tab-trial':
        g = new G(16, 16); P(t => { t.rect(7, 0, 3, 2, '#cdd0e4'); t.rect(8, 2, 1, 1, '#cdd0e4'); }); P(t => soft(t, 8.5, 9.5, 6, 6, ['#ffffff', '#f4f6fc', '#d8deee']));
        PX.stroke(g, [[8.5, 9.5], [8.5, 6]], 0.35, 0.35, '#ff8f9e'); PX.stroke(g, [[8.5, 9.5], [10.8, 9.5]], 0.35, 0.35, '#ff8f9e'); g.ell(8.5, 9.5, 0.6, 0.6, '#ff8f9e'); g.dots([[8.5, 4.5], [4, 9.5], [13, 9.5], [8.5, 14.5]], '#b8c0d4'); bold = true; break;
      // ---- items ----
      case 'carrot':
        g = new G(15, 15); P(t => { t.ell(11, 3.4, 1.4, 2.8, '#a8e286', 0.75); t.ell(12.2, 5.6, 2.8, 1.3, '#86c46e', 0.35); t.ell(9.4, 2.6, 1.2, 2.5, '#c4f09a', -0.3); });
        P(t => { t.poly([[5.6, 4], [11.4, 9.6], [2, 13.8], [1.6, 13.4]], '#ffb87e'); t.poly([[8.5, 6.8], [11.4, 9.6], [2, 13.8]], '#f29a68'); }); for (const [a, b] of [[[6, 7.4], [7, 6.8]], [[4.4, 10.4], [5.4, 9.8]]]) PX.stroke(g, [a, b], 0.22, 0.22, '#e08a5e'); g.dots([[5.5, 6], [6, 5.5]], '#ffe6c8'); bold = true; break;
      case 'shield':
        g = new G(15, 15); P(t => soft(t, 7.5, 7.5, 6.2, 6.2, ['#ffffff', '#cfeeff', '#9fd2f6'], { hl: false })); g.ell(7.5, 7.5, 4.4, 4.4, '#e6f6ff'); g.ell(5.2, 4.8, 1.5, 1, '#ffffff', -0.6); g.dots([[10.5, 10.5], [11, 10]], '#ffffff'); bold = true; break;
      case 'honey':
        g = new G(15, 15); P(t => soft(t, 7.5, 9.6, 5.6, 4.6, ['#fff0b8', '#ffd27a', '#f0b05a'])); P(t => { t.rect(3, 3, 9, 3, '#f6dcbc'); t.rect(4, 5, 7, 1, '#e2c09a'); }); P(t => t.ell(7.5, 2.6, 2, 0.8, '#ff9fb4'));
        g.ell(9.4, 7, 1.2, 1.6, '#ffe8a0', 0, (x, y) => g.filled(x, y)); bold = true; break;
      case 'star':
        g = new G(15, 15); P(t => { t.poly(PX.starPts(7.5, 8, 7, 3.3, 5), '#fff09a'); t.ell(8.6, 10.4, 4.4, 2.2, '#f8d468', 0, (x, y) => t.filled(x, y)); });
        A.chibiEyes(g, 7.6, 8.5, { sp: 4.2, w: 2.1, h: 2.9 }); A.blush(g, 7.6, 10.6, { sp: 6.2, w: 0.9, h: 0.55 }); A.chibiMouth(g, 7.6, 11, 'smile', 1.5);
        g.dots([[7.5, 0.5], [0.5, 5.5], [14.5, 5.5]], '#ffc6d8'); bold = true; break;
      case 'itembox': g = new G(15, 15); P(t => { t.poly([[2, 1], [13, 1], [14, 2], [14, 13], [13, 14], [2, 14], [1, 13], [1, 2]], '#ffffff'); t.poly([[11.6, 1], [13, 1], [14, 2], [14, 13], [13, 14], [2, 14], [1, 13], [1, 12.6], [11.6, 12.6]], '#eee8fa'); }); g.str(QMARK, 5, 4, { '#': '#b89ae6' }); bold = true; break;
      // ---- pause + results tips ----
      case 'play': g = new G(24, 24); P(t => soft(t, 12, 12, 10.4, 10.4, ['#e4fbc8', '#a6e290', '#80c47c'])); P(t => t.poly([[9.4, 7], [18, 12], [9.4, 17]], '#ffffff')); bold = true; break;
      case 'ringtip': { // the Cheer Ring as it looks in the race: gold ring closing on the green circle
        const c = document.createElement('canvas'); c.width = c.height = 18; const x = c.getContext('2d');
        for (const [r, col] of [[8, INK], [6, INK], [7, '#ffcc44'], [4, INK], [2, INK], [3, '#99e550']]) drawCircle(x, 9, 9, r, col);
        return (ICO[kind] = c);
      }
      case 'lantern': g = new G(7, 10); P(t => { t.rect(2, 0, 3, 1, '#c8c0d8'); t.rect(1, 2, 5, 6, '#fff3a8'); t.rect(1, 2, 5, 1, '#e2b896'); t.rect(1, 7, 5, 1, '#e2b896'); }); g.dots([[3, 4], [3, 4.5], [3, 5]], '#ffffff'); break;
      // ---- daily cup twists ----
      case 'mod-lowgrav':
        g = new G(16, 16); P(t => soft(t, 8, 8, 5, 5, ['#f6eaff', '#d8c0f8', '#b89ce6'])); g.ell(6.4, 9.6, 0.9, 0.7, '#c4a8ee'); g.ell(9.6, 6.4, 0.7, 0.6, '#c4a8ee');
        for (let x = 0; x < 16; x += 0.5) { const y = 10.5 - x * 0.35; if (x < 3.6 || x > 12.4) g.dot(x, y, '#fff09a'); } break;
      case 'mod-rain':
        g = new G(16, 16); P(t => { t.ell(6, 6.4, 4, 3.2, '#ffffff'); t.ell(10.5, 5.6, 4, 3.8, '#ffffff'); t.rect(3, 7, 11, 2, '#ffffff'); t.ell(9, 8.2, 5.4, 1.2, '#e2eafa', 0, (x, y) => t.filled(x, y)); });
        for (const [x, y] of [[4.5, 12], [8.5, 11.2], [12.5, 12], [6.5, 14.5], [10.5, 14.5]]) PX.stroke(g, [[x, y], [x - 0.4, y + 1]], 0.35, 0.35, '#9fd0ff'); break;
      case 'mod-giant': { const c = sprig({ species: 'wallnut', stage: 1 }, { arms: 'up', eyes: 'happy', mouth: 'open' }); return (ICO[kind] = c); }
      case 'mod-reverse': g = new G(16, 16); P(t => { t.poly([[1.2, 8], [7, 2.4], [7, 5.6], [14.6, 5.6], [14.6, 10.4], [7, 10.4], [7, 13.6]], '#b8ec9a'); t.poly([[1.2, 8], [14.6, 8], [14.6, 10.4], [7, 10.4], [7, 13.6]], '#94d27e'); }); g.dots([[4, 7.5], [5, 6.5], [8.5, 6.5], [9.5, 6.5]], '#e4fbc8'); bold = true; break;
      case 'mod-night': g = new G(16, 16); P(t => { t.rect(6, 1, 4, 1, '#c8c0d8'); t.rect(7, 2, 2, 1, '#c8c0d8'); }); P(t => { t.rect(4, 4, 8, 9, '#fff3a8'); t.rect(4, 4, 8, 2, '#e2b896'); t.rect(4, 12, 8, 2, '#e2b896'); }); g.ell(8, 8.6, 1.6, 2, '#ffffff'); g.dots([[6, 10.5], [10, 10.5]], '#ffe07a'); bold = true; break;
      case 'mod-party': return (ICO[kind] = icon('itembox'));
      default:
        if (kind.startsWith('medal')) { // medal0..2, medalx = empty
          const k = kind.slice(5), R = k === 'x' ? ['#fffaf0', '#f2e6cc', '#dccaa4'] : MEDAL_RAMPS[+k];
          g = new G(11, 14); P(t => { t.poly([[1, 0], [4, 0], [6.5, 5], [3.5, 5]], k === 'x' ? '#f2e6cc' : '#9fb8f2'); t.poly([[10, 0], [7, 0], [4.5, 5], [7.5, 5]], k === 'x' ? '#e6d6b4' : '#ffa6b4'); });
          P(t => soft(t, 5.5, 9, 4.2, 4.2, R));
          if (k !== 'x') { g.poly(PX.starPts(5.5, 9.2, 2.5, 1.1, 5), R[0]); g.dots([[3.5, 7], [4, 6.5]], '#ffffff'); }
          bold = true; break;
        }
        g = new G(4, 4);
    }
    if (bold) g.outerLine();
    return (ICO[kind] = g.canvas());
  }
  // pastel-rainbow edged item box frames
  function boxFrame(t) {
    const f = Math.floor(t * 8) % 6, key = 'box' + f; if (ICO[key]) return ICO[key];
    const g = new PX.Grid(13, 13);
    for (let y = 0; y < 13; y++) for (let x = 0; x < 13; x++) {
      const edge = x === 0 || y === 0 || x === 12 || y === 12, e2 = x === 1 || y === 1 || x === 11 || y === 11, corner = (x === 0 || x === 12) && (y === 0 || y === 12);
      if (corner) continue;
      if (edge) g.set(x, y, INK); else if (e2) g.set(x, y, RAINBOW[(x + y + f) % 6]); else g.set(x, y, 'rgba(255,255,255,0.82)');
    }
    g.str(QMARK, 4, 3, { '#': '#ffffff' }); g.str(QMARK.map(r => r.replace(/#/g, 'k')), 4, 4, { k: '#8e70c0' }); g.str(QMARK, 4, 3, { '#': '#b89ae6' });
    g.dots([[2, 2], [2.5, 2], [2, 2.5], [3, 2]], '#ffffff');
    return (ICO[key] = g.canvas());
  }
  function honeySpr() {
    if (ICO.hpud) return ICO.hpud;
    const g = new PX.Grid(15, 5); PX.piece(g, t => PX.art.softBody(t, 7.5, 3, 6.8, 1.8, ['#fff0b8', '#ffd27a', '#f0b05a'], { hl: false })); g.ell(4.6, 2.4, 1.6, 0.5, '#fff6d0'); g.dot(10, 3, '#fff6d0');
    return (ICO.hpud = g.canvas());
  }
  const CONF = {};
  function confetti(col, k) { const key = col + k; if (CONF[key]) return CONF[key]; const c = document.createElement('canvas'); c.width = k ? 1 : 2; c.height = k ? 2 : 1; const x = c.getContext('2d'); x.fillStyle = col; x.fillRect(0, 0, 2, 2); return (CONF[key] = c); }
  // puffy clouds: round puffs, a soft shade underneath and a soft outline (TH.puff = [fill, shade, outline])
  function puffs(th) {
    const key = 'puff:' + th; if (ICO[key]) return ICO[key];
    const p = TH[th].puff; if (!p) return (ICO[key] = []);
    const cloud = (w, h, list) => {
      const c = new PX.Grid(w, h), base = h - 1.2, keep = (x, y) => y < base; keep.fine = true;
      for (const [x, y, r] of list) c.ell(x, y, r, r * 0.9, p[1], 0, keep);
      const lit = (x, y) => y < base - 0.6 && c.ffilled(Math.round(x * 2), Math.round(y * 2 + 1.2)); lit.fine = true;
      for (const [x, y, r] of list) c.ell(x - 0.3, y - 0.7, r, r * 0.9, p[0], 0, lit);
      c.outline(p[2]); return c.canvas();
    };
    return (ICO[key] = [cloud(15, 7, [[3.5, 4.4, 2.6], [7, 3.4, 3.2], [11, 4.2, 2.8]]), cloud(10, 6, [[3.4, 3.6, 2.4], [6.6, 3.2, 2.6]]), cloud(20, 8, [[3.8, 5.2, 2.8], [7.8, 3.8, 3.4], [12.4, 3.6, 3.6], [16.4, 5, 2.8]])]);
  }
  // ---------------- course props drawn here (reef, sky islands, jungle, volcano, snow, stars) and the start / finish gates ----------------
  // chibi sticker props: chunky rounded shapes, flat pastel fills with one soft shade (softBody), fine inner outlines, a bold outer ring
  const rpSoft = (t, cx, cy, rx, ry, R, o) => PX.art.softBody(t, cx, cy, rx, ry, R, o), rpPiece = (g, f) => PX.piece(g, f);
  const RPROP = {
    kelp() { const g = new PX.Grid(11, 30); rpPiece(g, t => { for (let y = 29; y >= 3; y -= 0.5) { const x = 5.5 + Math.sin(y * 0.33) * 1.6; t.ell(x, y, 1.15, 0.6, '#9edcb0'); } for (let y = 6; y < 28; y += 6) t.ell(5.5 + Math.sin(y * 0.33) * 1.6 + (y % 12 ? 2.6 : -2.6), y, 2, 1.05, '#b8ecc4', y % 12 ? 0.5 : -0.5); }); g.dots([[5, 20], [6, 12], [5.5, 6]], '#e4fbea'); return g; },
    coral() { const g = new PX.Grid(17, 16); const c = '#ffb0a4'; rpPiece(g, t => { PX.stroke(t, [[8, 15], [8, 9], [4.4, 5.4], [3.6, 2.6]], 1.35, 1.0, c); PX.stroke(t, [[8, 10], [12, 6.4], [12.8, 3.4]], 1.25, 1.0, c); PX.stroke(t, [[8, 8], [8, 3.2]], 1.25, 1.0, c); PX.stroke(t, [[12, 7], [14.8, 7]], 1.0, 0.9, c); }); g.dots([[3.5, 2.5], [8, 3], [12.7, 3.3], [14.8, 6.8], [7.5, 11]], '#ffd8cc'); return g; },
    brain() { const g = new PX.Grid(16, 9); rpPiece(g, t => rpSoft(t, 8, 8.4, 6.8, 6.4, ['#ffe6c4', '#ffc898', '#f2a876'], { mask: (x, y) => y < 8.6 })); for (let x = 3.4; x < 13; x += 3) PX.stroke(g, [[x, 4], [x + 0.8, 5], [x, 6], [x + 0.8, 7]], 0.22, 0.22, '#e8986a'); return g; },
    anemone() { const g = new PX.Grid(13, 12); rpPiece(g, t => { for (let i = 0; i < 6; i++) { PX.stroke(t, [[3 + i * 1.4, 9], [1.4 + i * 2.1, 2.6 + (i % 2) * 2]], 0.65, 0.55, '#ffc6dc'); t.ell(1.4 + i * 2.1, 2.6 + (i % 2) * 2, 0.9, 0.9, '#ffe2ee'); } }); rpPiece(g, t => rpSoft(t, 6.5, 10, 4.2, 1.8, ['#f2e6ff', '#d8c0f8', '#b89ce6'])); return g; },
    clam() { const g = new PX.Grid(13, 9); rpPiece(g, t => rpSoft(t, 6.5, 7, 5.8, 2, ['#f8f0ff', '#dcc8f8', '#bca4ea'], { hl: false })); rpPiece(g, t => { t.poly([[1.2, 6], [3.2, 1.6], [9.8, 1.6], [11.8, 6], [9, 4.4], [4, 4.4]], '#e6d6fc'); }); rpPiece(g, t => t.ell(6.5, 5.4, 1.5, 1.4, '#ffffff')); g.dot(6, 5, '#e8f0ff'); return g; },
    chest() { const g = new PX.Grid(15, 12); rpPiece(g, t => { t.rect(1, 5, 13, 6, '#ecbe96'); t.rect(12, 5, 2, 6, '#d6a27c'); }); rpPiece(g, t => rpSoft(t, 7.5, 5, 6.5, 3.4, ['#f6d4b0', '#ecbe96', '#d6a27c'], { mask: (x, y) => y < 5 })); rpPiece(g, t => { t.rect(1, 5, 13, 1, '#ffe07a'); t.rect(6, 4, 3, 4, '#ffe07a'); }); g.dot(7.2, 6, INK); g.dots([[3, 3], [10.5, 8]], '#fff3a8'); return g; },
    windmill() { const g = new PX.Grid(19, 30); rpPiece(g, t => { t.poly([[6, 29], [7.6, 11.4], [11.4, 11.4], [13, 29]], '#fff8ec'); t.poly([[10.4, 11.4], [11.4, 11.4], [13, 29], [11, 29]], '#f2e6d4'); }); rpPiece(g, t => t.poly([[6.4, 12.2], [9.5, 7.6], [12.6, 12.2]], '#ffa6b4')); rpPiece(g, t => { t.ell(9.5, 24.6, 1.5, 1.8, '#e6c49e'); t.rect(8, 25, 3, 4, '#e6c49e'); });
      rpPiece(g, t => { for (const [x, y] of [[2.4, 2.4], [16.6, 2.4], [2.4, 16.6], [16.6, 16.6]]) PX.stroke(t, [[9.5, 9.5], [x, y]], 0.9, 1.1, '#fff3e0'); }); rpPiece(g, t => t.ell(9.5, 9.5, 1.3, 1.3, '#ffe07a')); return g; },
    pillar() { const g = new PX.Grid(11, 25); rpPiece(g, t => { t.rect(2, 3, 7, 19, '#ffffff'); t.rect(7, 3, 2, 19, '#eceef8'); }); for (const x of [4, 5.5]) PX.stroke(g, [[x, 4], [x, 21]], 0.2, 0.2, '#dfe2f0'); rpPiece(g, t => { t.rect(1, 0, 9, 3, '#ffe48a'); t.rect(1, 22, 9, 3, '#ffe48a'); t.rect(1, 2, 9, 1, '#f2c866'); t.rect(1, 24, 9, 1, '#f2c866'); }); g.dots([[2, 1], [2.5, 1]], '#fffbe2'); return g; },
    balloon() { const g = new PX.Grid(11, 26); rpPiece(g, t => { rpSoft(t, 5.5, 5.6, 4.4, 5, ['#ffd8e0', '#ffa6b8', '#f088a0']); t.poly([[4.4, 10.2], [6.6, 10.2], [5.5, 11.6]], '#f088a0'); }); g.outerLine(); for (let y = 12.5; y < 26; y += 0.5) g.dot(5.5 + Math.sin(y * 0.8) * 0.5, y, '#b0a8c4'); g.noOuter = true; return g; },
    // volcano
    lavarock() { const g = new PX.Grid(15, 10); rpPiece(g, t => rpSoft(t, 7.5, 6.4, 6.4, 3.6, ['#c8b0c8', '#a68aa8', '#8a7090'])); PX.stroke(g, [[4, 5.6], [7, 7.2], [10, 5.4]], 0.45, 0.45, '#ffbc7e'); g.dots([[7, 7], [10, 5.5]], '#fff3a8'); return g; },
    vent() { const g = new PX.Grid(13, 8); rpPiece(g, t => rpSoft(t, 6.5, 7, 5.8, 3, ['#c8b0c8', '#a68aa8', '#8a7090'], { mask: (x, y) => y < 7.2, hl: false })); rpPiece(g, t => t.ell(6.5, 4.6, 1.8, 0.7, '#ffbc7e')); g.dot(6.4, 4.4, '#fff3a8'); return g; },
    charred() { const g = new PX.Grid(15, 24); rpPiece(g, t => { PX.stroke(t, [[7.5, 23.5], [7.5, 7]], 1.1, 0.8, '#a88a9e'); PX.stroke(t, [[7.4, 13], [3.6, 8], [3, 5]], 0.7, 0.55, '#a88a9e'); PX.stroke(t, [[7.6, 10], [11.4, 5.4]], 0.7, 0.55, '#a88a9e'); }); g.dots([[7.5, 17], [8, 20]], '#ffbc7e'); return g; },
    obsidian() { const g = new PX.Grid(11, 14); rpPiece(g, t => { t.poly([[1.2, 13], [3, 4.6], [5.5, 0.8], [7.2, 5], [9.8, 13]], '#b89ae6'); t.poly([[5.5, 0.8], [7.2, 5], [9.8, 13], [5.5, 13]], '#9a7cd2'); }); PX.stroke(g, [[4.4, 4], [3.6, 9]], 0.3, 0.3, '#ecdcff'); return g; },
    // snowy summit
    snowpine() { const g = new PX.Grid(17, 26); rpPiece(g, t => t.rect(7, 21, 3, 5, '#e2b896')); for (let i = 2; i >= 0; i--) rpPiece(g, t => { const by = 11 + i * 5, top = 1 + i * 6, hw = 7.4 - (2 - i) * 1.1; t.poly([[8.5, top], [8.5 + hw, by - 0.4], [8.5 + hw - 1, by + 0.8], [8.5 - hw + 1, by + 0.8], [8.5 - hw, by - 0.4]], '#9cd8c4'); t.poly([[8.5, top], [8.5 + hw, by - 0.4], [8.5 + hw - 1, by + 0.8], [8.5, by + 0.8]], '#7cc0ac'); t.ell(8.5, top + 1.3, 1.6, 1.2, '#ffffff'); PX.stroke(t, [[8.5 - hw + 1.2, by - 0.2], [8.5 + hw - 1.2, by - 0.2]], 0.45, 0.45, '#ffffff'); }); return g; },
    snowman() { const g = new PX.Grid(13, 20); rpPiece(g, t => rpSoft(t, 6.5, 15, 5, 4.4, ['#ffffff', '#f6f8ff', '#d8e2f4'])); rpPiece(g, t => rpSoft(t, 6.5, 7.6, 3.8, 3.5, ['#ffffff', '#f6f8ff', '#d8e2f4'])); rpPiece(g, t => { t.rect(3, 3, 7, 1, '#9fb4ec'); t.rect(4, 0, 5, 3, '#9fb4ec'); });
      rpPiece(g, t => t.poly([[3, 10.6], [10, 10.6], [9.6, 11.8], [3.4, 11.8]], '#ffa6b4')); rpPiece(g, t => t.poly([[7, 8.2], [10.2, 8.8], [7, 9.4]], '#ffb87e')); PX.art.chibiEyes(g, 6.5, 7.6, { sp: 3.4, w: 1.8, h: 2.4 }); PX.art.blush(g, 6.5, 9.5, { sp: 5.2, w: 0.8, h: 0.5 }); g.dots([[6.5, 14], [6.5, 16.5]], '#8e88c4'); return g; },
    igloo() { const g = new PX.Grid(21, 12); rpPiece(g, t => rpSoft(t, 10.5, 12, 9.4, 10, ['#ffffff', '#f2f6ff', '#d4def4'], { mask: (x, y) => y < 11.6 })); for (const y of [5, 8.4]) PX.stroke(g, [[3, y], [18, y]], 0.2, 0.2, '#c8d4ee'); for (const [x, y] of [[6, 3.4], [10.5, 2.4], [15, 3.4], [4.6, 6.8], [8.6, 6.8], [12.6, 6.8], [16.4, 6.8]]) PX.stroke(g, [[x, y], [x, y + 1.4]], 0.2, 0.2, '#c8d4ee'); rpPiece(g, t => t.ell(10.5, 12, 2.8, 3.8, '#8e9ad0', 0, (x, y) => y < 11.6)); return g; },
    // jungle
    fern() { const g = new PX.Grid(17, 12); for (let i = 0; i < 5; i++) rpPiece(g, t => { const a = -Math.PI / 2 + (i - 2) * 0.52, L = 8 - Math.abs(i - 2) * 1.1, ex = 8.5 + Math.cos(a) * L, ey = 11.4 + Math.sin(a) * L; t.ell((8.5 + ex) / 2, (11.4 + ey) / 2, L / 2 + 0.4, 1.6, i % 2 ? '#9cd88e' : '#b4e6a0', a); PX.stroke(t, [[8.5, 11.4], [ex, ey]], 0.18, 0.18, '#7cbc7a'); }); return g; },
    bigleaf() { const g = new PX.Grid(15, 18); rpPiece(g, t => PX.stroke(t, [[7.5, 17.5], [7.5, 9]], 0.55, 0.55, '#8cc87e')); rpPiece(g, t => rpSoft(t, 5, 7, 4.5, 2.5, ['#d4f6bc', '#a8dc92', '#86c47e'], { rot: -0.6 })); rpPiece(g, t => rpSoft(t, 10.5, 5, 4.5, 2.5, ['#d4f6bc', '#a8dc92', '#86c47e'], { rot: 0.6 })); PX.stroke(g, [[2, 9], [7, 6]], 0.2, 0.2, '#86c47e'); PX.stroke(g, [[13, 7], [8, 4]], 0.2, 0.2, '#86c47e'); return g; },
    bamboo() { const g = new PX.Grid(11, 28); for (const [x, h] of [[3, 27], [7, 22]]) rpPiece(g, t => { t.rect(x, 28 - h, 2, h, '#c4ec9a'); for (let y = 28 - h + 4; y < 28; y += 6) t.rect(x, y, 2, 1, '#a2d884'); }); rpPiece(g, t => { t.ell(8.4, 5, 2.5, 1, '#a8dc92', -0.5); t.ell(2.4, 2, 2.5, 1, '#a8dc92', 0.5); }); return g; },
    totem() { const g = new PX.Grid(11, 24); rpPiece(g, t => { t.rect(2, 2, 7, 22, '#ecc49e'); t.rect(7, 2, 2, 22, '#d8aa84'); t.rect(0, 9, 11, 2, '#ecc49e'); }); rpPiece(g, t => { t.ell(4, 5, 1.1, 1.1, '#fff3a8'); t.ell(7, 5, 1.1, 1.1, '#fff3a8'); }); g.dots([[4, 5], [7, 5]], INK); PX.stroke(g, [[4, 7.4], [5.5, 8], [7, 7.4]], 0.3, 0.3, '#ff8f9e'); rpPiece(g, t => { t.ell(4, 13.6, 0.9, 0.7, '#9fd0ff'); t.ell(7, 13.6, 0.9, 0.7, '#9fd0ff'); t.rect(4, 16, 3, 2, '#ffa6b4'); t.rect(3, 20, 5, 1, '#b8ec9a'); }); return g; },
    // starlight sky
    starlamp() { const g = new PX.Grid(9, 22); rpPiece(g, t => { t.rect(4, 6, 1, 15, '#c8c4e4'); t.rect(2, 20, 5, 2, '#a8a4d0'); }); rpPiece(g, t => t.poly(PX.starPts(4.5, 4, 4, 1.9, 5), '#fff3a0')); g.dot(4.2, 3.4, '#ffffff'); return g; },
    moonrock() { const g = new PX.Grid(15, 9); rpPiece(g, t => rpSoft(t, 7.5, 5.8, 6.4, 3.4, ['#f2f0fa', '#d4d2ea', '#b4b2d4'])); g.ell(5, 5.4, 1.3, 0.8, '#bcbad8'); g.ell(10, 6.6, 1.1, 0.7, '#bcbad8'); return g; },
    zonepost() { // the signpost between two gardens of the Grand Prix: a candy-striped pole, an arrow sign with a star, a ball on top
      const g = new PX.Grid(16, 36);
      rpPiece(g, t => { t.rect(7, 6, 2, 30, '#ffffff'); for (let y = 7; y < 35; y += 4) t.poly([[7, y], [9, y - 1.4], [9, y + 0.6], [7, y + 2]], '#ffa6b4'); });
      rpPiece(g, t => { t.poly([[1, 9], [12.5, 9], [15, 11.5], [12.5, 14], [1, 14]], '#fff2d4'); t.poly([[1, 12.6], [13.8, 12.6], [12.5, 14], [1, 14]], '#f2d8a8'); });
      rpPiece(g, t => t.poly(PX.starPts(6.8, 11.5, 2, 0.9, 5), '#ffd76a'));
      rpPiece(g, t => rpSoft(t, 8, 4.2, 2.7, 2.7, ['#ecfcd8', '#b8ec9a', '#94d27e']));
      return g; },
    arch() { // finish arch: poles + checkered banner + balloons
      const g = new PX.Grid(26, 34); rpPiece(g, t => { t.rect(2, 7, 2, 27, '#f2d4b0'); t.rect(22, 7, 2, 27, '#f2d4b0'); });
      rpPiece(g, t => { for (let y = 0; y < 3; y++) for (let x = 0; x < 9; x++) t.rect(4 + x * 2, 8 + y * 2, 2, 2, (x + y) % 2 ? '#8e88c4' : '#ffffff'); });
      for (const [x, y, rx, ry, R] of [[3, 4, 2.4, 2.9, ['#ffd8e0', '#ffa6b8', '#f088a0']], [23, 4, 2.4, 2.9, ['#e0f0ff', '#9fd0ff', '#80b4ec']], [6.5, 3.4, 1.8, 2.2, ['#fffbe2', '#fff09a', '#f2d070']], [19.5, 3.4, 1.8, 2.2, ['#ecfcd8', '#b8ec9a', '#94d27e']]]) rpPiece(g, t => rpSoft(t, x, y, rx, ry, R));
      return g; },
    gate() { // start gate: poles + bunting
      const g = new PX.Grid(22, 30); rpPiece(g, t => { t.rect(1, 4, 2, 26, '#f2d4b0'); t.rect(19, 4, 2, 26, '#f2d4b0'); }); rpPiece(g, t => { t.ell(2, 3, 1.6, 1.6, '#ffe07a'); t.ell(20, 3, 1.6, 1.6, '#ffe07a'); });
      for (let x = 3; x < 19; x++) if ((x - 3) % 4 === 1) { const sag = Math.round(Math.sin((x - 3) / 16 * Math.PI) * 3); rpPiece(g, t => t.poly([[x - 1, 5.6 + sag], [x + 2, 5.6 + sag], [x + 0.5, 9.2 + sag]], RAINBOW[((x - 3) >> 2) % 6])); }
      g.outerLine(); for (let x = 3; x < 19; x += 0.5) { const sag = Math.sin((x - 3) / 16 * Math.PI) * 3; g.dot(x, 5.2 + sag, '#b08a74'); } g.noOuter = true;
      return g; },
  };
  function rprop(kind) { const key = 'rp:' + kind; if (ICO[key] !== undefined) return ICO[key]; let c = null; try { if (RPROP[kind]) { const g = RPROP[kind](); if (!g.noOuter) g.outerLine(); c = g.canvas(); } } catch (e) { console.error('race prop', kind, e); } return (ICO[key] = c); }
  function propSprite(kind, th) {
    if (kind.startsWith('r:')) return rprop(kind.slice(2));
    if (kind.startsWith('c:')) return safeCritter(kind.slice(2));
    return safeProp(kind, TH[th].prop);
  }
  function paint2x(cv, src) { // a small sprite at exactly 2x (crisp) — for 18px critters in 36px slots
    const m = src.k ? 1 : 2; cv.width = src.width * m; cv.height = src.height * m; // (a hi-res critter already has 2x the pixels)
    const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; x.clearRect(0, 0, cv.width, cv.height); x.drawImage(src, 0, 0, cv.width, cv.height);
  }
  function paintTo(cv, src, w, h) { // (w, h in art pixels; a hi-res sprite gets k x the bitmap)
    const k = src.k || 1; cv.width = w ? w * k : src.width; cv.height = h ? h * k : src.height;
    const x = cv.getContext('2d'); x.imageSmoothingEnabled = false; x.clearRect(0, 0, cv.width, cv.height);
    x.drawImage(src, Math.floor((cv.width - src.width) / 2), Math.floor((cv.height - src.height) / 2));
  }
  // a sprout sprite fitted into a small square canvas (canvas can be taller for flower heads)
  function spriteBox(cv, look, pose, size) {
    const src = sprig(look, pose), k = src.k || 1; size = size || 36;
    const h = size + Math.max(0, PX.artH(src) - 32); cv.width = size * k; cv.height = h * k; cv._ah = h; // (bitmap k x the art size)
    const x = cv.getContext('2d'); x.setTransform(k, 0, 0, k, 0, 0); x.imageSmoothingEnabled = false; x.clearRect(0, 0, size, h);
    PX.blit(x, src, size / 2, h - 2, false, sprigAX(), sprigAY());
  }

  // =====================================================================
  // World drawing (shared by the race view and the hub banners)
  // V = { g, W, H, GY, CH, C, camX, t, night, rain, cheer }
  // =====================================================================
  function px(g, x, y, w, h, c) { g.fillStyle = c; g.fillRect(x, y, w, h); }
  function elevAt(V, x) {
    const s = segAtC(V.C, x);
    if (s.type === 'climb') return Math.round(V.CH * clamp((x - s.x0) / s.len, 0, 1));
    if (s.type === 'fly') return Math.round(V.CH * (1 - clamp((x - s.x0) / s.len, 0, 1)));
    return 0;
  }
  const SINK = 5;
  function sinkAt(V, x) { const s = segAtC(V.C, x); if (s.type !== 'swim') return 0; return Math.round(Math.min(SINK, (x - s.x0) * 0.5, (s.x1 - x) * 0.5)); }
  function disc(g, cx, cy, r, col) { g.fillStyle = col; for (let y = -r; y <= r; y++) { const w = Math.floor(Math.sqrt(r * r - y * y + r * 0.8)); g.fillRect(cx - w, cy + y, w * 2 + 1, 1); } }

  // ---- chibi sticker scenery (docs/pvz-art-guide.md §1.11) ----
  // The world canvases are painted at SCENE_K buffer pixels per world pixel (coordinates stay in world pixels; FP = one fine
  // buffer pixel), so outlines are one fine pixel and sparkles / highlights can sit on half pixels.
  const FP = 1 / PX.SCENE_K;
  function hexMix(a, b, k) { const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16), f = (s) => Math.round(((pa >> s) & 255) + (((pb >> s) & 255) - ((pa >> s) & 255)) * k); return '#' + ((1 << 24) | (f(16) << 16) | (f(8) << 8) | f(0)).toString(16).slice(1); }
  // round bumps along a parallax band: the height of the tallest bump over world x a (bell: soft mountain shape)
  function bumpH(a, per, r0, rv, sq, base, seed, bell) {
    let h = base; const k0 = Math.floor(a / per);
    for (let k = k0 - 2; k <= k0 + 2; k++) { const q = hash(k * 131 + seed), c = k * per + (q % 97) / 97 * per * 0.7, r = r0 + (q >>> 9) % rv, d = a - c; if (d > -r && d < r) h = Math.max(h, base * 0.5 + (bell ? r * (1 + Math.cos(Math.PI * d / r)) / 2 : Math.sqrt(r * r - d * d)) * sq); }
    return h;
  }
  // one column of a band: flat fill, an optional soft shade on slopes falling to the right, and a fine outline on top
  // (stretched down the side where the neighbour is lower, so steep edges stay outlined)
  function bandCol(g, sx, GY, h, hl, hr, fill, line, shade) {
    const top = Math.round((GY - h) / FP) * FP, low = Math.min(GY, Math.max(top + FP, Math.round((GY - Math.min(hl, hr)) / FP) * FP));
    px(g, sx, top, 1, GY - top, shade && hr < h - 0.2 ? shade : fill); px(g, sx, top, 1, low - top, line);
    return top;
  }
  function twinkle(g, x, y, c, big) { for (let i = 1; i <= (big ? 2 : 1); i++) { px(g, x - i * FP, y, FP, FP, c); px(g, x + i * FP, y, FP, FP, c); px(g, x, y - i * FP, FP, FP, c); px(g, x, y + i * FP, FP, FP, c); } px(g, x, y, FP, FP, '#ffffff'); }
  // the little sky characters: a smiling sun and a sleepy moon (hi-res sprites, drawn once)
  function skySpr(kind) {
    const key = 'sky:' + kind; if (ICO[key] !== undefined) return ICO[key];
    let c = null;
    try {
      const A = PX.art;
      if (kind === 'sun') {
        const g = new PX.Grid(20, 20), m = 10, r = 5.4;
        PX.piece(g, t => { for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5 + 0.31; t.ell(m + Math.cos(a) * (r + 2.3), m + Math.sin(a) * (r + 2.3), 1.55, 1.55, i % 2 ? '#ffe9a0' : '#ffdf8a'); } });
        PX.piece(g, t => A.softBody(t, m, m, r, r, ['#fffbe2', '#fff0a0', '#ffd77e']));
        A.chibiEyes(g, m + 0.4, m + 0.7, { sp: 4.6, w: 2.5, h: 3.2 }); A.blush(g, m + 0.4, m + 2.8, { sp: 7, w: 0.9, h: 0.55 }); A.chibiMouth(g, m + 0.4, m + 3.2, 'smile', 1.6);
        c = g.canvas();
      } else {
        const g = new PX.Grid(16, 16);
        PX.piece(g, t => A.softBody(t, 8, 8, 5.8, 5.8, ['#fffbea', '#fff1c2', '#f2d896']));
        g.ell(5.6, 5.4, 1, 0.8, '#f6e2a8'); A.chibiEyes(g, 8.4, 8.4, { sp: 4.8, w: 2.5, h: 3.2 }); A.chibiMouth(g, 8.4, 11.2, 'smile', 1.4); A.blush(g, 8.4, 10.6, { sp: 6.6, w: 0.9, h: 0.5 });
        c = g.canvas();
      }
    } catch (e) { c = null; }
    return (ICO[key] = c);
  }
  // the sky's colour gradient never moves: painted once per theme and size, then one drawImage per frame
  const skyCache = {}; let skyN = 0;
  function skyBands(th, key, W, H, GY) {
    const k = key + ':' + W + 'x' + H + ':' + GY; if (skyCache[k]) return skyCache[k];
    if (++skyN > 40) { for (const q in skyCache) delete skyCache[q]; skyN = 1; }
    const K = PX.SCENE_K, c = document.createElement('canvas'); c.width = W * K; c.height = Math.max(1, H) * K; const g = c.getContext('2d'); g.setTransform(K, 0, 0, K, 0, 0);
    const end = Math.max(4, GY + 6);
    for (let y = 0; y < H; y += FP) { const u = Math.min(2.999, y / end * 3), i = Math.floor(u); px(g, 0, y, W, FP, hexMix(th.sky[i], th.sky[i + 1], u - i)); }
    c.k = K; return (skyCache[k] = c);
  }
  function drawSky(V, th, key, starA) {
    const { g, W, GY, camX, t } = V;
    const A0 = g.globalAlpha; // the Grand Prix crossfade draws a second sky at partial alpha: every layer must respect it
    const n = V.night || 0, sc = GY < 30 ? 0.6 : clamp(GY / 58, 1, 1.8);
    { const Hs = Math.max(V.H || 0, GY + 6); g.drawImage(skyBands(th, key, W, Hs, GY), 0, 0, W, Hs); }
    // light rays under the sea
    if (th.rays) {
      g.fillStyle = '#e4fbff';
      const o = Math.floor(camX * 0.05);
      for (let k = Math.floor(o / 40) - 1; k <= Math.floor((o + W) / 40) + 1; k++) {
        const h = hash(k + 5), x0 = k * 40 + (h % 20) - o, wv = 3 + (h >> 4) % 4, al = 0.08 + 0.05 * Math.sin(t * 0.8 + k);
        g.globalAlpha = A0 * al; for (let y = 0; y < GY; y++) g.fillRect(x0 + Math.floor(y * 0.45), y, wv, 1);
      }
      g.globalAlpha = A0;
    }
    // stars: little twinkles (always in the dark worlds; fade in at night elsewhere)
    const sa = th.dark ? 1 : th.rays ? 0 : starA;
    if (sa > 0.05) {
      const s0 = Math.floor(camX * 0.05); g.globalAlpha = A0 * sa;
      for (let sx = 0; sx < W; sx++) { const h = hash(sx + s0 + 999); if (h % (th.dark ? 11 : 16) === 0) { const y = 1 + (h >> 6) % Math.max(4, GY - 12); if ((h >> 9) % 5 === 0) { if (((t * 2 + sx) | 0) % 3) twinkle(g, sx, y, (h >> 3) % 3 ? '#e6e8ff' : '#fff4b0', (h >> 12) % 3 === 0); } else px(g, sx, y, FP * 2, FP * 2, (h >> 3) % 4 ? '#e6e8ff' : '#fff4b0'); } }
      g.globalAlpha = A0;
    }
    if (th.far2 === 'aurora') { // soft ribbons of mint and lilac light
      for (let sx = 0; sx < W; sx++) {
        const a = sx + camX * 0.04, y0 = Math.round(4 * sc + 3 * Math.sin(a * 0.045 + t * 0.4) + 2 * Math.sin(a * 0.11)), col = Math.sin(a * 0.02 + t * 0.2) > 0 ? '#9cf0d4' : '#d4b4ff';
        g.fillStyle = col; for (let k = 0; k < 7; k++) { g.globalAlpha = A0 * (0.3 - k * 0.04); g.fillRect(sx, y0 + k, 1, 1); }
      }
      g.globalAlpha = A0;
    }
    if (th.dark || (n > 0.6 && !th.rays)) { // the sleepy moon
      const m = skySpr('moon'), ma = th.dark ? 1 : clamp((n - 0.6) / 0.3, 0, 1);
      if (m) { g.globalAlpha = A0 * ma; g.drawImage(m, W - 26 - Math.floor(camX * 0.02) % 6, -2, PX.artW(m), PX.artH(m)); g.globalAlpha = A0; }
    } else if (!th.noSun && n < 0.6 && !V.rain) { // the smiling sun
      const s = skySpr('sun'), cy = GY > 70 ? 28 : Math.round(7 * sc), a = 1 - n / 0.6;
      if (s) { g.globalAlpha = A0 * a; g.drawImage(s, W - 30, cy - 10 + Math.round(Math.sin(t * 1.2) * 0.5), PX.artW(s), PX.artH(s)); g.globalAlpha = A0; }
    }
    // far-far layer (parallax .12)
    const f2 = Math.floor(camX * 0.12), c2 = th.far2C;
    if (th.far2 === 'volcanoes') { // round pastel volcanoes with glowing caps and puffy smoke
      const H = a => { const P = 120, k = Math.floor(a / P), h = hash(k + 51), c = k * P + 40 + h % 40, w = 30 + h % 14, d = Math.abs(a - c); if (d >= w) return 0; const u = d / w; return (1 - u * u * (3 - 2 * u)) * (w * 0.62) * sc + 3 * sc; };
      for (let sx = 0; sx < W; sx++) {
        const a = sx + f2, h = H(a); if (h < 3 * sc + 0.5) { bandCol(g, sx, GY - 2, 3 * sc, 3 * sc, 3 * sc, c2[0], c2[1]); continue; }
        const top = bandCol(g, sx, GY - 2, h, H(a - 1), H(a + 1), c2[0], c2[1], c2[1]);
        const P = 120, k = Math.floor(a / P), hh = hash(k + 51), w = 30 + hh % 14; if (h > (w * 0.62) * sc * 0.93 + 3 * sc) { px(g, sx, top + FP, 1, 1.5, c2[2]); if ((a + Math.floor(t * 4)) % 6 === 0) px(g, sx, top + 1.5, 1, FP * 2, c2[2]); }
      }
      for (let k = Math.floor((f2 - 40) / 120); k <= Math.floor((f2 + W + 40) / 120); k++) { // smoke puffs
        const h = hash(k + 51), c = k * 120 + 40 + h % 40 - f2, w = 30 + h % 14, ty = GY - 2 - (w * 0.62) * sc - 3 * sc - 3;
        for (let i = 0; i < 4; i++) { const age = mod(t * 0.35 + i * 0.25, 1), r = 2 + Math.round(age * 3); g.globalAlpha = A0 * (0.7 * (1 - age)); disc(g, c + Math.round(age * 9 + Math.sin(t + i) * 2), Math.round(ty - age * 20 * sc), r, '#d8cce4'); disc(g, c + Math.round(age * 9 + Math.sin(t + i) * 2) - 1, Math.round(ty - age * 20 * sc) - 1, Math.max(1, r - 1), '#f2ecf8'); }
        g.globalAlpha = A0;
      }
    }
    if (th.far2 === 'town') { // a town skyline (art-world3.js Rooftop): houses and towers, some with pointy roofs, rows of little lit windows
      const H = a => { const k = Math.floor(a / 12), q = hash(k + 41), hh = (5 + q % 13) * sc; return q % 4 === 0 ? hh * 0.8 + Math.max(0, 6 - Math.abs(mod(a, 12) - 6)) * 0.6 * sc : hh; };
      for (let sx = 0; sx < W; sx++) {
        const a = sx + f2, u = mod(a, 12), top = bandCol(g, sx, GY - 2, H(a), H(a - 1), H(a + 1), c2[0], c2[1]);
        if (u === 0) px(g, sx, top, 1, GY - 2 - top, c2[1]);
        else if (u % 3 === 2 && u < 11) for (let y = top + 3; y < GY - 4; y += 4) px(g, sx, y, 1, FP * 2, c2[2]);
      }
    }
    if (th.far2 === 'canopy') { // distant round tree crowns
      for (let sx = 0; sx < W; sx++) { const a = sx + f2, H = b => bumpH(b, 15, 8, 5, 1, 6 * sc, 61, false); bandCol(g, sx, GY - 2, H(a), H(a - 1), H(a + 1), c2[1], c2[2]); }
    }
    if (th.far2 === 'planets') { // a ringed planet and a little moon
      const p1 = mod(Math.round(70 - camX * 0.03), W + 60) - 30, p2 = mod(Math.round(20 - camX * 0.05), W + 40) - 20, py = Math.round(16 * sc);
      for (let sx = 0; sx < W; sx++) { const a = sx + camX * 0.04, y0 = Math.round(GY * 0.3 + 5 * Math.sin(a * 0.03) + 3 * Math.sin(a * 0.071)); g.fillStyle = Math.sin(a * 0.013) > 0 ? '#f0a8dc' : '#a8c0f8'; for (let k = 0; k < 9; k++) { g.globalAlpha = A0 * (0.14 - Math.abs(k - 4) * 0.027); g.fillRect(sx, y0 + k, 1, 1); } }
      g.globalAlpha = A0;
      const ringPts = front => { g.fillStyle = '#fff3a8'; for (let i = 0; i < 140; i++) { const an = i / 140 * Math.PI * 2, x = Math.cos(an) * 13, y = Math.sin(an) * 3.2; if ((y > 0) !== front) continue; g.fillRect(p1 + Math.round(x / FP) * FP, py + 1 + Math.round((y - x * 0.22) / FP) * FP, FP * 2, FP * 2); } };
      ringPts(false); disc(g, p1, py, 9, INK); disc(g, p1, py, 8, '#e8a2cc'); disc(g, p1 + 1, py + 1, 7, '#f6b8da'); disc(g, p1 - 2, py - 2, 5, '#fcd0e6'); px(g, p1 - 4, py - 4, 2, FP * 2, '#ffffff'); ringPts(true);
      disc(g, p2, Math.round(30 * sc), 4, INK); disc(g, p2, Math.round(30 * sc), 3, '#bfe4ff'); px(g, p2 - 1, Math.round(30 * sc) - 1, FP * 2, FP * 2, '#ffffff');
    }
    if (th.far2 === 'mountains' || th.far2 === 'softserve' || th.far2 === 'reefs' || th.far2 === 'isles') {
      for (let sx = 0; sx < W; sx++) {
        const a = sx + f2;
        if (th.far2 === 'mountains') { // soft bell mountains with snowy caps
          const H = b => bumpH(b, 34, 15, 10, 1.15 * sc, 4 * sc, 17, true), h = H(a), top = bandCol(g, sx, GY - 3, h, H(a - 1), H(a + 1), c2[0], c2[3], c2[1]);
          const d = h - 15 * sc; if (d > 0) { const dep = Math.min(d * 0.7, 5) + Math.sin(a * 1.7) * 0.5 + 0.5; px(g, sx, top + FP, 1, Math.max(FP, Math.round(dep / FP) * FP), c2[2]); px(g, sx, top + FP + Math.max(FP, Math.round(dep / FP) * FP), 1, FP, c2[3]); }
        } else if (th.far2 === 'softserve') { // swirly soft-serve hills
          const P = 46, k = Math.floor(a / P), d = a - k * P - P / 2, r = 14 + hash(k + 3) % 7;
          const hh = Math.max(0, r - Math.abs(d)) * 1.25 * sc; if (hh <= 0) continue;
          const col = hash(k + 3) % 2 ? c2[0] : c2[2], top = bandCol(g, sx, GY - 3, hh, Math.max(0, r - Math.abs(d - 1)) * 1.25 * sc, Math.max(0, r - Math.abs(d + 1)) * 1.25 * sc, col, hexMix(c2[1], '#b07090', 0.25));
          for (let y = top + 2; y < GY - 3; y += 5) px(g, sx, y + ((a + k) % 5 === 0 ? 1 : 0), 1, FP * 2, c2[1]);
          if (Math.abs(d) < 1 && hh > 4) { px(g, sx, top - 1, 1, 1, '#ff9fb4'); }
        } else if (th.far2 === 'reefs') {
          const H = b => bumpH(b, 13, 5, 5, 0.9 * sc, 7 * sc, 23, false); bandCol(g, sx, GY - 2, H(a), H(a - 1), H(a + 1), c2[mod(a, 29) < 3 ? 1 : 0], hexMix(c2[0], '#3a6a9a', 0.25));
        } else if (th.far2 === 'isles') { // little floating islands with a waterfall
          const P = 58, k = Math.floor(a / P), h = hash(k + 17), w = 10 + h % 12, d = a - (k * P + 16 + (h >> 5) % 26);
          if (Math.abs(d) > w / 2) continue;
          const by = Math.round(GY - 20 * sc - (h >> 8) % 9), e = w / 2 - Math.abs(d), dep = Math.max(1, Math.round(Math.sqrt(Math.max(0, e * (w - e))) * 0.55));
          px(g, sx, by - FP, 1, FP, '#7cb46e'); px(g, sx, by, 1, 1, '#c4f09a'); px(g, sx, by + 1, 1, dep, (a & 3) ? '#e8d4c0' : '#dcc6b0'); px(g, sx, by + 1 + dep, 1, FP, '#b8a08c');
          if (h % 2 && Math.abs(d) <= 2) { px(g, sx, by - 3 + (Math.abs(d) >> 1), 1, 3 - (Math.abs(d) >> 1), '#94cc72'); }
          if (d === Math.round(w / 4)) { for (let y = by + 2 + dep; y < GY; y++) px(g, sx, y, 1, 1, ((y + Math.floor(t * 8)) % 3) ? '#f2fbff' : '#c4e8ff'); }
        }
      }
    }
    // puffy clouds (parallax .15)
    const pf = puffs(key);
    if (pf.length) {
      const cx0 = Math.floor(camX * 0.15), sp = GY > 70 ? 42 : th.style === 'island' ? 50 : 70, ymax = Math.max(2, Math.min(Math.round(7 * sc) + (GY > 70 ? GY - 60 : 0), GY - 20));
      for (let k = Math.floor((cx0 - 40) / sp); k <= Math.floor((cx0 + W + 20) / sp); k++) {
        const h = hash(k + 11), spr = pf[h % 3];
        g.drawImage(spr, k * sp + (h % 30) - cx0, 2 + ((h >> 4) % ymax), PX.artW(spr), PX.artH(spr));
      }
    }
    if (th.surface) { // shimmering light at the water surface
      for (let sx = 0; sx < W; sx++) { const y = Math.round(1 + Math.sin((sx + camX * 0.1) * 0.21 + t * 2) * 1.2); px(g, sx, y, 1, FP * 2, '#f0feff'); if ((sx + Math.floor(t * 3)) % 7 === 0) twinkle(g, sx, y + 2, '#c8f4fc'); }
    }
    if (th.fish) { // little pastel fish swimming left
      const cx0 = Math.floor(camX * 0.2 + t * 5); // swimming is part of the scroll, so schools never jump when a timer wraps
      for (let k = Math.floor((cx0 - 60) / 80); k <= Math.floor((cx0 + W + 60) / 80); k++) {
        const h = hash(k + 71), n2 = 3 + h % 3, bx = k * 80 + (h % 40) - cx0, by = 10 + (h >> 6) % Math.max(4, GY - 30);
        const col = ['#ffe08a', '#ffb4a0', '#fff3a8', '#dcc2f8'][h % 4], fin = ['#f6b468', '#f28a86', '#f6cc6a', '#b89ae6'][h % 4];
        for (let i = 0; i < n2; i++) {
          const fx = bx + i * 7 + (hash(k * 7 + i) % 3), fy = by + (hash(k * 13 + i) % 7) + Math.round(Math.sin(t * 2 + i) * 0.8), wag = (Math.floor(t * 6) + i) & 1;
          px(g, fx - FP, fy - FP, 3 + FP * 2, 2 + FP * 2, INK); px(g, fx, fy, 3, 2, col); px(g, fx + 1, fy + 1, 2, FP * 2, fin); px(g, fx + FP, fy + FP, FP, FP, INK);
          px(g, fx + 3, fy - wag * FP * 2, 1, 1, fin); px(g, fx + 3, fy + 1 + wag * FP * 2, 1, 1, fin);
        }
      }
    }
    if (th.bubbles) { // bubbles drifting up
      for (let k = 0; k < 16; k++) {
        const h = hash(k + 901), span = GY + 6, bx = mod((h % 700) - Math.floor(camX * 0.45), W + 10) - 5 + Math.round(Math.sin(t * 2 + k) * 1.2), by = GY + 2 - mod(Math.floor(t * (7 + h % 9)) + (h >> 6), span);
        if ((h >> 3) % 3 === 0) { disc(g, bx, by, 1, '#bfeefa'); px(g, bx - FP, by - FP, FP, FP, '#ffffff'); } else px(g, bx, by, FP * 2, FP * 2, '#e4fbff');
      }
    }
    // far + near layers
    const hA = Math.floor(camX * 0.3), hB = Math.floor(camX * 0.55);
    const fc = th.farC, nc = th.nearC, small = sc;
    for (let sx = 0; sx < W; sx++) {
      const a = sx + hA, b = sx + hB;
      if (th.far === 'hills') {
        const H = q => bumpH(q, 30, 13, 10, 0.42 * small, 5 * small, 3, false), h = H(a), top = bandCol(g, sx, GY, h, H(a - 1), H(a + 1), fc[0], fc[1]);
        if (th.pyramids && mod(a, 90) > 30 && mod(a, 90) < 52) { const d = Math.abs(mod(a, 90) - 41), ph = (11 - d) * 1.0 * small; if (ph > 0) { const pt = Math.round((top + 2 - ph) / FP) * FP; px(g, sx, pt, 1, top + 2 - pt, mod(a, 90) < 41 ? '#fbe6b4' : '#ecca8c'); px(g, sx, pt, 1, FP, '#c8a46e'); if (d < 0.6) px(g, sx, pt - FP, 1, FP, '#c8a46e'); } }
      } else if (th.far === 'sea') {
        const hz = GY - Math.round(8 * small);
        for (let y = hz; y < GY; y++) px(g, sx, y, 1, 1, hexMix(fc[2] === '#ffffff' ? '#d8f4fc' : fc[0], fc[0], Math.min(1, (y - hz) / 4)));
        px(g, sx, hz, 1, FP, fc[3]);
        const isl = mod(a, 150); if (isl > 20 && isl < 44) { const ih = Math.sqrt(144 - (isl - 32) * (isl - 32)) / 3; if (ih > 0.4) { const it = Math.round((hz - ih) / FP) * FP; px(g, sx, it, 1, hz - it, fc[1]); px(g, sx, it, 1, FP, fc[4] || fc[3]); } }
        const q = hash(a * 3 + Math.floor(t * 2)); if (q % 13 === 0) twinkle(g, sx, hz + 2 + hash(a) % Math.max(1, Math.round(8 * small) - 3), '#e8faff', q % 39 === 0); else if (q % 7 === 0) px(g, sx, hz + 2 + hash(a + 5) % 4, 1.5, FP, '#e8faff');
      } else if (th.far === 'peaks') {
        const H = q => bumpH(q, 22, 9, 7, 1.0 * small, 5 * small, 9, true); bandCol(g, sx, GY, H(a), H(a - 1), H(a + 1), fc[0], fc[1], fc[1]);
      } else if (th.far === 'gumdrops') {
        const P = 26, k = Math.floor(a / P), d = a - k * P - P / 2, r = 9 + hash(k) % 4, hf = dd => Math.sqrt(Math.max(0, r * r - dd * dd)) * small * 0.9;
        const hh = hf(d);
        if (hh > 0) { const col = fc[hash(k) % 4], top = bandCol(g, sx, GY, hh, hf(d - 1), hf(d + 1), col, hexMix(col, '#8a4a6a', 0.35)); if (hh > 3 && Math.abs(d + 3) < 1) px(g, sx, top + 2, FP * 2, FP * 2, '#ffffff'); if (hash(a * 5) % 9 === 0) px(g, sx, top + 1 + hash(a) % Math.max(1, Math.round(hh) - 1), FP, FP, '#ffffff'); }
      } else if (th.far === 'reef') { // colourful coral heads
        const P = 19, k = Math.floor(a / P), hk = hash(k + 9), d = a - k * P - P / 2, r = 4 + hk % 5, hf = dd => Math.sqrt(Math.max(0, r * r - dd * dd)) * (hk % 3 === 0 ? 1.4 : 0.8) * small;
        const bump = hf(d);
        if (bump > 0) { const col = fc[hk % 3], top = bandCol(g, sx, GY, bump, hf(d - 1), hf(d + 1), col, hexMix(col, '#7a4a6a', 0.35)); for (let y = top + 2; y < GY; y += 3) if ((a + y) % 3 === 0) px(g, sx, y, FP * 2, FP * 2, fc[3]); }
      } else if (th.far === 'cloudsea') {
        const H = q => bumpH(q, 12, 5, 4, 0.8 * small, 3 * small, 13, false); bandCol(g, sx, GY, H(a), H(a - 1), H(a + 1), fc[0], fc[2]); px(g, sx, GY - 1.5, 1, 1.5, fc[1]);
      }
      // near layer
      if (th.near === 'clouds') {
        const H = q => bumpH(q, 10, 4, 4, 0.8 * small, 2 * small, 29, false); bandCol(g, sx, GY, H(b), H(b - 1), H(b + 1), nc[0], nc[2]); px(g, sx, GY - 1, 1, 1, nc[1]);
      } else if (th.near === 'trees') { // round tree crowns over low hedges
        const P = 17, k = Math.floor(b / P), q = hash(k + 1), c = k * P + 8 + q % 4, r = 3 + q % 3, crown = q % 3 !== 0;
        const lowH = v => (2.5 + 1.5 * Math.sin(v * 0.11 + 0.5) + Math.sin(v * 0.27)) * small;
        const top = bandCol(g, sx, GY, lowH(b), lowH(b - 1), lowH(b + 1), nc[0], nc[1]);
        if (crown && Math.abs(b - c) <= r + 0.6) {
          const ch = dd => Math.abs(dd) > r ? 0 : Math.sqrt(r * r - dd * dd) * 1.15 * small, cy = GY - lowH(c) - r * 0.9 * small, d = b - c, h = ch(d);
          if (Math.abs(d) < 0.8) px(g, sx, cy, 1, GY - lowH(b) - cy + 1, '#c49a76');
          if (h > 0) { const t0 = Math.round((cy - h * 0.85) / FP) * FP, t1 = Math.round((cy + h * 0.75) / FP) * FP; px(g, sx, t0, 1, t1 - t0, d > r * 0.35 ? nc[3] : nc[2]); px(g, sx, t0, 1, FP, nc[1]); px(g, sx, t1, 1, FP, nc[1]); if (Math.abs(d) >= r - 0.6) px(g, sx, t0, 1, t1 - t0, nc[1]); if (d < -r * 0.3 && d > -r * 0.7 && h > 2) px(g, sx, t0 + 1, 1, FP * 2, hexMix(nc[2], '#ffffff', 0.4)); }
        }
      } else if (th.near === 'pines') { // chibi pines in a row
        const P = 13, k = Math.floor(b / P), q = hash(k + 2), d = b - (k * P + 6), r = 3 + q % 2, lowH = v => (2.5 + 1.5 * Math.sin(v * 0.11 + 0.5) + Math.sin(v * 0.27)) * small;
        const pineH = dd => q % 4 && Math.abs(dd) <= r ? (r - Math.abs(dd)) * 2.4 * small + 1 : 0;
        const h = lowH(b) + pineH(d), top = bandCol(g, sx, GY, h, lowH(b - 1) + pineH(d - 1), lowH(b + 1) + pineH(d + 1), pineH(d) > 0 ? (nc[2] || nc[0]) : nc[0], nc[1], pineH(d) > 0 ? (nc[3] || nc[1]) : null);
        if (th.nearTop && pineH(d) > 0) px(g, sx, top + FP, 1, 1, th.nearTop);
      } else if (th.near !== 'kelp') { // low rounded bumps
        const lowH = v => (2.5 + 1.5 * Math.sin(v * 0.11 + 0.5) + Math.sin(v * 0.27)) * small;
        if (lowH(b) > 0.3) bandCol(g, sx, GY, lowH(b), lowH(b - 1), lowH(b + 1), nc[0], nc[1]);
      }
    }
    if (th.style === 'island' && V.H > GY) { px(g, 0, GY, W, V.H - GY, nc[1]); for (let sx = 0; sx < W; sx++) if (hash(sx + hB + 7) % 11 === 0) twinkle(g, sx, GY + 2 + hash(sx + hB) % Math.max(1, V.H - GY - 3), '#f4f8ff'); }
    if (th.near === 'kelp') { // swaying seaweed
      const o = Math.floor(camX * 0.55);
      for (let k = Math.floor(o / 9) - 1; k <= Math.floor((o + W) / 9) + 1; k++) {
        const h = hash(k + 33); if (h % 3 === 0) continue;
        const bx = k * 9 + h % 6 - o, hh = Math.round((6 + h % 10) * small);
        for (let y = 0; y < hh; y++) { const x = bx + Math.round(Math.sin(t * 1.4 + y * 0.35 + k) * 1.3 * y / hh); px(g, x - FP, GY - 1 - y, 1 + FP * 2, 1, nc[1]); px(g, x, GY - 1 - y, 1, 1, y % 4 ? nc[0] : hexMix(nc[0], '#ffffff', 0.3)); }
      }
    }
    if (th.boat) { const bx = mod(Math.floor(-camX * 0.3 + t * 3), W + 60) - 30, by = GY - Math.round(8 * small); px(g, bx - FP, by - 2 - FP, 7 + FP * 2, 2 + FP * 2, INK); px(g, bx, by - 2, 7, 2, '#f2c4a0'); px(g, bx + 1, by - 1, 5, 1, '#e0a684'); px(g, bx + 3, by - 9, 1, 7, '#c8b0a0'); px(g, bx + 4 - FP, by - 8 - FP, 3 + FP * 2, 5 + FP * 2, INK); px(g, bx + 4, by - 8, 3, 5, '#ffffff'); px(g, bx + 4, by - 8, 1, 1, '#ff9fb4'); }
    // ambient life
    if (th.birds && n < 0.5) {
      for (let k = 0; k < 3; k++) {
        const h = hash(k + 401), bx = mod(Math.floor((h % 300) - camX * 0.2 + t * (6 + k * 2)), W + 40) - 20, by = 4 + (h >> 7) % Math.max(4, Math.round(GY * 0.35)) + Math.round(Math.sin(t + k) * 1.5), up = (Math.floor(t * 5) + k) & 1;
        g.fillStyle = th.dark ? '#c8d8ff' : '#7a78a8'; g.fillRect(bx, by, 1, FP * 2); g.fillRect(bx - 1, by - up * FP * 2, 1, FP * 2); g.fillRect(bx + 1, by - up * FP * 2, 1, FP * 2); g.fillRect(bx - 2, by - FP * 2, 1, FP * 2); g.fillRect(bx + 2, by - FP * 2, 1, FP * 2);
      }
    }
    if (th.vines) { // vines hanging from the canopy, with little leaves
      const o = Math.floor(camX * 0.8);
      for (let k = Math.floor(o / 17) - 1; k <= Math.floor((o + W) / 17) + 1; k++) {
        const h = hash(k + 123); if (h % 3 === 0) continue;
        const bx = k * 17 + h % 9 - o, len = Math.round((6 + h % 14) * sc);
        for (let y = 0; y < len; y++) { const x = bx + Math.round(Math.sin(t * 1.1 + y * 0.3 + k) * y / len * 1.5); px(g, x, y, FP * 2, 1, '#7cb86e'); if (y % 4 === 2) { const lx2 = x + ((y >> 2) & 1 ? 1 : -1.5); px(g, lx2, y - FP, 1.5, 1, '#a8dc8e'); px(g, lx2, y - FP, 1.5, FP, '#7cb86e'); } }
      }
    }
    if (th.parrots && n < 0.5) for (let k = 0; k < 2; k++) { // pastel parrots
      const h = hash(k + 811), bx = mod(Math.floor((h % 300) - camX * 0.3 + t * (9 + k * 3)), W + 40) - 20, by = 8 + (h >> 7) % Math.max(4, Math.round(GY * 0.3)) + Math.round(Math.sin(t * 2 + k) * 2), up = (Math.floor(t * 6) + k) & 1, cc = k ? '#ffa6b4' : '#9fd0ff';
      px(g, bx - FP, by - FP, 3 + FP * 2, 2 + FP * 2, INK); px(g, bx, by, 3, 2, cc); px(g, bx + 3, by, 1, 1, '#fff09a'); px(g, bx - 1, by + 1, 1, 1, '#b8ec9a'); px(g, bx + 1, by - 1 - up, 1, 1 + up, cc); px(g, bx + 2, by + FP, FP, FP, INK);
    }
    if (th.embers) for (let k = 0; k < 14; k++) { // rising embers
      const h = hash(k + 707), ex = mod((h % 500) - Math.floor(camX * 0.5) + Math.round(Math.sin(t * 1.5 + k) * 3), W), ey = GY - mod(Math.floor(t * (10 + h % 10)) + (h >> 5), GY + 4);
      px(g, ex, ey, 1, 1, (h & 1) ? '#fff09a' : '#ffbc7e');
    }
    if (th.snow) for (let k = 0; k < 26; k++) { // snowfall
      const h = hash(k + 919), ex = mod((h % 600) - Math.floor(camX * 0.6) + Math.round(Math.sin(t * 1.2 + k) * 3), W + 8) - 4, ey = mod(Math.floor(t * (8 + h % 8)) + (h >> 5), GY + 6);
      if (h % 5 === 0) disc(g, ex, ey, 1, '#ffffff'); else px(g, ex, ey, 1, 1, '#ffffff');
    }
    if (th.shooting) { // a shooting star now and then
      const cyc = Math.floor(t / 2.6), ph = t / 2.6 - cyc, h = hash(cyc + 5);
      if (ph < 0.3) { const x0 = h % W, y0 = 3 + (h >> 8) % Math.max(4, GY >> 1), q = ph / 0.3; for (let i = 0; i < 6; i++) { g.globalAlpha = A0 * ((1 - i / 6) * (1 - q)); px(g, x0 - Math.round(q * 30) + i * 2, y0 + Math.round(q * 12) - i, 1, 1, i ? '#fff4b0' : '#ffffff'); } g.globalAlpha = A0; }
    }
    if (th.fireflies || (n > 0.6 && th.near === 'trees')) {
      for (let k = 0; k < 9; k++) {
        const h = hash(k + 77), fx = mod(Math.floor((h % 400) - camX * 0.6 + Math.sin(t * 0.7 + k) * 6), W + 8) - 4, fy = GY - 4 - (h >> 5) % Math.max(4, Math.round(GY * 0.5)) + Math.round(Math.sin(t * 1.3 + k * 2) * 2);
        if ((Math.floor(t * 2) + k) % 5 === 0) continue; g.globalAlpha = A0 * 0.4; disc(g, fx, fy, 1, '#e8ffb0'); g.globalAlpha = A0; px(g, fx, fy, 1, 1, '#f8ffd8');
      }
    }
  }

  function drawGround(V) {
    const { g, W, H, GY, CH, C, camX, t } = V;
    for (let sx = 0; sx < W; sx++) {
      const wx = camX + sx, s = segAtC(C, wx), hs = hash(wx), th = TH[themeAt(C, wx)], st = th.style;
      if (s.type === 'climb') {
        const R = th.rock, e = Math.round(CH * clamp((wx - s.x0 + 1) / s.len, 0, 1)), top = GY - e;
        if (st === 'island') { // rainbow bridge: an arch of pastel colour with sky showing below
          px(g, sx, top - FP, 1, FP, INK); px(g, sx, top, 1, 1, '#ffffff');
          for (let k = 0; k < 6; k++) px(g, sx, top + 1 + k, 1, 1, R[k]);
          px(g, sx, top + 7, 1, FP, INK);
          if (hs % 6 === 0) px(g, sx, top + FP, FP, FP, '#fff3a0');
          continue;
        }
        px(g, sx, top, 1, H - top, R[0]);
        if (st === 'reef') { // rounded coral polyps in staggered rows
          for (let y = top + 1; y < H; y++) { const ry = y - GY + 20, row = Math.floor(ry / 3), cx = mod(wx + (row & 1) * 2, 4), cy = mod(ry, 3); if (cy === 2 || cx === 3) px(g, sx, y, 1, FP * 2, R[1]); else if (cy === 0 && cx === 0) px(g, sx, y, FP * 2, FP * 2, R[2]); }
        } else if (th.stripes) { // candy stripes
          for (let y = top + 1; y < H; y++) { const q = ((wx + y) >> 1) % 4; if (q === 0) px(g, sx, y, 1, 1, R[4]); else if (q === 1) px(g, sx, y, 1, 1, R[2]); }
        } else if (th.ice) { // glassy ice with diagonal shine
          for (let y = top + 1; y < H; y++) { const q = mod(wx - y * 2, 13); if (q === 0) px(g, sx, y, 1, 1, R[3]); else if (q === 1) px(g, sx, y, 1, 1, R[2]); }
        } else { // soft rounded blocks: fine mortar lines, a light top edge on every block
          for (let y = top + 1; y < H; y++) {
            const ry = y - GY, bx = mod(wx + ((ry >> 2) & 1) * 3, 6);
            if (mod(ry, 4) === 3) px(g, sx, y + 1 - FP, 1, FP, R[1]);
            else if (mod(ry, 4) === 0) px(g, sx, y, 1, FP, R[2]);
            if (bx === 0) px(g, sx, y, FP, 1, R[1]);
            if (th.lava && hash(wx * 3 + y * 7) % 29 === 0) { px(g, sx, y, 1, FP * 2, R[4]); px(g, sx, y + FP, FP, FP, '#fff09a'); }
          }
        }
        px(g, sx, top, 1, FP * 2, R[3]); px(g, sx, top - FP, 1, FP, INK);
        if (th.moss && hs % 3 === 0) { px(g, sx, top, 1, FP * 2, '#a8dc8e'); if (hs % 7 === 0) px(g, sx, top + FP * 2, 1, 1, '#86c47a'); }
        if (th.ice && hs % 5 === 0) px(g, sx, top + FP, FP, FP, '#ffffff');
        if (st === 'reef' && hs % 5 === 0) px(g, sx, top - 1, 1, 1 - FP, R[4]);
        if (wx === s.x1 - 1) px(g, sx + 1 - FP, top - FP, FP, H - top + FP, INK);
      } else if (s.type === 'fly') {
        if (st === 'reef') { // riding the current over the sea floor
          px(g, sx, H - 2, 1, 2, '#f0dcb0'); px(g, sx, H - 2 - FP, 1, FP, '#fdf0d0');
          for (let y = GY - 2; y < H - 3; y += 3) if (mod(wx + y * 5 - Math.floor(t * 45), 19) < 3) px(g, sx, y, 1, FP * 2, '#e4fbff');
          if (hs % 13 === 0) px(g, sx, H - 3, 1, 1, '#ffb0a0');
          continue;
        }
        const c = th.cloud, ph = mod(wx, 7), ct = GY + 2.5 - Math.sqrt(Math.max(0, 12.25 - (ph - 3.5) * (ph - 3.5))) * 0.55 + Math.sin(wx * 0.13 + t * 0.8) * 0.6, cty = Math.round(ct / FP) * FP;
        px(g, sx, cty - FP, 1, FP, c[2]); px(g, sx, cty, 1, H - cty, c[1]); px(g, sx, cty, 1, 1, c[0]); px(g, sx, cty + 2.5, 1, H - cty - 2.5, c[2]);
        if (ph === 0) px(g, sx, cty, FP, 2.5, c[2]);
        if (th.sparkleFloor && hs % 11 === 0 && (Math.floor(t * 3) + hs) % 3) twinkle(g, sx, cty + 2 + (hs >> 4) % Math.max(1, H - cty - 3), '#fff3a0');
        if (wx === s.x1 - 1) px(g, sx + 1 - FP, GY - 1, FP, H - GY + 1, INK);
      } else if (s.type === 'swim') {
        const w = th.water;
        px(g, sx, GY + 1, 1, 1, w[0]); px(g, sx, GY + 2, 1, H - GY - 4, w[1]); px(g, sx, H - 2, 1, 2, w[2]);
        if (hs % 17 === 0) px(g, sx, H - 3, 1, 1, st === 'reef' ? '#ffb0a0' : w[2]);
        if (th.steam && hs % 7 === 0) { const age = mod(t * 0.8 + (hs >> 5) % 10 / 10, 1); g.globalAlpha = 0.6 * (1 - age); disc(g, sx + Math.round(Math.sin(t * 2 + wx) * 1.5), GY - Math.round(age * 12), 1, '#ffffff'); g.globalAlpha = 1; }
        if (wx === s.x0) px(g, sx, GY, FP, H - GY, INK); if (wx === s.x1 - 1) px(g, sx + 1 - FP, GY, FP, H - GY, INK);
      } else {
        const tp = th.top, soil = th.soil;
        if (st === 'island' && !s.after && wx >= 0) { // floating island: a grass lip, soft earth, a rounded underside that tapers at the ends
          const e = Math.min(wx - s.x0, s.x1 - 1 - wx), dep = Math.min(H - GY, 3 + Math.floor(Math.sqrt(Math.max(0, e)) * 2.2));
          if (e < 0) continue;
          px(g, sx, GY - FP, 1, FP, tp[2]); px(g, sx, GY, 1, 1.5, (Math.floor(wx / 8) & 1) ? tp[1] : tp[0]); px(g, sx, GY + 1.5, 1, FP, tp[2]);
          px(g, sx, GY + 1.5 + FP, 1, dep - 1.5 - FP, soil[0]); px(g, sx, GY + dep - 1, 1, 1, soil[1]); px(g, sx, GY + dep, 1, FP, INK);
          if (e === 0) px(g, sx + (wx === s.x0 ? 0 : 1 - FP), GY - FP, FP, dep + FP, INK);
          if (th.tuft && hs % 6 === 0) px(g, sx, GY - 1, FP, 1, th.tuft);
          if (hs % 29 === 0) px(g, sx, GY - 1, 1, 1, th.dots[(hs >> 5) % 2]);
          if (wx === 0) px(g, sx, GY, 1, 2, '#ffffff');
          continue;
        }
        // a soft checker lawn seen from the side: tiles of two tones along the top, a darker lip, then soft earth
        px(g, sx, GY - FP, 1, FP, tp[2]); px(g, sx, GY, 1, 3, (Math.floor(wx / 8) & 1) ? tp[1] : tp[0]);
        px(g, sx, GY + FP, 1, FP, (Math.floor(wx / 8) & 1) ? tp[0] : hexMix(tp[0], '#ffffff', 0.35));
        const lip = mod(wx, 4) === 1 || mod(wx, 4) === 2 ? FP : 0;
        px(g, sx, GY + 3, 1, FP + lip, tp[2]);
        px(g, sx, GY + 3 + FP + lip, 1, H - GY - 3 - FP - lip, soil[0]);
        if (th.sprinkles) { if (hs % 4 === 0) px(g, sx, GY + 5 + (hs >> 3) % Math.max(1, H - GY - 6), (hs >> 7) & 1 ? FP * 2 : 1, (hs >> 7) & 1 ? 1 : FP * 2, th.dots[(hs >> 5) % th.dots.length]); }
        else {
          if (hs % 9 === 0) { const py = GY + 4.5 + (hs >> 3) % 2; px(g, sx, py, 1.5, 1, soil[1]); px(g, sx, py, 1, FP, th.soilDot); } // little round pebbles
          if (H - GY > 8) { // deep ground (time trial): soft strata and pebbles
            for (let y = GY + 9; y < H; y += 7) { const q = hash(wx * 3 + y * 17); if (q % 37 === 0) { px(g, sx, y + 2, 3, 2, th.rock[1]); px(g, sx, y + 2, 2, FP * 2, th.rock[2]); } else if (q % 5 === 0) px(g, sx, y, 1, FP, soil[1]); }
          }
          if (st === 'reef' && hs % 23 === 0) px(g, sx, GY + 1, FP * 2, FP * 2, '#ffb0a0');
          if (th.cracks && hs % 13 === 0) { px(g, sx, GY + 1, FP * 2, 2, (Math.floor(t * 3) + hs) % 4 ? '#ffbc7e' : '#fff09a'); }
          if (th.sparkleFloor && hs % 9 === 0 && (Math.floor(t * 2) + hs) % 3) twinkle(g, sx, GY + 5 + (hs >> 3) % Math.max(1, H - GY - 6), '#fff3a0');
        }
        if (th.tuft && hs % 7 === 0) { px(g, sx, GY - 1, FP, 1, th.tuft); px(g, sx + FP * 2, GY - 1 + FP, FP, 1 - FP, th.tuft); }
        if (hs % 31 === 0) { const c = th.dots[(hs >> 5) % 2]; px(g, sx - FP, GY - 1.5, FP, FP, c); px(g, sx + FP, GY - 1.5, FP, FP, c); px(g, sx, GY - 1.5 - FP, FP, FP, c); px(g, sx, GY - 1.5 + FP, FP, FP, c); px(g, sx, GY - 1.5, FP, FP, '#fff3a0'); }
        if (V.rain && mod(wx, 37) < 7 && !s.after) { px(g, sx, GY, 1, FP * 2, ((wx + Math.floor(t * 5)) % 5) ? '#c8deff' : '#ffffff'); }
        if (wx === 0) px(g, sx, GY, 1, 4, '#ffffff');
        if (wx === C.LEN || wx === C.LEN + 1) for (let y = 0; y < 4; y++) px(g, sx, GY + y, 1, 1, ((wx + y) & 1) ? INK : '#ffffff');
      }
    }
  }
  function drawFence(V) {
    const { g, W, GY, C, camX } = V;
    for (const s of C.segs) {
      if (s.type !== 'run' || hash(s.x0 + 5) % 3 === 0 || s.x1 < camX || s.x0 > camX + W) continue;
      const th = TH[themeAt(C, s.x0 + 1)]; if (!th.fence) continue;
      const a = s.x0 + 6, b = s.x1 - 6;
      for (let wx = Math.max(a, camX - 2); wx <= Math.min(b, camX + W + 2); wx++) {
        const sx = wx - camX, m = mod(wx - a, 4), post = mod(wx - a, 12) === 0;
        if (th.fence === 'wood') { // a little white picket fence
          if (m === 0) { px(g, sx - FP, GY - 6, 1 + FP * 2, 6, '#a8acc4'); px(g, sx, GY - 6 + FP, 1, 6 - FP, '#ffffff'); px(g, sx, GY - 6.5, 1, FP, '#a8acc4'); }
          else { px(g, sx, GY - 4.5, 1, FP * 2, '#a8acc4'); px(g, sx, GY - 4.5 + FP, 1, FP, '#f2f4fa'); px(g, sx, GY - 2.5, 1, FP * 2, '#a8acc4'); px(g, sx, GY - 2.5 + FP, 1, FP, '#f2f4fa'); }
        } else if (th.fence === 'rope') { if (post) { px(g, sx - FP, GY - 5.5, 1 + FP * 2, 5.5, INK); px(g, sx, GY - 5.5 + FP, 1, 5.5 - FP, '#e6c49e'); } else { const sg = Math.sin(mod(wx - a, 12) / 12 * Math.PI) * 1.5; px(g, sx, Math.round((GY - 5 + sg) / FP) * FP, 1, FP * 2, '#f6dcb4'); } }
        else if (th.fence === 'cane') { if (post) { px(g, sx - FP, GY - 7.5, 1 + FP * 2, 7.5, INK); for (let y = 0; y < 7; y++) px(g, sx, GY - 1 - y, 1, 1, y % 2 ? '#ff9fb4' : '#ffffff'); px(g, sx + 1, GY - 7, 1, 1, '#ff9fb4'); } else if (mod(wx - a, 12) < 11) px(g, sx, GY - 4, 1, FP * 2, '#ffc6d8'); }
      }
    }
  }
  function drawProps(V, glow) {
    const { g, W, GY, C, camX, t } = V;
    if (!glow) drawFence(V);
    for (const d of C.decor) {
      if (d.glow !== glow) continue;
      const sx = d.x - camX; if (sx < -30 || sx > W + 30) continue;
      const spr = propSprite(d.kind, d.th); if (!spr || PX.artH(spr) > GY + 1) continue;
      PX.blit(g, spr, sx, GY + 1, d.flip);
    }
    if (glow) return;
    for (let i = 0; i < C.zones.length - 1; i++) { const sx = C.zones[i].x1 - camX, post = rprop('zonepost'); if (post && sx > -12 && sx < W + 12 && PX.artH(post) <= GY + 1) PX.blit(g, post, sx, GY + 1); } // signposts between gardens
    const gate = rprop('gate'), arch = rprop('arch');
    if (gate && PX.artH(gate) <= GY + 1) { const sx = -21 - camX; if (sx > -30 && sx < W + 10) g.drawImage(gate, sx, GY + 1 - PX.artH(gate), PX.artW(gate), PX.artH(gate)); }
    if (arch && PX.artH(arch) <= GY + 1) { const sx = C.LEN - camX; if (sx > -30 && sx < W + 10) g.drawImage(arch, sx - 3, GY + 1 - PX.artH(arch), PX.artW(arch), PX.artH(arch)); }
    else { const fx = C.LEN + 3 - camX; if (fx > -14 && fx < W + 14) PX.blit(g, icon('bigflag'), fx, GY + 1, false, 2, 26); }
    // the cheering crowd at the start and the finish
    if (C.crowd) for (const c of C.crowd) {
      const sx = c.x - camX; if (sx < -20 || sx > W + 20) continue;
      const spr = safeCritter(c.kind); if (!spr || PX.artH(spr) > GY) continue;
      const hop = V.cheer && c.x > 0 ? Math.round(Math.abs(Math.sin(t * 7 + c.ph)) * 3) : (Math.sin(t * 2 + c.ph) > 0.93 ? 1 : 0);
      PX.blit(g, spr, sx, GY + 1 - hop, c.flip);
    }
  }
  // the Grand Prix zone edge on screen (screen x, theme left, theme right), or null
  function zoneSeam(C, camX, W) { const z = C.zones; for (let i = 0; i < z.length - 1; i++) { const x = z[i].x1 - camX; if (x > 0 && x < W) return { x, a: z[i].th, b: z[i + 1].th }; } return null; }
  function drawWorld(V) {
    const { g, W, H, C, camX } = V;
    g.clearRect(0, 0, W, H);
    const n = V.night, starA = clamp((n - 0.3) / 0.5, 0, 1);
    // the sky: one theme, or a clean hard seam where the Grand Prix moves into the next garden (a signpost stands on it)
    const sm = zoneSeam(C, camX, W);
    if (sm) {
      g.save(); g.beginPath(); g.rect(0, 0, sm.x, H); g.clip(); drawSky(V, TH[sm.a], sm.a, starA); g.restore();
      g.save(); g.beginPath(); g.rect(sm.x, 0, W - sm.x, H); g.clip(); drawSky(V, TH[sm.b], sm.b, starA); g.restore();
    } else { const th = themeAt(C, camX + W / 2); drawSky(V, TH[th], th, starA); }
    if (V.rain) { g.globalCompositeOperation = 'multiply'; g.globalAlpha = 0.25; px(g, 0, 0, W, V.GY + 2, '#a8b4dc'); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; }
    drawGround(V);
    drawProps(V, false);
    const dark = TH[themeAt(C, camX + (V.focus == null ? W / 2 : V.focus))].dark;
    const amt = n * (dark ? 0.2 : 0.42); // night: a soft periwinkle tint
    if (amt > 0.01) { g.globalCompositeOperation = 'multiply'; g.globalAlpha = amt; px(g, 0, 0, W, H, '#7a84d0'); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; }
    V.tint = amt;
    drawProps(V, true);
  }
  // the water in front of the racers: see-through near the surface (the swimmer shows through), with drifting sparkles
  function drawWaterFront(V) {
    const { g, W, H, GY, C, camX, t } = V;
    g.clearRect(0, 0, W, H);
    for (let sx = 0; sx < W; sx++) {
      const wx = camX + sx, s = segAtC(C, wx); if (s.type !== 'swim') continue;
      const w = TH[themeAt(C, wx)].water, crest = Math.sin(wx * 0.4 - t * 4) > 0.75;
      px(g, sx, GY + 1, 1, FP, '#ffffff'); px(g, sx, GY + 1 + FP, 1, FP, w[0]);
      if (crest) px(g, sx, GY + FP, 1, FP, w[0]);
      g.globalAlpha = 0.55; px(g, sx, GY + 2, 1, 2, w[1]);
      g.globalAlpha = 0.85; px(g, sx, GY + 4, 1, Math.max(0, H - GY - 6), w[1]);
      g.globalAlpha = 1; px(g, sx, H - 2, 1, 2, w[2]);
      if (hash(wx * 3 + Math.floor(t * 4)) % 23 === 0) twinkle(g, sx, GY + 3 + hash(wx) % Math.max(1, H - GY - 5), w[3] === '#ffffff' ? '#e8faff' : w[3]);
      const bh = hash(wx * 5 + 3); if (bh % 29 === 0) { const by = H - 2 - mod(Math.floor(t * 9 + bh), Math.max(1, H - GY - 3)); if (by > GY + 2) disc(g, sx, by, 1, w[0]); }
      if (wx === s.x0) px(g, sx, GY, FP, H - GY, INK); if (wx === s.x1 - 1) px(g, sx + 1 - FP, GY, FP, H - GY, INK);
    }
    if (V.tint > 0.01) { g.globalCompositeOperation = 'source-atop'; g.globalAlpha = V.tint * 0.5; px(g, 0, 0, W, H, '#5a64b0'); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; }
  }

  // =====================================================================
  // Scene state
  // =====================================================================
  let root = null, hubEl = null, raceEl = null, stageEl = null, cv = null, ctx = null;
  let visible = false, race = null, hubDirty = true, partnerCv = null, partnerT = 0, lastNightBucket = -1, hubTab = 'races', hubClockT = 0, hubDay = '';
  const lo = document.createElement('canvas'), lx = lo.getContext('2d');
  const bgC = document.createElement('canvas'), bg = bgC.getContext('2d');
  const fgC = document.createElement('canvas'), fg = fgC.getContext('2d');
  const dkC = document.createElement('canvas'), dk = dkC.getContext('2d');
  const silC = document.createElement('canvas'), sil = silC.getContext('2d');
  let cssW = 0, cssH = 0, dpr = 1, DS = 3, PXS = 4, WW = 100, WH = 150, LH = 40, GY = 34, CLIMB_H = 10, PSX = 34, NL = 4;
  const $r = sel => root.querySelector(sel);

  function mount(el) {
    injectCSS();
    root = el;
    root.innerHTML = `<div class="r-root">
      <div class="r-hub"></div>
      <div class="r-race" hidden>
        <div class="r-hud">
          <div class="r-place">1<small>st</small></div>
          <div class="r-track" aria-hidden="true"><div class="r-rail"></div><div class="r-dots"></div><canvas class="px r-flag" width="10" height="12"></canvas></div>
          <button class="btn r-quit" aria-label="Leave race">✕</button>
          <div class="r-hrow"><span class="label">Stamina</span><div class="bar"><i class="r-stam"></i></div><span class="num r-time">0.0s</span></div>
        </div>
        <div class="r-stage">
          <canvas class="px r-cv" aria-label="Race track. Tap when the ring meets the circle."></canvas>
          <div class="hint r-hint" hidden>Tap anywhere when the ring meets the circle!</div>
          <div class="hint r-ihint" hidden>You got an item! Tap this button to use it.</div>
          <button class="btn primary r-skip" hidden>Skip to results</button>
          <button class="r-item" hidden aria-label="Use item"><canvas class="px"></canvas><span>Item</span></button>
          <div class="overlay r-ov r-results" hidden></div>
          <div class="overlay r-ov r-leave" hidden><div class="modal-wrap"><button class="m-x r-leave-x" type="button" aria-label="Keep racing">×</button><div class="card modal-card">
            <div class="eyebrow">Paused</div><h1>Leave this race?</h1>
            <p class="r-leave-p">You won't earn coins or XP for a race you leave.</p>
            <div class="r-btns"><button class="btn danger r-leave-yes">Leave</button><button class="btn go r-leave-no">Keep racing</button></div>
          </div></div></div>
          <div class="overlay r-ov r-pause" hidden><div class="card" role="button" tabindex="0" aria-label="Keep racing">
            <canvas class="px r-play"></canvas><div class="eyebrow">Paused</div><h1>Tap to keep racing</h1>
          </div></div>
        </div>
      </div></div>`;
    hubEl = $r('.r-hub'); raceEl = $r('.r-race'); stageEl = $r('.r-stage'); cv = $r('.r-cv'); ctx = cv.getContext('2d');
    paintTo($r('.r-flag'), icon('flag')); paintTo($r('.r-play'), icon('play'));
    stageEl.addEventListener('pointerdown', e => {
      if (e.target.closest('button, .r-ov')) return;
      e.preventDefault(); PX.Sound.unlock(); tap();
    });
    $r('.r-item').addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); PX.Sound.unlock(); useItem(); });
    $r('.r-skip').addEventListener('click', e => { e.stopPropagation(); skipToEnd(); });
    $r('.r-quit').addEventListener('click', () => {
      // once your plant has crossed the line the ✕ is hidden: the results (and prizes) are on their way
      if (!race || race.state === 'done' || race.shown || race.player.finished) return; PX.Sound.play('pop'); race.paused = true;
      $r('.r-leave-p').textContent = race.mode === 'trial' ? 'This run won’t count if you leave.' : 'You won’t earn coins or XP for a race you leave.';
      $r('.r-pause').hidden = true; $r('.r-leave').hidden = false;
    });
    $r('.r-leave-no').addEventListener('click', () => { PX.Sound.play('pop'); resume(); });
    $r('.r-leave-x').addEventListener('click', () => { PX.Sound.play('pop'); resume(); });
    $r('.r-leave-yes').addEventListener('click', () => { PX.Sound.play('pop'); $r('.r-leave').hidden = true; abortRace(); showHub(); hubMusic(); });
    $r('.r-pause').addEventListener('click', e => { e.stopPropagation(); PX.Sound.unlock(); resume(); });
    window.addEventListener('keydown', e => {
      if (!visible || !race) return;
      if (race.paused) { if (!$r('.r-pause').hidden && (e.code === 'Space' || e.code === 'Enter')) { e.preventDefault(); resume(); } return; }
      if (race.state !== 'run') return;
      if (e.code === 'Space' || e.code === 'Enter') { e.preventDefault(); tap(); }
      if (e.code === 'KeyX' || e.code === 'ArrowUp') { e.preventDefault(); useItem(); }
    });
    // the app went to the background (home button, lock, app switch): pause, and wait for a tap when it comes back
    const away = () => { if (visible && race && !race.paused && !race.player.finished && (race.state === 'run' || race.state === 'count')) pauseRace(); };
    document.addEventListener('visibilitychange', () => { if (document.hidden) away(); });
    window.addEventListener('pagehide', away);
    window.addEventListener('resize', () => { if (visible && race) resize(); if (visible && !race) hubDirty = true; });
    PS.on('sprout:update', () => { if (!race) hubDirty = true; });
    PS.on('reset', () => { hubDirty = true; });
    if (document.fonts && document.fonts.load) { document.fonts.load('400 20px "Luckiest Guy"').catch(() => {}); document.fonts.load('800 14px "Nunito"').catch(() => {}); }
  }

  function show(params) {
    visible = true; params = params || {};
    if (race) { abortRace(); }
    if (params.tab && ['races', 'wild', 'cup', 'trial'].includes(params.tab)) hubTab = params.tab;
    showHub();
    if (params.race) { const ri = ALL.findIndex(r => r.id === params.race); if (ri >= 0) startRace(ri, params.tier || 0); }
  }
  function hide() {
    visible = false;
    if (race) abortRace(); // left mid-race (e.g. another screen took over): a finished race still pays out
  }
  function frame(dt, t) {
    if (race) {
      if (!race.paused) {
        try { update(dt); race.errs = 0; } catch (e) { console.error('race update', e); if (++race.errs > 20) { bailOut(); return; } }
      }
      if (!race) return;
      // nothing moves while paused, and the results card covers the track: draw once instead of 60 times a second
      if (!(race.paused || race.shown) || race.redraw) { race.redraw = false; render(); }
      updateHud();
      return;
    }
    const nb = Math.round(nightAmt() * 8);
    if (nb !== lastNightBucket) { lastNightBucket = nb; hubDirty = true; }
    hubClockT -= dt;
    if (hubClockT <= 0) {
      hubClockT = 1;
      const dkey = dayKey(); if (dkey !== hubDay) { hubDay = dkey; hubDirty = true; }
      const nx = hubEl && hubEl.querySelector('.r-next'); if (nx) nx.textContent = `New cup in ${fmtWait(msToMidnight())}`;
    }
    if (hubDirty && !(PS.ui.sboxBusy && PS.ui.sboxBusy(hubEl && hubEl.querySelector('.r-box')))) renderHub();
    partnerT += dt;
    if (partnerCv && partnerT > 0.18) { partnerT = 0; drawPartner(t); }
  }

  // =====================================================================
  // HUB
  // =====================================================================
  function lockReason(R, tier) {
    if (tier > 0 && !prog(R, tier - 1).wins) return `Win ${D.RACE_TIERS[tier - 1].name} to unlock`;
    if (R.unlock) { const U = byId(R.unlock.race); return `Win ${U ? U.name : R.unlock.race} ${D.RACE_TIERS[R.unlock.tier].name} to unlock`; }
    return 'Locked';
  }
  // The match label compares projected finish times on this exact course: your racer vs the fastest real rival, both with
  // no cheering and no items (stamina counts). MATCH_Q[tier] = the time ratios (you / fastest rival) up to which the label
  // says Easy / Good match / Tough. From sims: at "Good match" an average tapper wins about half the races or more
  // (cheering well is worth more than the rivals' cheering, most of all in Beginner).
  const MATCH_Q = [[1.04, 1.11, 1.19], [0.96, 1.03, 1.11], [0.915, 0.975, 1.05]];
  function soloTime(C, rating, stamR) {
    const r = makeRacer({ name: '', rating, stamR }), c = { C, t: 0, rng: Math.random, fx: false }, dt = 0.1; // coarse is plenty for a label
    while (!r.finished && c.t < 300) { c.t += dt; stepRacer(r, dt, c); }
    return r.finished ? r.time : 300;
  }
  const rivalBest = {}; let soloMemo = {}, soloN = 0;
  function matchQ(s, ri, tier) {
    const key = ri + '-' + tier, C = courseOf(ri, tier);
    if (rivalBest[key] == null) rivalBest[key] = Math.min(...rivalRacers(ALL[ri], tier).map(r => soloTime(C, r.rating, (r.stamMax - T.stamBase) / T.stamPer)));
    const pr = playerRatings(s), st = ST.staminaRating(s), pk = key + ':' + SEGS.map(k => pr[k].toFixed(2)).join() + ',' + st.toFixed(2);
    if (soloMemo[pk] == null) { if (++soloN > 600) { soloMemo = {}; soloN = 1; } soloMemo[pk] = soloTime(C, pr, st); }
    return soloMemo[pk] / rivalBest[key];
  }
  function matchOf(s, ri, tier) {
    if (!s) return null;
    const q = matchQ(s, ri, tier), M = MATCH_Q[tier] || MATCH_Q[2];
    if (q <= M[0]) return { t: 'Easy', c: '#2b8243' };
    if (q <= M[1]) return { t: 'Good match', c: '#5a9a2e' };
    if (q <= M[2]) return { t: 'Tough', c: '#c7861c' };
    return { t: 'Very tough', c: '#c0443f' };
  }
  function showHub() {
    raceEl.hidden = true; hubEl.hidden = false;
    hubDirty = true; renderHub();
  }
  function medalCount() { const x = xsRead(); if (!x || !x.trials) return 0; return Object.values(x.trials).reduce((a, tr) => a + (tr && tr.m ? Math.min(3, tr.m) : 0), 0); }
  function renderHub() {
    hubDirty = false;
    const s = ST.active();
    const ob = hubEl.querySelector('.r-box'), scroll = ob ? ob.scrollTop : 0; // (the box is rebuilt: keep where it was scrolled to)
    const openSeries = sideOrder().filter(ri => unlocked(ALL[ri], 0)).length, friends = WILD_RACES.reduce((a, R) => a + [0, 1, 2].filter(t => prog(R, t).wins).length, 0);
    const cup = cupToday();
    const HEAD = { races: [ST.raceVs() === 'plants' ? 'Plant race series' : 'Zombie race series', 'Races', `${openSeries} of ${sideOrder().length} open`],
      cup: ['Special race', 'Daily Cup', 'New every day'], trial: ['Beat your best', 'Time Trial', `${medalCount()} medal${medalCount() === 1 ? '' : 's'}`] }[hubTab] || [];
    let html = `<div class="r-pin"><div class="r-head"><div><div class="label">${HEAD[0]}</div><h2 class="px-title">${HEAD[1]}</h2></div><span class="r-count">${HEAD[2]}</span></div>`;
    if (!s) {
      html += `<div class="card r-empty"><canvas class="px r-ecv"></canvas><h3>No racer yet</h3><p>Plant your first seed packet in the Garden, then come back to race the zombies.</p><button class="btn go wide r-togarden">Go to the Garden</button></div>`;
      hubEl.innerHTML = html + '</div>';
      const ec = hubEl.querySelector('.r-ecv'), egg = safeItem('egg', 'normal'); if (egg) paintTo(ec, egg, 22, 28);
      hubEl.querySelector('.r-togarden').onclick = () => { PX.Sound.play('pop'); PS.ui.go('garden'); };
      partnerCv = null; return;
    }
    html += `<div class="r-tabs" role="tablist">${[['races', 'Races'], ['cup', 'Daily Cup'], ['trial', 'Time Trial']].map(([id, label]) =>
      `<button class="r-tab" role="tab" data-tab="${id}" aria-selected="${hubTab === id}"><canvas class="px" data-tic="tab-${id}"></canvas>${label}${id === 'cup' && cup.best == null ? '<i class="r-badge"></i>' : ''}</button>`).join('')}</div>
      <div class="r-vsbar"><span>Race against:</span><button class="r-vsb" data-vs="zombies" aria-pressed="${ST.raceVs() === 'zombies'}"><canvas class="px" data-vsic="zombie"></canvas>Zombies</button><button class="r-vsb" data-vs="plants" aria-pressed="${ST.raceVs() === 'plants'}"><canvas class="px" data-vsic="plant"></canvas>Plants</button></div></div>
      <div class="sbox-frame sb-fill"><div class="sbox r-box">`;
    const fi = ST.formInfo(s), rate = k => (k === 'stamina' ? ST.staminaRating(s) : ST.raceRating(s, k)).toFixed(1);
    html += `<div class="panel r-partner"><canvas class="px r-pc" width="40" height="40"></canvas><div>
      <div class="r-ptop"><div><div class="label">Your racer</div><div class="r-pname">${esc(s.name)}</div></div><button class="btn r-change">Change</button></div>
      <div class="r-pform">${esc(fi.name)} · Lv ${ST.totalLevels(s)}</div>
      <div class="r-rates">${['run', 'swim', 'climb', 'fly', 'stamina'].map(k => `<div class="r-rate"><small>${k === 'stamina' ? 'Stam' : k === 'fly' ? 'Fly' : SEG_META[k].label}</small><b>${rate(k)}</b></div>`).join('')}</div>
    </div></div>`;
    if (hubTab === 'cup') html += cupHtml(s, cup);
    else if (hubTab === 'trial') html += trialHtml(s);
    else html += racesHtml(s);
    hubEl.innerHTML = html + '</div></div>';
    partnerCv = hubEl.querySelector('.r-pc'); drawPartner(0);
    hubEl.querySelector('.r-change').onclick = () => {
      PX.Sound.play('pop');
      PS.ui.pickSprout({ title: "Who's racing?", eyebrow: 'Races', extra: x => `Run ${ST.raceRating(x, 'run').toFixed(1)} · Swim ${ST.raceRating(x, 'swim').toFixed(1)} · Climb ${ST.raceRating(x, 'climb').toFixed(1)} · Fly ${ST.raceRating(x, 'fly').toFixed(1)}`,
        onPick: x => { ST.setActive(x.id); hubDirty = true; } });
    };
    hubEl.querySelectorAll('.r-vsb').forEach(b => { b.onclick = () => { if (ST.raceVs() === b.dataset.vs) return; PX.Sound.play('tick'); ST.setRaceVs(b.dataset.vs); PS.ui.toast(b.dataset.vs === 'plants' ? 'Racing other gardeners\' plants!' : 'Racing the zombies!', 1800); hubDirty = true; renderHub(); }; });
    hubEl.querySelectorAll('canvas[data-vsic]').forEach(c => paintTo(c, PX.sprig(c.dataset.vsic === 'zombie' ? { zombie: 'conehead' } : { species: 'peashooter', stage: 0 }, {}), 16, 16));
    hubEl.querySelectorAll('.r-tab').forEach(b => { b.onclick = () => { if (hubTab === b.dataset.tab) return; PX.Sound.play('tick'); hubTab = b.dataset.tab; const bx = hubEl.querySelector('.r-box'); if (bx) bx.scrollTop = 0; hubDirty = true; renderHub(); }; });
    hubEl.querySelectorAll('canvas[data-tic]').forEach(c => { if (c.dataset.tic === 'tab-wild') { const cr = safeCritter('hare'); c.classList.add('r-tabcrit'); if (cr) paintTo(c, cr, 18, 18); } else paintTo(c, icon(c.dataset.tic), 16, 16); });
    hubEl.querySelectorAll('canvas[data-critter]').forEach(c => { const cr = safeCritter(c.dataset.critter); if (cr) paintTo(c, cr, 18, 18); });
    hubEl.querySelectorAll('canvas[data-ic]').forEach(c => paintTo(c, icon(c.dataset.ic), 11, 11));
    hubEl.querySelectorAll('.r-prize canvas, .r-cupprize canvas.r-cc').forEach(c => paintTo(c, icon('coin'), 9, 9));
    hubEl.querySelectorAll('.r-eggic canvas[data-area]').forEach(c => { const e = safeItem('egg', c.dataset.area); if (e) paintTo(c, e, 22, 28); });
    hubEl.querySelectorAll('.r-eggic canvas[data-map]').forEach(c => { try { const m = PS.ui.mapPreview(c.dataset.map); c.width = 60; c.height = 32; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(m, 0, 0, 60, 32); } catch (e) { /* optional */ } });
    hubEl.querySelectorAll('.r-eggic canvas[data-plant]').forEach(c => { const e = safeItem('plant', c.dataset.plant); if (e) { paintTo(c, e, 16, 16); if (!ST.isUnlocked(c.dataset.plant)) c.style.filter = 'brightness(0) opacity(.35)'; } });
    hubEl.querySelectorAll('.r-lock canvas').forEach(c => paintTo(c, icon('lock'), 11, 12));
    hubEl.querySelectorAll('canvas[data-medal]').forEach(c => paintTo(c, icon('medal' + c.dataset.medal), 11, 14));
    hubEl.querySelectorAll('canvas[data-mod]').forEach(c => { const big = c.dataset.mod === 'giant'; if (big) c.classList.add('r-giantic'); paintTo(c, icon('mod-' + c.dataset.mod), big ? 32 : 16, big ? 32 : 16); });
    hubEl.querySelectorAll('.r-tier').forEach(b => {
      b.onclick = () => {
        const ri = +b.dataset.ri, ti = +b.dataset.tier; if (!unlocked(ALL[ri], ti)) return;
        PX.Sound.unlock(); PX.Sound.play('go');
        if (b.dataset.mode === 'trial') startTrial(ri, ti); else startRace(ri, ti);
      };
    });
    const cg = hubEl.querySelector('.r-cupgo'); if (cg) cg.onclick = () => { PX.Sound.unlock(); PX.Sound.play('go'); startCup(); };
    // banners after layout so we know the width (integer 3x scale)
    const bw = hubEl.querySelector('.r-banner');
    const w = bw ? bw.clientWidth : 320;
    hubEl.querySelectorAll('.r-bn').forEach(c => drawBanner(c, +c.dataset.ri, w, { H: +c.dataset.h || 30 }));
    const cb = hubEl.querySelector('.r-cupbn');
    if (cb) { const info = dailyInfo(); drawBanner(cb, info.ri, w, { C: cupCourse(info, s), mod: info.mod, look: ST.lookOf(s) }); }
    // back to where the list was scrolled, now that the banners have their height (set earlier, a list that was still short
    // cut the position down: a rebuild jumped the list up by a row)
    const nb = hubEl.querySelector('.r-box'); if (nb && scroll) nb.scrollTop = scroll;
  }
  function seriesSub(R) {
    const order = SEGS.filter(k => R.mix[k]).sort((a, b) => R.mix[b] - R.mix[a]);
    const area = D.AREAS[R.area] ? D.AREAS[R.area].baseName : '';
    return `${R.id === 'grand' ? 'Every area in one long course.' : R.extra ? esc(R.blurb) : esc(area) + ' course'} · ${order.map(k => SEG_META[k].label.toLowerCase()).join(', ')}`;
  }
  function wildNew() { return WILD_RACES.some(R => unlocked(R, 0) && !prog(R, 0).runs); }
  // a locked series shows as a small card: banner, name and what to win
  function lockedCard(ri, label) {
    const R = ALL[ri];
    return `<div class="panel r-card locked" data-ri="${ri}"><div class="r-banner"><canvas class="px r-bn" data-ri="${ri}" data-h="20"></canvas><span class="r-num">${label}</span><span class="r-lockchip">Locked</span></div>
      <div class="r-body"><div class="r-title">${esc(R.name)}</div><div class="r-tsub r-lockline"><span class="r-lock"><canvas class="px"></canvas></span>${esc(lockReason(R, 0))}</div></div></div>`;
  }
  function wildHtml(s) {
    let html = '<p class="r-intro">Race the animals that live on each island! Win a race the first time and the fastest animal becomes your friend.</p><div class="r-list">';
    WILD_ORDER.forEach(ri => {
      const R = ALL[ri]; if (!unlocked(R, 0)) { html += lockedCard(ri, D.AREAS[R.area] ? D.AREAS[R.area].baseName : 'Wild'); return; }
      const fresh = !prog(R, 0).runs;
      html += `<div class="panel r-card" data-ri="${ri}">
        <div class="r-banner"><canvas class="px r-bn" data-ri="${ri}"></canvas><span class="r-num">${esc(D.AREAS[R.area] ? D.AREAS[R.area].baseName : '')}</span>${fresh ? '<span class="r-new">New!</span>' : ''}</div>
        <div class="r-body"><div class="r-title">${esc(R.name)}</div><div class="r-sub">${seriesSub(R)}</div>
        <div class="r-tiers">${D.RACE_TIERS.map((Tr, ti) => tierRow(s, ri, ti)).join('')}</div></div></div>`;
    });
    return html + '</div><p class="r-foot">Each island opens after you win its first race series. Full pouch? The animal leaves you coins instead.</p>';
  }
  function racesHtml(s) {
    const plants = ST.raceVs() === 'plants';
    let html = plants ? '<p class="r-intro">Race other gardeners\' plants on their own courses! Every win gives a prize: fruit (Beginner), an element core (Pro) or a fusion item (Master). First wins unlock new plants.</p><div class="r-list">' : '<div class="r-list">';
    sideOrder().forEach((ri, n) => {
      const R = ALL[ri], open = unlocked(R, 0);
      if (!open) { html += lockedCard(ri, `Series ${n + 1}`); return; }
      const W = SEGS.reduce((a, k) => a + (R.mix[k] || 0), 0);
      const order = SEGS.filter(k => R.mix[k]).sort((a, b) => R.mix[b] - R.mix[a]);
      const fresh = open && R.extra && !prog(R, 0).runs;
      html += `<div class="panel r-card${open ? '' : ' locked'}" data-ri="${ri}">
        <div class="r-banner"><canvas class="px r-bn" data-ri="${ri}"></canvas><span class="r-num">Series ${n + 1}</span>${open ? (fresh ? '<span class="r-new">New!</span>' : '') : `<span class="r-lockchip">Locked</span>`}</div>
        <div class="r-body">
          <div class="r-title">${esc(R.name)}</div>
          <div class="r-sub">${seriesSub(R)}</div>
          <div class="r-mixbar">${SEGS.filter(k => R.mix[k]).map(k => `<i style="width:${(R.mix[k] / W * 100).toFixed(1)}%;background:${SEG_META[k].color}"></i>`).join('')}</div>
          <div class="r-mix">${order.map(k => `<span class="r-mixchip"><canvas class="px" data-ic="${k}"></canvas>${SEG_META[k].label} <span>${Math.round(R.mix[k] / W * 100)}%</span></span>`).join('')}</div>
          <div class="r-tiers">${D.RACE_TIERS.map((Tr, ti) => tierRow(s, ri, ti)).join('')}</div>
        </div></div>`;
    });
    return html + `</div><p class="r-foot">${plants ? 'Switch to Zombies above for the zombie races, with their own courses and prizes.' : 'Win a tier the first time to unlock a new plant, a garden map or a seed packet. Each first win also opens the next tier. Switch to Plants above for the plant races!'} Grab item boxes on the track!</p>`;
  }
  function tierRow(s, ri, ti) {
    const R = ALL[ri], Tr = D.RACE_TIERS[ti], open = unlocked(R, ti), p = prog(R, ti);
    const fp = firstPrize(R, ti), eName = prizeName(R, ti), newPlant = fp.plant && !ST.isUnlocked(fp.plant);
    const m = open ? matchOf(s, ri, ti) : null;
    let sub;
    if (!open) sub = esc(lockReason(R, ti));
    else if (!p.runs) sub = p.wins ? '' : `First win: <b>${eName}!</b>`;
    else sub = `Best <b>${p.best ? p.best.toFixed(1) + 's' : '—'}</b> · ${p.wins} win${p.wins === 1 ? '' : 's'}${p.wins ? '' : ` · First win: <b>${eName}!</b>`}`;
    const right = open
      ? `${!p.wins ? (fp.plant ? `<span class="r-eggic${newPlant ? ' r-newplant' : ''}" title="First win: ${esc(eName)}"><canvas class="px" data-plant="${fp.plant}"></canvas></span>` : fp.map ? `<span class="r-eggic" title="First win: ${esc(eName)}"><canvas class="px r-mapic" data-map="${fp.map}"></canvas></span>` : `<span class="r-eggic" title="First win: ${esc(eName)}"><canvas class="px" data-area="${fp.seed}"></canvas></span>`) : ''}<span class="r-go">Race</span>`
      : `<span class="r-lock"><canvas class="px"></canvas></span>`;
    return `<button class="r-tier" data-ri="${ri}" data-tier="${ti}" ${open ? '' : 'disabled'} aria-label="${esc(R.name + ' ' + Tr.name)}${open ? '' : ' (locked)'}">
      <span><span class="r-tname">${Tr.name}${m ? `<span class="r-match" style="background:${m.c}">${m.t}</span>` : ''}</span>
      <span class="r-tsub">${sub}</span></span>
      <span class="r-right"><span class="r-prize"><canvas class="px"></canvas>${prizeOf(R, ti)}</span>${right}</span></button>`;
  }
  function cupHtml(s, cup) {
    const info = dailyInfo(), best = cup.best;
    const first = cupCoins(0), more = best != null && best > 0 ? cupCoins(0) - cupCoins(best) : 0;
    let prize;
    if (best == null) prize = `<div class="r-cupprize"><canvas class="px r-cc"></canvas>${first} coins for 1st <span class="r-eggic" title="Lucky seeds"><canvas class="px" data-area="${info.egg}"></canvas></span><small>+ lucky seed packet chance</small></div>`;
    else if (best === 0) prize = `<div class="r-done">You won today’s cup! Come back tomorrow.</div>`;
    else prize = `<div class="r-done">You came ${ORD[best]} today!</div><div class="r-cupprize"><canvas class="px r-cc"></canvas>Win for +${more} more coins</div>`;
    return `<div class="panel r-card">
      <div class="r-banner"><canvas class="px r-cupbn"></canvas><span class="r-num">Today</span></div>
      <div class="r-body">
        <div class="r-title">${esc(info.R.name)} Cup</div>
        <div class="r-sub">A new special race every day, just for fun and prizes.</div>
        <div class="r-twist"><canvas class="px" data-mod="${info.mod}"></canvas><div><b>${esc(info.M.name)}</b><span>${esc(info.M.desc)}</span></div></div>
        ${prize}
        <button class="btn go wide r-cupgo">${best == null ? 'Race!' : best === 0 ? 'Race for fun' : 'Try again'}</button>
        <p class="r-next">New cup in ${fmtWait(msToMidnight())}</p>
      </div></div>
      <p class="r-foot">Rivals in the Daily Cup are about as fast as your racer.</p>`;
  }
  function trialHtml(s) {
    let html = '<p class="r-intro">Race your ghost and win medals! Your best run comes back as a ghost to race.</p><div class="r-list">';
    let hidden = 0;
    sideOrder().forEach(ri => {
      const R = ALL[ri]; if (!unlocked(R, 0)) { hidden++; return; }
      html += `<div class="panel r-card" data-ri="${ri}">
        <div class="r-banner"><canvas class="px r-bn" data-ri="${ri}" data-h="22"></canvas></div>
        <div class="r-body"><div class="r-title">${esc(R.name)}</div>
        <div class="r-tiers">${D.RACE_TIERS.map((Tr, ti) => trialRow(ri, ti)).join('')}</div></div></div>`;
    });
    html += '</div>';
    if (hidden) html += `<p class="r-foot">Win races to open ${hidden} more course${hidden === 1 ? '' : 's'} here.</p>`;
    return html;
  }
  function trialRow(ri, ti) {
    const R = ALL[ri], Tr = D.RACE_TIERS[ti], open = unlocked(R, ti), tr = trialRec(R, ti);
    const m = Math.min(3, tr.m || 0);
    let sub;
    if (!open) sub = esc(lockReason(R, ti));
    else {
      const mt = medalTimes(ri, ti);
      sub = tr.best ? `Best <b>${tr.best.toFixed(1)}s</b>` : 'No ghost yet';
      sub += m < 3 ? ` · ${MEDAL_NAMES[m]}: <b>${mt[m].toFixed(1)}s</b>` : ' · <b>All medals!</b>';
    }
    const medals = open ? `<span class="r-medals">${[0, 1, 2].map(k => `<canvas class="px${k < m ? '' : ' off'}" data-medal="${k < m ? k : 'x'}"></canvas>`).join('')}</span><span class="r-go">Go</span>` : `<span class="r-lock"><canvas class="px"></canvas></span>`;
    return `<button class="r-tier" data-mode="trial" data-ri="${ri}" data-tier="${ti}" ${open ? '' : 'disabled'} aria-label="Time trial ${esc(R.name + ' ' + Tr.name)}${open ? '' : ' (locked)'}">
      <span><span class="r-tname">${Tr.name}</span><span class="r-tsub">${sub}</span></span>
      <span class="r-right">${medals}</span></button>`;
  }
  const bannerCourses = {};
  function drawBanner(c, ri, cssWidth, opt) {
    opt = opt || {};
    const S = 3, W = Math.max(40, Math.floor(cssWidth / S)), H = opt.H || 30, K = PX.SCENE_K;
    c.width = W * K; c.height = H * K; c.style.width = W * S + 'px'; c.style.height = H * S + 'px';
    const C = opt.C || bannerCourses[ri] || (bannerCourses[ri] = buildCourse(ri, 0));
    const R = ALL[ri], GYb = H - 8;
    // pick a window that shows a characteristic stretch of the course
    let camX = -10;
    if (R.id === 'grand' && !opt.C) camX = Math.round(C.zones[1].x0 - W / 2);
    else { const fav = SEGS.slice().sort((a, b) => (R.mix[b] || 0) - (R.mix[a] || 0)).find(k => k !== 'run'); const sg = C.segs.find(q => q.type === (fav === 'fly' ? 'climb' : fav)); if ((R.mix.run || 0) >= Math.max(R.mix.swim || 0, R.mix.climb || 0, R.mix.fly || 0)) camX = sg ? sg.x0 - Math.round(W * 0.55) : -10; else if (sg) camX = sg.x0 - Math.round(W * 0.3); }
    const g = c.getContext('2d'); g.setTransform(K, 0, 0, K, 0, 0); g.imageSmoothingEnabled = false;
    const md = opt.mod || '';
    const V = { g, W, H, GY: GYb, CH: 7, C, camX, t: 0, night: md === 'night' ? 1 : nightAmt(), rain: md === 'rain' };
    drawWorld(V);
    // a little plant running along (rival look), feet on the ground
    const look = opt.look || { species: ['peashooter', 'sunflower', 'chomper', 'snowpea', 'wallnut', 'cactus', 'starfruit', 'bonkchoy', 'jalapeno', 'iceberg', 'laserbean'][ri % 11], stage: 1 };
    const spr = sprig(look, { walk: true, frame: 1, mouth: 'grin', arms: md === 'lowgrav' ? 'up' : undefined }), sx = Math.round(W * 0.28), wx = camX + sx;
    const half = md !== 'giant', sw = half ? 16 : 32, sh = half ? Math.ceil(PX.artH(spr) / 2) : PX.artH(spr);
    const fy = V.GY + 1 - elevAt(V, wx) + Math.min(2, sinkAt(V, wx)) - (md === 'lowgrav' ? 7 : 0);
    if (R.wild && !opt.look) { // wild race banner: the Beginner animals running along
      wildAnimals(R, 0).forEach((id, i) => { const cr = safeCritter(id); if (!cr || PX.artH(cr) > V.GY) return; const x = sx - 4 + i * 26, wx2 = camX + x; PX.blit(g, cr, x, V.GY + 1 - elevAt(V, wx2) + Math.min(2, sinkAt(V, wx2))); });
    } else { g.imageSmoothingEnabled = half; g.drawImage(spr, sx - sw / 2, fy - sh + 1, sw, sh); g.imageSmoothingEnabled = false; } // (the half-size runner is shrunk smoothly so its thin outline survives)
    const f = document.createElement('canvas'); f.width = W * K; f.height = H * K; const fvg = f.getContext('2d'); fvg.setTransform(K, 0, 0, K, 0, 0);
    drawWaterFront({ g: fvg, W, H, GY: GYb, CH: 7, C, camX, t: 0, tint: V.tint });
    g.drawImage(f, 0, 0, W, H);
    if (md === 'rain') { g.fillStyle = '#d0e2ff'; for (let k = 0; k < 40; k++) { const h = hash(k + 3); g.fillRect(h % W, (h >> 8) % H, 1, 2); } }
    if (md === 'night') { dkC.width = W; dkC.height = H; dk.fillStyle = 'rgba(8,8,30,0.6)'; dk.fillRect(0, 0, W, H); dk.globalCompositeOperation = 'destination-out'; disc(dk, sx, fy - 8, 13, '#000'); dk.globalCompositeOperation = 'source-over'; g.drawImage(dkC, 0, 0); PX.blit(g, icon('lantern'), sx + 8, fy - 8); }
    if (md === 'lowgrav') { g.fillStyle = '#fff27a'; [[-6, 4], [7, 8], [-2, 11]].forEach(([dx, dy]) => g.fillRect(sx + dx, fy - dy, 1, 1)); }
    if (md === 'party') for (let k = 0; k < 3; k++) PX.blit(g, boxFrame(k * 0.3), sx + 18 + k * 16, V.GY - 3 - elevAt(V, camX + sx + 18 + k * 16));
    c.style.transform = md === 'reverse' ? 'scaleX(-1)' : '';
  }
  function drawPartner(t) {
    if (!partnerCv) return;
    const s = ST.active(); if (!s) return;
    const look = ST.lookOf(s), f = Math.floor(t * 5) % 2;
    const src = sprig(look, { walk: true, frame: f, mouth: 'grin' }), k = src.k || 1;
    const extra = Math.max(0, PX.artH(src) - 32), H = 40 + extra;
    if (partnerCv.height !== H * k || partnerCv.width !== 40 * k) { partnerCv.width = 40 * k; partnerCv.height = H * k; partnerCv.style.height = (80 + extra * 2) + 'px'; }
    const g = partnerCv.getContext('2d'); g.setTransform(k, 0, 0, k, 0, 0); g.imageSmoothingEnabled = false; g.clearRect(0, 0, 40, H);
    g.fillStyle = '#e3cf9d'; g.fillRect(10, H - 3, 20, 2);
    PX.blit(g, src, 20, H - 3 - f, false, sprigAX(), sprigAY());
  }

  // =====================================================================
  // RACE
  // =====================================================================
  // Canvas sizing for crisp pixels on any screen (iPhones are devicePixelRatio 3):
  //  - DS = device pixels per world pixel is always a whole number, so every art pixel is the same size;
  //  - the bitmap is exactly (CSS size x dpr) device pixels, so the browser never rescales it;
  //  - the canvas is nudged so it starts on a whole device pixel even when the HUD height is fractional.
  let sizeKey = '';
  function snapCanvas(r) {
    const fx = (r.left * dpr) % 1, fy = (r.top * dpr) % 1;
    cv.style.transform = fx > 0.001 || fy > 0.001 ? `translate(${-(fx / dpr).toFixed(4)}px,${-(fy / dpr).toFixed(4)}px)` : '';
  }
  function resize() {
    const r = stageEl.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    const nd = Math.min(3, window.devicePixelRatio || 1);
    const key = [r.width, r.height, nd, NL, race && race.mods.giant ? 1 : 0].join('|');
    if (key === sizeKey && cv.width) { snapCanvas(r); return true; } // nothing changed: don't wipe and reallocate canvases
    sizeKey = key; dpr = nd;
    cssW = r.width; cssH = r.height;
    PXS = clamp(Math.round(cssW / 125), 3, 5); // smaller pixels = more detail
    while (PXS > 3 && cssH / PXS / 4 < 42) PXS--;           // keep lanes tall enough on short screens
    DS = Math.max(PX.SCENE_K, Math.round(PXS * dpr / PX.SCENE_K) * PX.SCENE_K); // whole device px per fine px
    const devW = Math.ceil(cssW * dpr - 0.01), devH = Math.ceil(cssH * dpr - 0.01);
    WW = Math.ceil(devW / DS); WH = Math.ceil(devH / DS);
    LH = Math.floor(WH / NL);
    GY = NL >= 4 ? LH - 6 : LH - 6 - Math.round(Math.max(0, LH - 64) * 0.4); // tall lanes (time trial) show deeper ground
    CLIMB_H = clamp(LH - 32, 6, NL >= 4 ? 14 : 22); PSX = Math.round(WW * 0.3);
    if (race && race.mods.giant) { CLIMB_H = Math.min(CLIMB_H, LH < 60 ? 4 : 8); if (NL >= 4 && LH < 60) GY = LH - 3; } // short screens: giants need every row
    lo.width = WW * PX.SCENE_K; lo.height = WH * PX.SCENE_K; dkC.width = WW; dkC.height = LH; // lo: SCENE_K px per world px
    bgC.width = fgC.width = WW * PX.SCENE_K; bgC.height = fgC.height = LH * PX.SCENE_K; // the world layers too (fine outlines and sparkles)
    for (const c of [bg, fg]) { c.setTransform(PX.SCENE_K, 0, 0, PX.SCENE_K, 0, 0); c.imageSmoothingEnabled = false; }
    cv.width = devW; cv.height = devH;
    cv.style.width = (devW / dpr) + 'px'; cv.style.height = (devH / dpr) + 'px';
    snapCanvas(r);
    if (V) { V.GY = GY; V.CH = CLIMB_H; V.W = WW; V.H = LH; }
    if (race) race.redraw = true; // the canvases were cleared: draw again even while paused
    return true;
  }
  let V = null; // world view for the race

  function startRace(ri, tier) {
    const s = ST.active();
    if (!s) { PS.ui.toast('Hatch a plant first'); return; }
    const R = ALL[ri];
    if (!R || !unlocked(R, tier)) return;
    const C = buildCourse(ri, tier);
    const pl = makeRacer({ name: s.name, look: ST.lookOf(s), rating: playerRatings(s), stamR: ST.staminaRating(s), isPlayer: true });
    const rv = rivalRacers(R, tier);
    begin({ mode: 'race', ri, tier, R, C, s, pl, lanes: [rv[0], pl, rv[1], rv[2]], title: R.name, sub: D.RACE_TIERS[tier].name, items: true });
  }
  function startTrial(ri, tier) {
    const s = ST.active();
    if (!s) { PS.ui.toast('Hatch a plant first'); return; }
    const R = ALL[ri];
    if (!R || !unlocked(R, tier)) return;
    const C = buildCourse(ri, tier);
    const pl = makeRacer({ name: s.name, look: ST.lookOf(s), rating: playerRatings(s), stamR: ST.staminaRating(s), isPlayer: true });
    const tr = trialRec(R, tier), ok = tr.best && Array.isArray(tr.g) && tr.g.length > 2;
    const gs = ok && tr.sid ? ST.get(tr.sid) : null;
    const gh = makeRacer({ name: 'Ghost', look: gs ? ST.lookOf(gs) : ST.lookOf(s), rating: playerRatings(s), stamR: 1 });
    gh.isGhost = true; gh.none = !ok; gh.color = '#cbdbfc';
    begin({ mode: 'trial', ri, tier, R, C, s, pl, lanes: [gh, pl], ghost: gh, ghostData: ok ? tr : null, title: 'Time Trial', sub: R.name + ' · ' + D.RACE_TIERS[tier].name, items: false });
  }
  function startCup() {
    const s = ST.active();
    if (!s) { PS.ui.toast('Hatch a plant first'); return; }
    const info = dailyInfo(), C = cupCourse(info, s);
    const pl = makeRacer({ name: s.name, look: ST.lookOf(s), rating: playerRatings(s), stamR: ST.staminaRating(s), isPlayer: true });
    const rv = cupRivals(info, s);
    begin({ mode: 'cup', ri: info.ri, tier: 0, R: info.R, C, s, pl, lanes: [rv[0], pl, rv[1], rv[2]], title: 'Daily Cup', sub: info.M.name, items: true, mods: C.mods, info });
  }
  function begin(o) {
    o.pl.nextBoost = T.ring.first;
    o.lanes.forEach((r, i) => { r.lane = i; r.x = 0; });
    NL = o.lanes.length;
    const unlockedBefore = allUnlocked();
    race = { mode: o.mode, ri: o.ri, tier: o.tier, R: o.R, Tr: D.RACE_TIERS[o.tier], C: o.C, sprout: o.s, lanes: o.lanes, racers: o.lanes.filter(r => !r.isGhost), player: o.pl, t: 0,
      state: 'count', countT: 3.6, ring: null, ringsSeen: 0, pops: [], parts: [], finishT: 0, doneT: 0, shown: false, goFlash: 0, pflash: 0,
      paused: false, settled: false, summary: null, unlockedBefore, lastSeg: 'run', errs: 0, redraw: true, streak: 0, freezeT: 0, stamp: null, goBanner: false, fast: false,
      title: o.title, sub: o.sub, items: !!o.items, mods: o.mods || {}, info: o.info || null, honey: [], ghost: o.ghost || null, ghostData: o.ghostData || null, rec: [], mirror: !!(o.mods && o.mods.reverse), itemKey: '' };
    try {
      PS.ui.hold(true); PS.ui.chrome(false);
      hubEl.hidden = true; raceEl.hidden = false;
      $r('.r-results').hidden = true; $r('.r-leave').hidden = true; $r('.r-pause').hidden = true; $r('.r-skip').hidden = true; $r('.r-hint').hidden = true; $r('.r-ihint').hidden = true;
      $r('.r-item').hidden = !race.items;
      stageEl.classList.toggle('mirror', race.mirror);
      $r('.r-quit').style.visibility = '';
      V = null; sizeKey = '';
      resize();
      V = { g: bg, W: WW, H: LH, GY, CH: CLIMB_H, C: race.C, camX: 0, t: 0, night: race.mods.night ? 1 : nightAmt(), focus: PSX };
      buildHud();
      music('race');
      // zombie rivals count as "seen" in the Almanac
      for (const r of race.racers) if (r.look && r.look.zombie) { try { if (PS.state.seeZombie) PS.state.seeZombie(r.look.zombie); } catch (e) { /* optional */ } }
    } catch (e) { console.error('race start', e); endRaceUI(); showHub(); PS.ui.toast('Oops! That race could not start.'); }
  }
  function allUnlocked() { const o = {}; ALL.forEach(R => D.RACE_TIERS.forEach((Tr, ti) => { o[R.id + '-' + ti] = unlocked(R, ti); })); return o; }
  // Parent tools: open every tier of every series (the 5 originals, the extra series and the Wild races) by marking Beginner
  // and Pro as won (runs and wins at least 1) in the same save fields a real win writes. Best times are kept and Master is
  // left unwon, so its first-win egg / animal friend can still be earned. Returns how many tiers were newly opened.
  function unlockAll() {
    const X = xs(), races = PS.S.progress.races || (PS.S.progress.races = {}), before = allUnlocked();
    for (const R of ALL) for (let tier = 0; tier < 2; tier++) {
      const k = R.id + '-' + tier, box = R.extra ? X.series : races, p = Object.assign(blankProg(), box[k]);
      box[k] = Object.assign(p, { runs: Math.max(1, +p.runs || 0), wins: Math.max(1, +p.wins || 0) });
    }
    const after = allUnlocked(); hubDirty = true; PS.save();
    return Object.keys(after).filter(k => after[k] && !before[k]).length;
  }
  // leaving: a race that's already decided (your plant crossed the line, or you skipped to the results) still pays out
  function abortRace() {
    if (race && !race.settled && (race.player.finished || race.state === 'done')) { try { settle(); } catch (e) { console.error(e); } }
    endRaceUI();
  }
  function endRaceUI() {
    race = null; V = null; NL = 4;
    if (raceEl) { raceEl.hidden = true; $r('.r-results').hidden = true; $r('.r-leave').hidden = true; $r('.r-pause').hidden = true; $r('.r-ihint').hidden = true; }
    PS.ui.chrome(true); PS.ui.hold(false);
  }
  // never leave a kid stuck (e.g. the results card failed to build): keep what was earned and go back to the races
  function bailOut() {
    const r = race; if (!r) return;
    try { if (!r.settled && (r.player.finished || r.state === 'done')) settle(); } catch (e) { console.error(e); }
    endRaceUI(); try { showHub(); } catch (e) { console.error(e); } hubMusic();
    PS.ui.toast(!r.settled ? 'Race stopped.' : r.mode !== 'trial' && r.place === 0 ? 'You won! Your prizes are saved.' : 'Race over! Your prizes are saved.');
  }
  // the app went to the background: stop everything until the kid taps "keep racing"
  function pauseRace() {
    race.paused = true; race.ring = null; race.redraw = true;
    $r('.r-leave').hidden = true; $r('.r-pause').hidden = false; $r('.r-ihint').hidden = true;
  }
  function resume() {
    if (!race) return;
    $r('.r-pause').hidden = true; $r('.r-leave').hidden = true;
    race.paused = false; race.ring = null; // never drop back into a half-closed ring: the next one starts fresh a moment later
    const p = race.player;
    if (race.state === 'run' && !p.finished) { p.nextBoost = Math.max(p.nextBoost, 1.2); race.goFlash = 0.7; PX.Sound.play('go'); }
  }

  // ---------- update ----------
  function standings() {
    return race.racers.slice().sort((a, b) => {
      if (a.finished && b.finished) return a.time - b.time;
      if (a.finished) return -1; if (b.finished) return 1;
      if (a.projTime && b.projTime) return a.projTime - b.projTime;
      return b.x - a.x;
    });
  }
  function burst(r, n) {
    if (!race) return;
    for (let i = 0; i < n; i++) race.parts.push({ lane: r.lane, x: r.x + rnd(-8, 8), y: -rnd(6, 20), vx: rnd(-10, 10), vy: rnd(-26, -8), g: 30, life: rnd(0.4, 0.8),
      spr: PX.fx(i % 3 ? 'spark' : 'bigspark', i % 2 ? '#fbf236' : '#ffffff'), rel: true });
  }
  function sparkle(r, cols, n) {
    if (!race) return;
    for (let i = 0; i < n; i++) race.parts.push({ lane: r.lane, x: r.x + rnd(-6, 6), y: -rnd(4, 22), vx: rnd(-22, 22), vy: rnd(-34, -6), g: 40, life: rnd(0.4, 0.8), spr: PX.fx(i % 2 ? 'spark' : 'bigspark', cols[i % cols.length]), rel: true });
  }
  function ring(r, col, n) {
    if (!race) return;
    for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; race.parts.push({ lane: r.lane, x: r.x + Math.cos(a) * 6, y: -12 + Math.sin(a) * 6, vx: Math.cos(a) * 30, vy: Math.sin(a) * 30, g: 0, life: 0.45, spr: PX.fx('spark', col), rel: true }); }
  }
  function confettiBurst(r, n) {
    if (!race) return;
    const cols = ['#e5535f', '#fbf236', '#6abe30', '#639bff', '#c9a2f0', '#ffffff', '#f6a91a'];
    for (let i = 0; i < n; i++) race.parts.push({ lane: r.lane, x: r.x + rnd(-20, 30), y: GY - (V ? elevAt(V, r.x) : 0) - rnd(20, 40), vx: rnd(-14, 14), vy: rnd(-40, -5), g: 26, life: rnd(1.2, 2.2), spr: confetti(cols[i % cols.length], i & 1), rel: false, flut: rnd(8, 20), ph: rnd(0, 6) });
  }
  function onSegEnter(r, seg) {
    if (!race || race.C.segs.indexOf(seg) < 0 && !seg.after) return;
    const me = r.isPlayer;
    if (seg.type === 'swim') {
      const w = TH[themeAt(race.C, r.x)].water;
      for (let i = 0; i < 7; i++) race.parts.push({ lane: r.lane, x: r.x + rnd(-5, 5), y: GY, vx: rnd(-14, 14), vy: rnd(-40, -20), g: 110, life: 0.6, spr: PX.fx('drop', w[0]) });
      if (me) PX.Sound.play('splash');
    }
    if (seg.type === 'fly' && me) PX.Sound.play('whoosh');
    if (seg.type === 'run' && r.prevType === 'fly' && me) PX.Sound.play('thud');
    if (seg.type === 'climb' && me) PX.Sound.play('tick');
    if (me && !seg.after) {
      const th = themeAt(race.C, r.x + 2), sp = SEG_POP[th] && SEG_POP[th][seg.type];
      pop(sp || (seg.type === 'fly' ? 'Glide!' : seg.type === 'climb' ? 'Climb!' : seg.type === 'swim' ? 'Swim!' : 'Run!'), SEG_META[seg.type].color, 22, 1.1, true);
    }
  }
  function pop(text, color, size, life, side) {
    if (!race) return;
    if (side) race.pops = race.pops.filter(p => !p.side);
    race.pops.push({ text, color, size: size || 26, t: 0, life: life || 0.9, lane: race.player.lane, side: !!side });
  }
  function itemHint() {
    const x = xsRead(); if (x && x.hint && x.hint.item >= 2) return;
    const el = $r('.r-ihint'); el.hidden = false; clearTimeout(itemHint.tm); itemHint.tm = setTimeout(() => { el.hidden = true; }, 3500);
  }
  function useItem() {
    if (!race || race.paused || race.state !== 'run' || !race.items) return;
    const p = race.player; if (!p.item || p.finished) return;
    activate(p, p.item, { C: race.C, fx: true, W: race });
    $r('.r-ihint').hidden = true;
    const x = xs(); x.hint.item = (x.hint.item || 0) + 1; PS.save();
  }
  // kind: 'perfect' | 'good' | 'miss' (a late tap: stumble) | 'none' (no tap: no boost, but no stumble and the shield stays)
  // great: a GOOD tap close to the circle (shown as GREAT!, it counts as a good cheer). Cheers in a row lift the cheer's pitch.
  function resolveRing(kind, great) {
    const p = race.player; race.ring = null; race.ringsSeen++;
    p.nextBoost = rnd(T.ring.every[0], T.ring.every[1]) - (T.ring.r0 - T.ring.target) / T.ring.shrink;
    if (kind === 'none') { race.streak = 0; p.cheers.miss++; pop('miss', '#d8d0e6', 18, 0.7); if (race.ringsSeen >= 3) hideHint(); return; }
    applyCheer(p, kind, { fx: true });
    if (kind === 'miss') { race.streak = 0; pop('MISS', '#f07a84', 22); PX.Sound.play('miss'); }
    else {
      const s = race.streak = (race.streak || 0) + 1, word = kind === 'perfect' ? 'PERFECT!' : great ? 'GREAT!' : 'GOOD';
      pop(s >= 3 ? `${word} \u00d7${s}` : word, kind === 'perfect' ? '#fbf236' : great ? '#8fe3ff' : '#99e550', kind === 'perfect' ? 28 : great ? 26 : 24);
      PX.Sound.play('cheer', { pitch: 1 + 0.08 * Math.min(6, s - 1), streak: s });
      if (kind === 'perfect') { PX.Sound.play('chime'); PX.buzz(12); perfectFx(p); }
    }
    if (kind !== 'miss' || race.ringsSeen >= 3) hideHint();
  }
  function hideHint() {
    $r('.r-hint').hidden = true;
    if (!PS.S.seen.raceHint) { PS.S.seen.raceHint = true; PS.save(); }
  }
  function tap() {
    if (!race || race.paused || race.state !== 'run' || !race.ring) return;
    const k = judge(race.ring.r, race.ring.good);
    if (k === 'early') { race.ring.wob = 0.2; return; } // too soon: ignored (the ring just wiggles), tap again when it glows
    const d = Math.abs(race.ring.r - T.ring.target);
    resolveRing(k === 'late' ? 'miss' : k, k === 'good' && d <= (T.ring.perfect + race.ring.good) / 2);
  }
  // ---------- small juice (cached sprites; only near the camera, a few per second) ----------
  const DUST = { meadow: '#eadfbf', beach: '#fff3d6', moonlit: '#9fd8ff', candy: '#ffe0f0', coral: '#f4e2b0', cloud: '#ffffff', jungle: '#cdbf95', volcano: '#9a8a90', snowy: '#ffffff', starlight: '#fff27a' };
  const puffFrames = col => ICO['dust' + col] || (ICO['dust' + col] = [['.cc.', 'cccc'], ['c..c', '.cc.'], ['c...', '...c']].map(rows => PX.fromStrings(rows, { c: col }).canvas()));
  const rippleFrames = col => ICO['rip' + col] || (ICO['rip' + col] = [['.ccc.', 'c...c', '.ccc.'], ['..ccccc..', 'c.......c', '..ccccc..'], ['...c.c.c.c...', 'c...........c', '...c.c.c.c...']].map(rows => PX.fromStrings(rows, { c: col }).canvas()));
  function juice(dt) {
    const camX = race.player.x - PSX;
    for (const r of race.racers) {
      if (r.finished || r.x < camX - 24 || r.x > camX + WW + 24) continue;
      if ((r.fxT = (r.fxT || 0) - dt) > 0) continue;
      const s = segAtC(race.C, r.x), th = themeAt(race.C, r.x);
      if (s.type === 'run' && !s.after && r.x > 0) { // dust puffs behind the feet (faster when boosted, slower when tired)
        r.fxT = r.tired ? 0.5 : r.boostT > 0 || r.itemT > 0 ? 0.12 : 0.24;
        race.parts.push({ lane: r.lane, x: r.x - 5, y: GY - 1, vx: -rnd(3, 9), vy: -rnd(2, 6), g: 0, life: 0.36, life0: 0.36, frames: puffFrames(DUST[th] || DUST.meadow) });
      } else if (s.type === 'swim' && sinkAt(V, r.x) > 2) { // ripples spreading on the water
        r.fxT = 0.45;
        race.parts.push({ lane: r.lane, x: r.x - 2, y: GY, vx: 0, vy: 0, g: 0, life: 0.5, life0: 0.5, frames: rippleFrames(TH[th].water[0]) });
      } else r.fxT = 0.15;
    }
  }
  function perfectFx(p) { // PERFECT: sparkles burst out of the Cheer Ring, plus a quick white flash (render)
    const cy = race.mods.giant ? -24 : -12;
    for (let i = 0; i < 12; i++) { const a = i / 12 * Math.PI * 2; race.parts.push({ lane: p.lane, x: p.x + Math.cos(a) * 13, y: cy + Math.sin(a) * 13, vx: Math.cos(a) * 44, vy: Math.sin(a) * 44, g: 0, life: 0.4, spr: PX.fx(i % 2 ? 'bigspark' : 'spark', i % 3 ? '#fff27a' : '#ffffff'), rel: true }); }
    race.pflash = 0.3;
  }
  const DBG = { autoCheer: false, skill: null, autoItem: false };
  function updateGhost(dt) {
    const g = race.ghost; if (!g || g.none) return;
    const d = race.ghostData, k = race.C.LEN / (d.len || race.C.LEN), tt = race.t;
    g.animT += dt;
    if (tt >= d.best) { if (!g.finished) { g.finished = true; g.time = d.best; } g.x = race.C.LEN + Math.min(T.finishJog, (tt - d.best) * 20); return; }
    const f = tt / (d.dt || GHOST_DT), i = Math.floor(f), n = d.g.length - 1, a = d.g[Math.min(i, n)], b = d.g[Math.min(i + 1, n)];
    g.x = Math.min(race.C.LEN - 0.01, (a + (b - a) * (f - i)) * k);
  }
  function update(dt) {
    if (!race) return;
    if (race.stamp) race.stamp.t += dt;
    // photo finish: everything stops for a moment (the camera flash is drawn in render)
    if (race.freezeT > 0) { race.freezeT -= dt; return; }
    // the final stretch: the music picks up a little once you're three quarters of the way (once per race; a new track resets it)
    if (!race.fast && race.state !== 'count' && race.player && !race.player.finished && race.C && race.player.x > race.C.LEN * 0.75) { race.fast = true; try { if (PX.Music && PX.Music.tempo) PX.Music.tempo(1.08); } catch (e) { /* music optional */ } }
    for (const p of race.pops) p.t += dt; race.pops = race.pops.filter(p => p.t < p.life);
    let n = 0; // move particles and drop the dead ones in place (no new array every frame)
    for (const p of race.parts) { p.life -= dt; p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; if (p.flut) { p.vx = Math.sin(p.life * 6 + p.ph) * p.flut; p.vy = Math.min(p.vy, 14); } if (p.life > 0) race.parts[n++] = p; }
    race.parts.length = n;
    if (race.goFlash > 0) race.goFlash -= dt;
    if (race.pflash > 0) race.pflash -= dt;
    if (race.state === 'count') {
      const prev = Math.ceil(race.countT); race.countT -= dt; const now = Math.ceil(race.countT);
      for (const r of race.lanes) r.animT += dt;
      if (now !== prev) {
        if (now >= 1 && now <= 3) PX.Sound.play('countdown');
        if (now <= 0) {
          PX.Sound.play('go'); race.state = 'run'; race.goFlash = 0.7; if (!PS.S.seen.raceHint) $r('.r-hint').hidden = false;
          try { if (PS.ui.fx && PS.ui.fx.banner) { PS.ui.fx.banner('GO!', { tone: 'go', ms: 650 }); race.goBanner = true; } } catch (e) { /* optional */ }
        }
      }
      return;
    }
    race.t += dt;
    const sctx = { C: race.C, t: race.t, rng: Math.random, fx: true, onFinish, W: race, items: race.items, placeOf: r => standings().indexOf(r) };
    for (const r of race.racers) stepRacer(r, dt, sctx);
    for (const h of race.honey) h.t += dt;
    const p = race.player;
    if (race.mode === 'trial') {
      updateGhost(dt);
      while (!p.finished && race.rec.length * GHOST_DT <= race.t) race.rec.push(Math.round(p.x));
    }
    for (const r of race.racers) if (r.starT > 0 && Math.random() < 0.6) race.parts.push({ lane: r.lane, x: r.x - rnd(4, 10), y: -rnd(2, 24), vx: rnd(-20, -6), vy: rnd(-6, 6), g: 0, life: 0.4, spr: PX.fx('spark', RAINBOW[Math.floor(Math.random() * 6)]), rel: true });
    juice(dt);
    if (DBG.autoItem && p.item) useItem();
    if (race.state === 'run' && !p.finished) {
      if (!race.ring) { p.nextBoost -= dt; if (p.nextBoost <= 0) race.ring = { r: T.ring.r0, good: goodOf(race.tier, race.mode), wob: 0, cueT: -1 }; }
      else {
        const rg = race.ring; rg.r -= T.ring.shrink * dt; if (rg.wob > 0) rg.wob -= dt;
        const k = judge(rg.r, rg.good), d = Math.abs(rg.r - T.ring.target);
        if (k === 'perfect' || k === 'good') rg.cueT = rg.cueT < 0 ? 0 : rg.cueT + dt; // time since the "TAP!" window opened (render)
        if (DBG.skill) { // debug: simulated tapper (plans one of perfect / good / miss (late) / none per ring)
          if (!rg.plan) { const u = Math.random(), s = DBG.skill; rg.plan = u < s[0] ? 'perfect' : u < s[0] + s[1] ? 'good' : u < s[0] + s[1] + s[2] ? 'miss' : 'none'; }
          if ((rg.plan === 'perfect' && d <= T.ring.perfect * 0.6) || (rg.plan === 'good' && k === 'good' && rg.r < T.ring.target) || (rg.plan === 'miss' && k === 'late')) tap();
        } else if (DBG.autoCheer && d <= T.ring.perfect * 0.6) tap();
        if (race.ring && race.ring.r < T.ring.endR) resolveRing('none'); // no tap: no boost, no stumble
      }
    } else if (race.ring && p.finished) race.ring = null;
    // skip button once the player's place can't change (never in a time trial)
    const rivalsDone = race.racers.every(r => r.isPlayer || r.finished);
    $r('.r-skip').hidden = !(race.mode !== 'trial' && race.state === 'run' && !p.finished && rivalsDone);
    if (race.state === 'run' && race.finishT && (race.racers.every(r => r.finished) || race.t - race.finishT > 2.2)) endRace();
    if (race.state === 'done') {
      race.doneT += dt;
      if (race.doneT > (race.mode === 'trial' ? 1.6 : 1.2) && !race.shown) {
        race.shown = true;
        try { showResults(); } catch (e) { console.error('race results', e); bailOut(); } // never trap a kid on a broken card
      }
    }
  }
  function onFinish(r) {
    const place = standings().filter(x => x.finished).indexOf(r);
    if (r === race.player) {
      race.finishT = race.t; race.ring = null;
      $r('.r-quit').style.visibility = 'hidden'; // crossed the line: no leaving now, the results and prizes are coming
      const win = race.mode === 'trial' ? (!race.ghost || race.ghost.none || !race.ghost.finished) : place === 0;
      PX.Sound.play(win ? 'level' : 'coo');
      if (win) setEmote(r, 'heart', 2.5);
      burst(r, 8);
      if (win || place <= 2) confettiBurst(r, win ? 46 : 22);
      race.freezeT = RM ? 0 : 0.4;
      race.stamp = { text: race.mode === 'trial' ? 'FINISH!' : ORD[place] + '!', col: race.mode === 'trial' ? '#ffffff' : STAMP_COL[Math.min(3, Math.max(0, place))], t: 0 };
    }
  }
  function project(r) {
    const c = Object.assign({}, r, { cheers: { perfect: 0, good: 0, miss: 0 }, item: null }), sc = { C: race.C, t: race.t, rng: Math.random, fx: false }, dt = 1 / 30;
    while (!c.finished && sc.t < race.t + 300) { sc.t += dt; stepRacer(c, dt, sc); }
    return c.time;
  }
  function endRace() {
    for (const r of race.racers) if (!r.finished) r.projTime = project(r);
    race.state = 'done'; race.doneT = 0; race.ring = null;
    $r('.r-skip').hidden = true; $r('.r-hint').hidden = true; $r('.r-ihint').hidden = true; $r('.r-quit').style.visibility = 'hidden';
  }
  function skipToEnd() {
    if (!race || race.state !== 'run' || race.mode === 'trial') return;
    PX.Sound.play('pop');
    const p = race.player;
    if (!p.finished) { p.projTime = project(p); }
    race.finishT = race.t; endRace(); race.doneT = 1.2;
  }

  // ---------- settle (rewards happen here, exactly once per race) ----------
  function finishExtra(s, R, tier, place, timeSec) {
    const Tr = D.RACE_TIERS[tier], X = xs(), key = R.id + '-' + tier;
    const p = Object.assign(blankProg(), X.series[key] || {});
    const firstWin = place === 0 && !p.wins;
    p.runs++; if (place === 0) p.wins++; if (timeSec && (!p.best || timeSec < p.best)) p.best = +timeSec.toFixed(2);
    X.series[key] = p;
    const coins = ST.addCoins(Tr.coins * R.mult * D.RACE_PLACE_SHARE[place], 'race');
    const mixTotal = Object.values(R.mix).reduce((a, b) => a + b, 0), gives = {};
    for (const [seg, w] of Object.entries(R.mix)) { const st = D.RACE_STAT[seg]; gives[st] = (gives[st] || 0) + Tr.xp * (w / mixTotal) * 2.5 * (place === 0 ? 1 : 0.6); }
    gives.stamina = (gives.stamina || 0) + Tr.xp * 0.5;
    const res = ST.gain(s, gives);
    if (s.record) { s.record.races = (s.record.races || 0) + 1; if (place === 0) s.record.raceWins = (s.record.raceWins || 0) + 1; }
    if (PS.S.totals) { PS.S.totals.races = (PS.S.totals.races || 0) + 1; if (place === 0) PS.S.totals.raceWins = (PS.S.totals.raceWins || 0) + 1; }
    if (place === 0 && ST.aquaWin) ST.aquaWin('race', { tier });
    let egg = null, unlock = null, item = null, map = null, bonus = null;
    if (firstWin) {
      unlock = ST.reward('race:' + key, `${R.name} ${Tr.name}`);
      if (unlock && unlock.map) { map = unlock.map; unlock = null; }
      egg = unlock ? unlock.egg : map ? null : ST.addEgg(R.eggs[tier], `${R.name} ${Tr.name}`);
      PS.S.bestTier = Math.max(PS.S.bestTier || 0, tier + 1);
    }
    // plant races: every win gives this tier's prize; zombie races: now and then a lucky fusion item for the winner
    if (place === 0 && R.plants) {
      const kind = PLANT_WIN_PRIZE[tier];
      if (kind === 'fruit') { const ids = Object.keys(D.FRUITS).filter(f => D.FRUITS[f].price < 100), f = ids[Math.floor(Math.random() * ids.length)]; ST.addFruit(f, 2); bonus = { kind, id: f, n: 2 }; }
      else if (kind === 'core') { const els = Object.keys(D.ELEMENT_INFO), el = els[Math.floor(Math.random() * els.length)]; ST.addToPouch(el); bonus = { kind, id: el, n: 1 }; }
      else { item = ST.randomItem(); ST.addItem(item); }
    } else if (place === 0 && Math.random() < 0.12) { item = ST.randomItem(); ST.addItem(item); }
    PS.save();
    return { coins, gives, ups: res.ups, evolved: res.evolved, egg, unlock, item, map, bonus, firstWin, unlockedNext: firstWin };
  }
  function finishCup(s, place) {
    const X = xs(), info = race.info, day = info.key;
    if (X.daily.day !== day) X.daily = { day, best: null, runs: 0, egg: false, total: X.daily.total || 0, wins: X.daily.wins || 0 };
    const d = X.daily, prev = d.best, firstToday = prev == null;
    d.runs = (d.runs || 0) + 1;
    let coins = 0, gives = {}, res = { ups: {}, evolved: null }, egg = null;
    if (prev == null || place < prev) {
      coins = ST.addCoins(cupCoins(place) - (prev == null ? 0 : cupCoins(prev)), 'cup');
      d.best = place;
      if (place === 0) d.wins = (d.wins || 0) + 1;
      if (!d.egg && Math.random() < CUP_EGG_CHANCE[place]) { d.egg = true; egg = ST.addEgg(info.egg, 'Daily Cup'); }
    }
    if (firstToday) {
      d.total = (d.total || 0) + 1;
      const xp = CUP_XP[Math.min(3, PS.S.bestTier || 0)], R = info.R, mixTotal = Object.values(R.mix).reduce((a, b) => a + b, 0);
      for (const [seg, w] of Object.entries(R.mix)) { const st = D.RACE_STAT[seg]; gives[st] = (gives[st] || 0) + xp * (w / mixTotal) * 2.5 * (place === 0 ? 1 : 0.6); }
      gives.stamina = (gives.stamina || 0) + xp * 0.5;
      res = ST.gain(s, gives);
    }
    if (s.record) { s.record.races = (s.record.races || 0) + 1; if (place === 0) s.record.raceWins = (s.record.raceWins || 0) + 1; }
    if (PS.S.totals) { PS.S.totals.races = (PS.S.totals.races || 0) + 1; if (place === 0) PS.S.totals.raceWins = (PS.S.totals.raceWins || 0) + 1; }
    PS.save();
    return { coins, gives, ups: res.ups, evolved: res.evolved, egg, prev, improved: prev == null || place < prev, firstToday };
  }
  function finishTrial(s, time) {
    const X = xs(), key = race.R.id + '-' + race.tier, tr = Object.assign({ best: null, m: 0, runs: 0 }, X.trials[key] || {});
    const prevBest = tr.best, newBest = !prevBest || time < prevBest;
    tr.runs = (tr.runs || 0) + 1;
    if (newBest) {
      const g = race.rec.slice(); g.push(Math.round(race.C.LEN));
      Object.assign(tr, { best: +time.toFixed(2), g, dt: GHOST_DT, len: race.C.LEN, sid: s.id });
    }
    const mt = medalTimes(race.ri, race.tier), got = medalOf(mt, time), had = Math.min(3, tr.m || 0), newMedals = [];
    let coins = 0, xp = 0;
    for (let k = had; k < got; k++) { coins += medalCoins(race.R, race.tier, k); xp += D.RACE_TIERS[race.tier].xp * MEDAL_XP[k]; newMedals.push(k); }
    tr.m = Math.max(had, got);
    X.trials[key] = tr;
    if (coins) ST.addCoins(coins, 'trial');
    const gives = {}; let res = { ups: {}, evolved: null };
    if (xp) {
      const mix = race.R.mix, tot = Object.values(mix).reduce((a, b) => a + b, 0);
      for (const [seg, w] of Object.entries(mix)) { const st = D.RACE_STAT[seg]; gives[st] = (gives[st] || 0) + xp * (w / tot) * 2.5; }
      gives.stamina = (gives.stamina || 0) + xp * 0.5;
      res = ST.gain(s, gives);
    }
    PS.save();
    return { time, prevBest, newBest, mt, got, have: tr.m, newMedals, coins, gives, ups: res.ups, evolved: res.evolved };
  }
  function settle() {
    if (!race || race.settled) return race && race.summary;
    race.settled = true;
    if (race.mode === 'trial') { race.summary = finishTrial(race.sprout, race.player.time); return race.summary; }
    const order = race.racers.slice().sort((a, b) => finalTime(a) - finalTime(b));
    // a skipped race only has an estimated time for you: it never becomes your Best time (0 = no time)
    const place = order.indexOf(race.player), time = race.player.finished ? race.player.time : 0;
    race.order = order; race.place = place;
    if (race.mode === 'cup') race.summary = finishCup(race.sprout, place);
    else if (race.R.extra) race.summary = finishExtra(race.sprout, race.R, race.tier, place, time);
    else race.summary = ST.finishRace(race.sprout, race.R.id, race.tier, place, time);
    return race.summary;
  }
  function xpChipsHtml(sum) {
    const gives = sum.gives || {}, ups = sum.ups || {};
    return D.STATS.filter(k => gives[k] > 0.5).sort((a, b) => gives[b] - gives[a]).map(k => `<span class="r-xpchip" style="background:${D.STAT_META[k].color}">${D.STAT_META[k].label} +${Math.round(gives[k])} XP${ups[k] ? `<b>Lv ${race.sprout.stats[k].lv}!</b>` : ''}</span>`).join('');
  }
  function eggBoxHtml(sum, text) {
    if (!sum.egg) return '';
    const U = sum.unlock, P = U && D.PLANTS[U.species];
    const head = P ? (U.isNew ? `New plant unlocked: ${esc(P.name)}!` : `${esc(P.name)} seeds!`) : sum.egg.kind === 'normal' ? `${esc(D.PLANTS[sum.egg.species].name)} seeds!` : `New ${esc(eggName(sum.egg.kind))}!`;
    return `<div class="r-eggbox"><canvas class="px r-eggcv"></canvas><div><b>${head}</b><span>${text || 'The seed packet is waiting in the Garden.'}${P && U.isNew ? ' You can buy more in the Shop now.' : ''}</span></div></div>`;
  }
  function bonusBoxHtml(sum) {
    let html = '';
    if (sum.map) html += `<div class="r-eggbox"><canvas class="px r-mapcv" data-map="${sum.map}"></canvas><div><b>New garden map: ${esc(D.GARDEN_MAPS[sum.map].name)}!</b><span>Tap a garden's name in the Garden to put it on.</span></div></div>`;
    const B = sum.bonus; if (!B) return html;
    if (B.kind === 'fruit') html += `<div class="r-eggbox"><canvas class="px r-bonuscv" data-fruit="${B.id}"></canvas><div><b>Prize: ${B.n} × ${esc(D.FRUITS[B.id].name)}!</b><span>It's in your fruit tray in the Garden.</span></div></div>`;
    if (B.kind === 'core') html += `<div class="r-eggbox"><canvas class="px r-bonuscv" data-core="${B.id}"></canvas><div><b>Prize: a ${esc(D.ELEMENT_INFO[B.id].name)} core!</b><span>It's in your core pouch in the Garden.</span></div></div>`;
    return html;
  }
  function friendBoxHtml(sum) {
    if (!sum.item) return '';
    const I = D.FUSION_ITEMS[sum.item];
    return `<div class="r-eggbox"><canvas class="px r-friendcv" data-fitem="${sum.item}"></canvas><div><b>Lucky! A ${esc(I.name)}!</b><span>A fusion item. Fuse it onto a plant in the Shop's Fusion Lab.</span></div></div>`;
  }
  // ---------- what happened, in kid terms: cheer counts (the same bubbles your plant shows) + ONE tip with a picture ----------
  const SEG_TIP = { run: ['el:electric', 'Slow running: give it an Electric core!'], swim: ['el:water', 'Slow in the water: give it a Water core!'], climb: ['el:fire', 'Slow climbing: give it a Fire core for Power!'], fly: ['el:magic', 'Slow gliding: give it a Magic core!'] };
  function cheerStatsHtml(p) {
    const c = p.cheers;
    return `<div class="r-cheers">${[['sparkle', c.perfect, 'Perfect'], ['heart', c.good, 'Good'], ['?', c.miss, 'Miss'], ['swirl', p.tiredCount, 'Tired']]
      .map(([e, n, l]) => `<span class="r-cstat" aria-label="${n} ${l}"><canvas class="px" data-emo="${esc(e)}"></canvas><b>${n}</b><small>${l}</small></span>`).join('')}</div>`;
  }
  // the one thing that would help most: missed rings, getting tired, or (after a loss) the segment where the fastest rival
  // gained most on you. rivals: null when their speed says nothing about your stats (Daily Cup, time trial)
  function tipFor(p, rivals, won) {
    const c = p.cheers, n = c.perfect + c.good + c.miss;
    if (n >= 3 && c.miss >= Math.max(2, n * 0.4)) return { ic: 'ringtip', text: 'Tap when the ring touches the circle!' };
    if (p.tiredCount >= 2) return { fruit: 'heartyroot', text: 'Train Stamina: feed Hearty Roots!' };
    if (won) return null;
    if (rivals && rivals.length) {
      const top = rivals.reduce((a, b) => (finalTime(b) < finalTime(a) ? b : a)), share = {}; let all = 0, seg = null, most = 0.015;
      for (const s of race.C.segs) { const q = s.len / T.base[s.type]; all += q; share[s.type] = (share[s.type] || 0) + q; }
      for (const k of SEGS) { const loss = (share[k] || 0) / all * (1 - p.mul[k] / top.mul[k]); if (loss > most) { most = loss; seg = k; } }
      if (seg) return { critter: SEG_TIP[seg][0], text: SEG_TIP[seg][1] };
    }
    if (n >= 3 && c.perfect < c.good) return { ic: 'ringtip', text: 'Tap right ON the circle for a PERFECT boost!' };
    return null;
  }
  const tipHtml = tp => (tp ? `<div class="r-tip"><canvas class="px r-tipcv"></canvas><span>${esc(tp.text)}</span></div>` : '');
  function paintCheerIcons(ov, tp) {
    ov.querySelectorAll('canvas[data-emo]').forEach(c => { try { paintTo(c, PX.emote(c.dataset.emo), 13, 13); } catch (e) { /* optional */ } });
    const tc = ov.querySelector('.r-tipcv'); if (!tc || !tp) return;
    if (tp.critter) { const cr = safeCritter(tp.critter); if (cr) paint2x(tc, cr); }
    else if (tp.fruit) { let f = null; try { f = PX.fruit(tp.fruit); } catch (e) { /* optional */ } if (f) paintTo(tc, f, 18, 18); }
    else paintTo(tc, icon(tp.ic), 18, 18);
  }
  // ---------- results (the shared .pv-res window): place title, podium, coins rolling up, XP bars filling, prize tiles ----------
  const resTile = (ic, value, label, cls) => `<div class="pv-res-tile${cls ? ' ' + cls : ''}">${ic ? `<canvas class="px" data-rt="${ic}"></canvas>` : ''}<b class="num">${value}</b><small>${label}</small></div>`;
  function prizeTiles(sum) {
    const out = [], B = sum.bonus;
    if (sum.egg) {
      const U = sum.unlock, P = U && D.PLANTS[U.species];
      const lb = P ? (U.isNew ? `New: ${esc(P.name)}` : esc(P.name)) : sum.egg.kind === 'normal' && D.PLANTS[sum.egg.species] ? esc(D.PLANTS[sum.egg.species].name) : esc(eggName(sum.egg.kind));
      out.push(resTile('egg', 'Seeds!', lb, 'r-prizetile'));
    }
    if (sum.map && D.GARDEN_MAPS[sum.map]) out.push(resTile('map', 'Map!', esc(D.GARDEN_MAPS[sum.map].name), 'r-prizetile'));
    if (B && B.kind === 'fruit' && D.FRUITS[B.id]) out.push(resTile('fruit', '×' + B.n, esc(D.FRUITS[B.id].name), 'r-prizetile'));
    if (B && B.kind === 'core' && D.ELEMENT_INFO[B.id]) out.push(resTile('core', 'Core!', esc(D.ELEMENT_INFO[B.id].name), 'r-prizetile'));
    if (sum.item && D.FUSION_ITEMS[sum.item]) out.push(resTile('fitem', 'Item!', esc(D.FUSION_ITEMS[sum.item].name), 'r-prizetile'));
    return out;
  }
  function paintResIcons(ov, sum) {
    ov.querySelectorAll('canvas[data-rt]').forEach(c => {
      const k = c.dataset.rt; let e = null;
      try {
        if (k === 'coin') { paintTo(c, icon('coin'), 11, 11); return; }
        if (k === 'egg') { e = safeItem('egg', sum.egg.kind + ':' + sum.egg.species); if (e) paintTo(c, e, 22, 28); return; }
        if (k === 'map') { const m = PS.ui.mapPreview(sum.map); c.width = 120; c.height = 64; const x = c.getContext('2d'); x.imageSmoothingEnabled = false; x.drawImage(m, 0, 0, 120, 64); c.style.width = '56px'; c.style.height = '30px'; return; }
        e = k === 'fruit' ? safeItem('fruit', sum.bonus.id) : k === 'core' ? safeItem('core', sum.bonus.id) : k === 'fitem' ? safeItem('fitem', sum.item) : null;
        if (e) paint2x(c, e);
      } catch (err) { /* art optional */ }
    });
  }
  // one bar per stat that got XP: it fills from where it was to where it is now ("Lv 12!" when it went up a level)
  function xpBarsHtml(sum) {
    const gives = sum.gives || {}, ups = sum.ups || {}, s = race.sprout, need = lv => { try { return D.GROWTH.xpForLevel(lv) || 100; } catch (e) { return 100; } };
    return D.STATS.filter(k => gives[k] > 0.5 && s && s.stats && s.stats[k]).sort((a, b) => gives[b] - gives[a]).map(k => {
      const st = s.stats[k], to = clamp(st.xp / need(st.lv), 0, 1), up = !!ups[k], from = up ? 0 : clamp((st.xp - gives[k]) / need(st.lv), 0, to), col = D.STAT_META[k].color;
      return `<div class="r-xprow"><span class="r-xpname" style="background:${col}">${D.STAT_META[k].label}</span><span class="r-xpbar"><i style="width:${Math.round(from * 100)}%;background:${col}" data-to="${Math.round(to * 100)}"></i></span>${up ? `<em class="r-lvup">Lv ${st.lv}!</em>` : `<small>+${Math.round(gives[k])}</small>`}</div>`;
    }).join('');
  }
  function podiumHtml(order, p) {
    const slot = i => (order[i] ? `<div class="r-pod p${i}${order[i] === p ? ' me' : ''}"><canvas class="px" data-pod="${i}"></canvas>${order[i] === p ? '<span class="r-you">You</span>' : ''}<div class="r-step"><b>${i + 1}</b></div></div>` : '');
    return `<div class="pv-res-hero r-podium">${slot(1)}${slot(0)}${slot(2)}</div>`;
  }
  function paintPodium(ov, order) {
    ov.querySelectorAll('canvas[data-pod]').forEach(c => {
      const i = +c.dataset.pod, r = order[i]; if (!r) return;
      try {
        if (r.animal) { const cr = safeCritter(r.animal); if (cr) paint2x(c, cr); }
        else spriteBox(c, r.look, i === 0 ? { eyes: 'happy', mouth: 'open', arms: 'up' } : { eyes: 'happy' }, 40);
      } catch (e) { /* art optional */ }
    });
  }
  // after the window drops in: coins roll up (and fly to the top bar's coin pill), XP bars fill
  function resultsFx(ov) {
    const cu = ov.querySelector('[data-count]');
    if (cu && PS.ui.fx && PS.ui.fx.countUp) {
      try { PS.ui.fx.countUp(cu, 0, +cu.dataset.count, 700, { prefix: '+' }); } catch (e) { /* optional */ }
      if (+cu.dataset.count > 0 && PS.ui.fx.coinsFly) setTimeout(() => { try { if (cu.isConnected) PS.ui.fx.coinsFly(cu, 8); } catch (e) { /* optional */ } }, 200);
    }
    requestAnimationFrame(() => requestAnimationFrame(() => ov.querySelectorAll('.r-xpbar i[data-to]').forEach(i => { i.style.width = i.dataset.to + '%'; })));
  }
  function showResults() {
    const sum = settle();
    if (race.mode === 'trial') return showTrialResults(sum);
    const order = race.order, place = race.place, p = race.player, R = race.R, Tr = race.Tr, cup = race.mode === 'cup';
    const title = ['1st!', '2nd!', '3rd!'][place] || 'So close!', tcls = [' ', ' r-silver', ' r-bronze'][place] || ' lose';
    const after = allUnlocked(), newly = Object.keys(after).filter(k => after[k] && !race.unlockedBefore[k]);
    const newNames = newly.map(k => { const i = k.lastIndexOf('-'), RR = byId(k.slice(0, i)); return RR ? `${RR.name} ${D.RACE_TIERS[+k.slice(i + 1)].name}` : k; });
    const tp = tipFor(p, cup ? null : race.racers.filter(r => r !== p), place === 0);
    const tiles = [];
    if (!cup || sum.coins > 0) tiles.push(resTile('coin', `<span data-count="${sum.coins}">+${sum.coins}</span>`, 'Coins'));
    tiles.push(resTile(null, `${p.finished ? '' : '~'}${finalTime(p).toFixed(1)}s`, place > 2 ? `${ORD[place]} place` : 'Your time'));
    tiles.push(...prizeTiles(sum));
    const xp = xpBarsHtml(sum);
    let note = '';
    if (cup && !(sum.coins > 0) && !xp) note = sum.prev === 0 ? 'You already won today’s cup. This one was just for fun!' : `Your best today is still ${ORD[sum.prev]}. Win to earn more!`;
    else if (cup) note = place === 0 ? 'A new cup with a new twist arrives tomorrow!' : 'You can try again today to win the rest of the prize.';
    const ov = $r('.r-results');
    ov.className = 'r-ov r-results pv-res';
    ov.innerHTML = `<div class="pv-res-win r-reswin" role="dialog" aria-label="Race results">
      <div class="eyebrow">${cup ? 'Daily Cup · ' + esc(race.info.M.name) : esc(R.name) + ' · ' + Tr.name}</div>
      <div class="pv-res-title${tcls.trim() ? tcls : ''}">${title}</div>
      ${podiumHtml(order, p)}
      <div class="pv-res-tiles">${tiles.join('')}</div>
      ${xp ? `<div class="r-xps">${xp}</div>` : ''}
      ${newNames.length ? `<p class="r-note">Unlocked: <b>${newNames.map(esc).join(', ')}</b></p>` : ''}
      ${tipHtml(tp)}
      ${cheerStatsHtml(p)}
      ${note ? `<p class="r-note">${note}</p>` : ''}
      <div class="pv-res-btns"><button class="btn go r-again" type="button">Race again</button><button class="btn r-back" type="button">Back</button></div>
    </div>`;
    paintPodium(ov, order); paintResIcons(ov, sum); paintCheerIcons(ov, tp);
    const ri = race.ri, tier = race.tier;
    ov.querySelector('.r-back').onclick = () => { PX.Sound.play('pop'); endRaceUI(); showHub(); hubMusic(); };
    ov.querySelector('.r-again').onclick = () => { PX.Sound.play('go'); endRaceUI(); showHub(); if (cup) startCup(); else startRace(ri, tier); };
    finishResults(place === 0 ? 'evolve' : place === 1 ? 'chime' : 'pop', place === 0 ? 'victory' : place === 3 ? 'lose' : null);
    resultsFx(ov);
  }
  function showTrialResults(sum) {
    const R = race.R, Tr = race.Tr;
    const title = sum.newMedals.length ? `${MEDAL_NAMES[sum.got - 1]} medal!` : sum.newBest ? (sum.prevBest ? 'New best time!' : 'Ghost saved!') : 'Nice run!';
    let delta = '';
    if (sum.prevBest) { const d = sum.time - sum.prevBest; delta = d < 0 ? `<p class="r-delta good">${(-d).toFixed(1)}s faster than your ghost!</p>` : `<p class="r-delta bad">${d.toFixed(1)}s behind your ghost. ${d < 1.5 ? 'So close!' : 'Keep trying!'}</p>`; }
    else delta = '<p class="r-delta good">Next time, your ghost will race you!</p>';
    const cells = [0, 1, 2].map(k => `<div class="r-mcell${k < sum.have ? ' got' : ''}${sum.newMedals.includes(k) ? ' new' : ''}"><canvas class="px" data-medal="${k < sum.have ? k : 'x'}"></canvas>${MEDAL_NAMES[k]}<b>${sum.mt[k].toFixed(1)}s</b></div>`).join('');
    const xp = xpBarsHtml(sum), tp = tipFor(race.player, null, false), next = sum.have < 3 ? medalCoins(R, race.tier, sum.have) : 0;
    const ov = $r('.r-results');
    ov.className = 'r-ov r-results pv-res';
    ov.innerHTML = `<div class="pv-res-win r-reswin" role="dialog" aria-label="Time trial results">
      <div class="eyebrow">Time Trial · ${esc(R.name)} · ${Tr.name}</div>
      <div class="pv-res-title${sum.newMedals.length || sum.newBest ? '' : ' lose'}">${title}</div>
      <div class="r-bigtime">${sum.time.toFixed(1)}s</div>
      ${delta}
      <div class="r-mrow">${cells}</div>
      ${sum.coins ? `<div class="pv-res-tiles">${resTile('coin', `<span data-count="${sum.coins}">+${sum.coins}</span>`, 'Coins')}</div>` : ''}
      ${xp ? `<div class="r-xps">${xp}</div>` : ''}
      ${sum.have < 3 ? `<p class="r-note">Beat <b>${sum.mt[sum.have].toFixed(1)}s</b> for ${sum.have === 0 ? 'a' : 'the'} ${MEDAL_NAMES[sum.have]} medal (+${next} coins)!</p>` : '<p class="r-note">You have every medal here. Can you beat your ghost again?</p>'}
      ${tipHtml(tp)}
      ${cheerStatsHtml(race.player)}
      <div class="pv-res-btns"><button class="btn go r-again" type="button">Try again</button><button class="btn r-back" type="button">Back</button></div>
    </div>`;
    ov.querySelectorAll('canvas[data-medal]').forEach(c => paintTo(c, icon('medal' + c.dataset.medal), 11, 14));
    paintResIcons(ov, sum); paintCheerIcons(ov, tp);
    const ri = race.ri, tier = race.tier;
    ov.querySelector('.r-back').onclick = () => { PX.Sound.play('pop'); endRaceUI(); hubTab = 'trial'; showHub(); hubMusic(); };
    ov.querySelector('.r-again').onclick = () => { PX.Sound.play('go'); endRaceUI(); hubTab = 'trial'; showHub(); startTrial(ri, tier); };
    finishResults(sum.newMedals.length ? 'evolve' : sum.newBest ? 'chime' : 'pop', sum.newMedals.length ? 'victory' : null);
    resultsFx(ov);
  }
  // jingle: the music's fanfare (audio.js) instead of the sound effect, when there is one
  function finishResults(snd, jingle) {
    $r('.r-results').hidden = false; $r('.r-quit').style.visibility = 'hidden'; $r('.r-item').hidden = true;
    let played = false;
    if (jingle) { try { if (PX.Music && PX.Music.jingle) { PX.Music.jingle(jingle); played = true; } } catch (e) { played = false; } }
    if (!played) PX.Sound.play(snd);
    // back on a menu: show the HUD (coins bump) and release held pop-ups (evolution etc.)
    PS.ui.chrome(true); PS.ui.hold(false);
  }

  // ---------- HUD ----------
  let dotEls = [], lastHud = '';
  function buildHud() {
    const rail = $r('.r-rail'), C = race.C;
    rail.innerHTML = C.segs.map(s => `<i style="width:${(s.len / C.LEN * 100).toFixed(2)}%;background:${SEG_META[s.type].color}"></i>`).join('');
    const dots = $r('.r-dots'); dots.innerHTML = ''; dotEls = [];
    race.lanes.forEach(r => { const d = document.createElement('i'); d.className = 'r-dot' + (r === race.player ? ' me' : '') + (r.isGhost ? ' ghost' : ''); d.style.background = r.color; if (r.none) d.hidden = true; dots.appendChild(d); dotEls.push(d); });
    lastHud = ''; race.itemKey = '?';
  }
  function hudPlace() {
    const p = race.player;
    if (race.mode !== 'trial') return standings().indexOf(p);
    const g = race.ghost; if (!g || g.none) return 0;
    if (p.finished && g.finished) return p.time <= g.time ? 0 : 1;
    if (g.finished) return 1; if (p.finished) return 0;
    return p.x >= g.x ? 0 : 1;
  }
  function updateHud() {
    if (!race) return;
    race.lanes.forEach((r, i) => { dotEls[i] && (dotEls[i].style.left = (clamp(r.x / race.C.LEN, 0, 1) * 100).toFixed(2) + '%'); });
    const p = race.player, pl = hudPlace();
    const tm = race.state === 'count' ? 0 : p.finished ? p.time : race.t;
    const key = pl + '|' + tm.toFixed(1);
    if (key !== lastHud) { lastHud = key; $r('.r-place').innerHTML = (pl + 1) + '<small>' + ORD[pl].slice(1) + '</small>'; $r('.r-time').textContent = tm.toFixed(1) + 's'; }
    const f = clamp(p.stam / p.stamMax, 0, 1), s = $r('.r-stam');
    s.style.width = (f * 100).toFixed(1) + '%';
    s.style.background = p.starT > 0 ? RAINBOW[Math.floor(race.t * 10) % 6] : p.tired ? '#d24552' : f < 0.3 ? '#f6c83a' : '#6abe30';
    if (race.items) {
      const k = (p.item || '') + (race.state === 'done' ? 'x' : '');
      if (k !== race.itemKey) {
        race.itemKey = k; const b = $r('.r-item');
        b.hidden = race.state === 'done' || race.shown;
        b.classList.toggle('has', !!p.item);
        paintTo(b.querySelector('canvas'), icon(p.item || 'itembox'), 15, 15);
        b.querySelector('span').textContent = p.item ? 'Use!' : 'Item';
        b.setAttribute('aria-label', p.item ? 'Use ' + ITEMS[p.item].name : 'No item yet');
      }
    }
  }

  // ---------- render ----------
  function poseOf(r) {
    const s = segAtC(race.C, r.x), P = { frame: 0 };
    if (race.state === 'count') { P.frame = Math.floor(race.countT * 3 + r.lane) % 2; P.mouth = 'grin'; return P; }
    if (r.finished) {
      const place = r.isGhost ? 1 : standings().indexOf(r);
      P.arms = 'up'; P.eyes = 'happy'; P.mouth = place === 0 ? 'open' : 'smile'; P.frame = Math.floor(r.animT * 3) % 2;
      if (r.x < race.C.LEN + T.finishJog) { P.walk = true; P.frame = Math.floor(r.x / 5) % 2; }
      return P;
    }
    if (s.type === 'run') { P.walk = true; P.frame = Math.floor(r.x / 5) % 2; }
    else if (s.type === 'swim') { P.arms = sinkAt(V, r.x) > 3 ? 'paddle' : 'down'; P.walk = P.arms === 'down'; P.frame = Math.floor(r.animT * 4) % 2; }
    else if (s.type === 'climb') { P.arms = 'up'; P.walk = true; P.frame = Math.floor(r.x / 3) % 2; }
    else { P.arms = 'out'; P.flap = true; P.frame = Math.floor(r.animT * ((r.look.parts || {}).wings ? 7 : 5)) % 2; }
    if (r.stumbleT > 0 || (r.slowT > 0 && r.starT <= 0)) { P.eyes = 'sad'; P.mouth = 'o'; }
    else if (r.tired) { P.eyes = 'closed'; P.mouth = 'o'; }
    else if (r.boostT > 0 || r.itemT > 0) { P.eyes = 'happy'; P.mouth = 'grin'; }
    return P;
  }
  function feetY(r) {
    const P = poseOf(r); let bob = 0;
    const s = segAtC(race.C, r.x);
    if (!r.finished && race.state !== 'count') {
      if (s.type === 'run' || s.type === 'climb') bob = P.frame ? -1 : 0;
      if (s.type === 'swim') bob = P.frame ? 1 : 0;
      if (s.type === 'fly') bob = P.frame ? 0 : -1;
      if (race.mods.lowgrav && s.type === 'run' && !s.after) { bob = -Math.round(Math.abs(Math.sin(r.x * 0.075 + r.lane)) * 10); P.walk = false; P.arms = bob < -6 ? 'up' : 'out'; }
      if (race.mods.lowgrav && s.type === 'fly') bob -= Math.round(2 + Math.sin(r.animT * 2) * 2);
    } else if (r.finished && r.x >= race.C.LEN + T.finishJog) bob = P.frame ? -2 : 0;
    return { y: GY + 1 - elevAt(V, r.x) + sinkAt(V, r.x) + bob, P };
  }
  const circCache = {};
  function circle(r) {
    if (circCache[r]) return circCache[r];
    const pts = []; let x = r, y = 0, err = 1 - r;
    while (x >= y) { pts.push([x, y], [y, x], [-y, x], [-x, y], [-x, -y], [-y, -x], [y, -x], [x, -y]); y++; if (err < 0) err += 2 * y + 1; else { x--; err += 2 * (y - x) + 1; } }
    const seen = new Set(), out = [];
    for (const p of pts) { const k = p[0] + ',' + p[1]; if (!seen.has(k)) { seen.add(k); out.push(p); } }
    out.sort((a, b) => Math.atan2(a[1], a[0]) - Math.atan2(b[1], b[0]));
    return (circCache[r] = out);
  }
  function drawCircle(g, cx, cy, r, col, dotted) {
    if (r < 1) return; g.fillStyle = col; const pts = circle(r);
    for (let i = 0; i < pts.length; i++) { if (dotted && (i >> 1) % 2) continue; g.fillRect(cx + pts[i][0], cy + pts[i][1], 1, 1); }
  }
  function arrow(x, y, dir, col) {
    const rows = [1, 2, 3, 2, 1];
    rows.forEach((w, j) => { for (let k = 0; k < w; k++) { const xx = dir > 0 ? x + k : x - k; px(lx, xx, y + j, 1, 1, col); } });
    rows.forEach((w, j) => { const xx = dir > 0 ? x + w : x - w; px(lx, xx, y + j, 1, 1, INK); });
    px(lx, x, y - 1, 1, 1, INK); px(lx, x, y + 5, 1, 1, INK);
  }
  function silhouette(spr, col) {
    if (silC.width !== spr.width || silC.height !== spr.height) { silC.width = spr.width; silC.height = spr.height; } // no per-frame reallocation
    sil.clearRect(0, 0, spr.width, spr.height); sil.globalCompositeOperation = 'source-over'; sil.drawImage(spr, 0, 0);
    sil.globalCompositeOperation = 'source-in'; sil.fillStyle = col; sil.fillRect(0, 0, spr.width, spr.height); sil.globalCompositeOperation = 'source-over';
    silC.k = spr.k; return silC;
  }
  function blitSpr(spr, x, y, big) {
    const AX = sprigAX(), AY = sprigAY();
    if (big === 2) lx.drawImage(spr, x - AX * 2, y - AY * 2 - 1, PX.artW(spr) * 2, PX.artH(spr) * 2);
    else PX.blit(lx, spr, x, y, false, AX, AY);
  }
  // wild animals: PX.critter at garden size (crisp), hopping on land, bobbing in water (swim sprite), flapping in the air
  function animalView(r, fy, y0, t) {
    const s = segAtC(race.C, r.x), ground = y0 + GY + 1 - elevAt(V, r.x), moving = race.state === 'run' && !r.finished;
    const a = D.ANIMALS[r.animal] || {}, plant = a.kind === 'plant', pf = plant && PX.critterFrames ? [0, 1, 0, 1, 0, 2][Math.floor(t * (moving ? 6 : 3) + r.lane) % 6] : 0;
    let spr = safeCritter(r.animal, pf) || icon('itembox'), y = ground;
    if (s.type === 'swim' && sinkAt(V, r.x) > 2 && !r.finished) { try { spr = PX.critterSwim(r.animal, pf) || spr; } catch (e) { /* optional */ } y = ground + 2 + Math.round(Math.sin(t * 4 + r.lane) * 0.8); }
    else if (plant && a.where === 'air' && !r.finished) y = ground - 4 + Math.round(Math.sin(t * 2.2 + r.lane) * 2); // the dandelion floats along
    else if (plant && moving && s.type !== 'fly') y = ground - (Math.floor(r.x / 3) % 2); // plants waddle instead of hopping
    else if (s.type === 'fly' && moving) y = ground - 3 - (a.where === 'air' ? 3 : 0) + Math.round(Math.sin(r.animT * (a.where === 'air' ? 14 : 6)) * 1.5);
    else if (moving) y = ground - (Math.floor(r.x / (s.type === 'climb' ? 3 : 5)) % 2 ? (r.tired ? 1 : 3) : 0);
    else if (r.finished) y = ground - (Math.floor(r.animT * 3) % 2 ? 2 : 0);
    else y = ground - (Math.floor(r.animT * 2 + r.lane) % 2);
    return { spr, y, k: race.mods && race.mods.giant ? 2 : 1 }; // same size as in the garden (Giant Mode doubles everyone)
  }
  function blitAnimal(spr, x, y, k) { const w = PX.artW(spr), h = PX.artH(spr); lx.drawImage(spr, Math.round(x - w * k / 2), Math.round(y - h * k + k), w * k, h * k); }
  function drawSled(sx, fy, big) { // a little wooden sled drawn in front of the rider
    const b = big, x0 = sx - 10 * b, y = fy - 1;
    px(lx, x0 - 1, y - 4 * b, 22 * b + 2, 4 * b + 2, INK);
    px(lx, x0, y - 3 * b, 20 * b, 2 * b, '#b8743a'); px(lx, x0, y - 3 * b, 20 * b, 1, '#e5535f'); px(lx, x0, y - b, 20 * b, b, '#8f563b');
    px(lx, x0 + 20 * b, y - 5 * b, 2 * b, 3 * b, INK); px(lx, x0 + 20 * b, y - 4 * b, b, 2 * b, '#e5535f');
    px(lx, x0 + 1, y + 1, 21 * b, 1, '#595a70');
  }
  function drawRacer(r, P, sx, fy, t, y0) {
    const big = race.mods.giant ? 2 : 1;
    let spr, blit;
    if (r.animal) { const av = animalView(r, fy, y0 || 0, t); spr = av.spr; fy = av.y; blit = (c, x, y) => blitAnimal(c, x, y, av.k); }
    else { spr = sprig(r.look, P); blit = (c, x, y) => blitSpr(c, x, y, big); }
    if ((r.itemT > 0 || r.boostT > 0) && r.starT <= 0) { // speed lines: orange for a carrot, gold after a PERFECT cheer, green after GOOD
      const col = r.itemT > 0 ? '#ffb35c' : r.boostMul >= T.perfect.mul ? '#fff27a' : '#b6f06a';
      for (let k = 0; k < 3; k++) {
        const ln = 6 + ((Math.floor(t * 20) + k * 2) % 5), x0 = sx - 9 * big - ln - k * 2, y = fy - (5 + k * 6) * big;
        px(lx, x0, y + 1, ln, 1, 'rgba(34,32,52,0.35)'); px(lx, x0, y, ln, 1, k === 1 ? '#ffffff' : col);
      }
    }
    if (r.starT > 0) { // rainbow glow outline
      const s2 = silhouette(spr, RAINBOW[Math.floor(t * 12) % 6]);
      for (const [dx, dy] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) blit(s2, sx + dx, fy + dy);
    }
    if (r.isGhost) {
      const s2 = silhouette(spr, '#cbe4ff');
      lx.globalAlpha = 0.28; blit(s2, sx, fy); lx.globalAlpha = 0.45 + 0.08 * Math.sin(t * 5); blit(spr, sx, fy); lx.globalAlpha = 1;
    } else blit(spr, sx, fy);
    if (!r.animal && !r.finished && TH[themeAt(race.C, r.x)].sled && segAtC(race.C, r.x).type === 'fly') drawSled(sx, fy, big);
    if (r.shieldT > 0 && (r.shieldT > 2 || Math.floor(t * 8) % 2)) { // bubble
      const cx = sx, cy = fy - 12 * big, R = 14 * big;
      lx.globalAlpha = 0.25; disc(lx, cx, cy, R, '#7fd0ff'); lx.globalAlpha = 1;
      drawCircle(lx, cx, cy, R + 1, 'rgba(34,32,52,0.55)', false); drawCircle(lx, cx, cy, R, '#5fb8f0', false); drawCircle(lx, cx, cy, R - 1, '#e6f8ff', true);
      px(lx, cx - Math.round(R * 0.55), cy - Math.round(R * 0.55), 3, 1, '#ffffff'); px(lx, cx - Math.round(R * 0.65), cy - Math.round(R * 0.4), 1, 3, '#ffffff');
    }
    if (r.slowT > 0 && r.slowMul === ITEMS.honey.mul && r.starT <= 0) { // sticky honey feet
      px(lx, sx - 5 * big, fy, 10 * big, 1, '#f6a91a'); if (Math.floor(t * 6) % 2) px(lx, sx - 2, fy + 1, 1, 1, '#f6c83a');
    }
    if (race.mods.night && !r.isGhost) PX.blit(lx, icon('lantern'), sx + 9 * big, fy - 14 * big + Math.round(Math.sin(r.animT * 4)));
  }
  function drawLaneStuff(r, y0, camX, t) {
    const C = race.C;
    for (const h of race.honey) { // honey puddles land in every other lane
      if (h.owner === r) continue;
      const sx = h.x - camX; if (sx < -10 || sx > WW + 10) continue;
      PX.blit(lx, honeySpr(), sx, y0 + GY + 2 - elevAt(V, h.x) + Math.min(1, sinkAt(V, h.x)));
    }
    if (race.items && C.boxes && !r.isGhost) for (const bx of C.boxes) {
      if (r.x >= bx) continue;
      const sx = bx - camX; if (sx < -10 || sx > WW + 10) continue;
      PX.blit(lx, boxFrame(t + bx), sx, y0 + GY - 3 - elevAt(V, bx) + Math.round(Math.sin(t * 3 + bx) * 1.5));
    }
  }
  function drawRain(y0, t, camX) {
    lx.fillStyle = '#c6dcff'; lx.globalAlpha = 0.7; const P = WW + 30;
    for (let k = 0; k < 34; k++) { const h = hash(k * 31 + 7), x = mod((h % 997) - camX - Math.floor(t * 30), P) - 10, y = mod((h >> 10) + Math.floor(t * (140 + (h % 40))), LH); lx.fillRect(x, y0 + y, 1, 3); }
    lx.globalAlpha = 1; lx.fillStyle = '#ffffff';
    for (let k = 0; k < 6; k++) { const h = hash(k * 13 + Math.floor(t * 5) * 7); if (h % 3) lx.fillRect(h % WW, y0 + GY - (h >> 8) % 2, 1, 1); }
  }
  function drawDark(r, y0, camX, sx, fy) {
    dk.clearRect(0, 0, WW, LH); dk.fillStyle = 'rgba(10,8,34,0.66)'; dk.fillRect(0, 0, WW, LH);
    const lights = [];
    if (!r.none) lights.push([sx + 4, fy - 14, 24]);
    for (const d of race.C.decor) if (d.glow || d.kind === 'lantern' || d.kind === 'lamp') { const x = d.x - camX; if (x > -20 && x < WW + 20) lights.push([x, GY - 8, 13]); }
    if (race.items && race.C.boxes) for (const bx of race.C.boxes) if (r.x < bx) { const x = bx - camX; if (x > -10 && x < WW + 10) lights.push([x, GY - 9 - elevAt(V, bx), 8]); }
    lights.push([race.C.LEN + 10 - camX, GY - 22, 20]);
    dk.globalCompositeOperation = 'destination-out';
    for (const [x, y, rr] of lights) { dk.globalAlpha = 0.5; disc(dk, x, y, rr, '#000'); dk.globalAlpha = 1; disc(dk, x, y, Math.round(rr * 0.66), '#000'); }
    dk.globalCompositeOperation = 'source-over';
    lx.drawImage(dkC, 0, y0);
  }
  function render() {
    if (!race || !cssW || !V) return;
    const t = race.t + (race.state === 'count' ? 3.6 - race.countT : 0);
    const camX = Math.round(race.player.x) - PSX;
    V.g = bg; V.W = WW; V.H = LH; V.GY = GY; V.CH = CLIMB_H; V.camX = camX; V.t = t; V.focus = PSX;
    V.rain = !!race.mods.rain; V.cheer = race.player.finished || race.player.x > race.C.LEN - 90;
    if (((t * 2) | 0) !== V.nt) { V.nt = (t * 2) | 0; V.night = race.mods.night ? 1 : nightAmt(); }
    drawWorld(V);
    drawWaterFront({ g: fg, W: WW, H: LH, GY, C: race.C, camX, t, tint: V.tint });
    lx.setTransform(PX.SCENE_K, 0, 0, PX.SCENE_K, 0, 0); lx.imageSmoothingEnabled = false; lx.fillStyle = INK; lx.fillRect(0, 0, WW, WH);
    const N = race.lanes.length;
    for (let i = 0; i < N; i++) {
      const r = race.lanes[i], y0 = i * LH, sx = Math.round(r.x) - camX;
      lx.save(); lx.beginPath(); lx.rect(0, y0, WW, LH); lx.clip();
      lx.drawImage(bgC, 0, y0, WW, LH);
      drawLaneStuff(r, y0, camX, t);
      const { y, P } = feetY(r);
      if (!r.none && sx > -40 && sx < WW + 40) {
        const gy = GY + 1 - elevAt(V, r.x) + sinkAt(V, r.x);
        if (race.mods.lowgrav && gy - y > 3) { const w = Math.max(3, 9 - ((gy - y) >> 1)); lx.globalAlpha = 0.3; px(lx, sx - w, y0 + gy, w * 2, 1, INK); lx.globalAlpha = 1; }
        const over = race.mods.giant && i > 0 ? clamp(58 - GY, 0, 12) : 0; // giants on short lanes may poke a little into the lane above
        if (over) { lx.restore(); lx.save(); lx.beginPath(); lx.rect(0, y0 - over, WW, LH + over); lx.clip(); }
        drawRacer(r, P, sx, y0 + y, t, y0);
        if (over) { lx.restore(); lx.save(); lx.beginPath(); lx.rect(0, y0, WW, LH); lx.clip(); }
      }
      lx.drawImage(fgC, 0, y0, WW, LH);
      for (const p of race.parts) if (p.lane === i) {
        const spr = p.frames ? p.frames[Math.min(p.frames.length - 1, ((1 - p.life / p.life0) * p.frames.length) | 0)] : p.spr; // puffs / ripples age through frames
        const px_ = Math.round(p.x) - camX, py = p.rel ? y0 + y + Math.round(p.y) : y0 + Math.round(p.y);
        lx.drawImage(spr, px_ - (PX.artW(spr) >> 1), py, PX.artW(spr), PX.artH(spr));
      }
      if (race.mods.rain) drawRain(y0, t, camX);
      if (race.mods.night) drawDark(r, y0, camX, sx, y);
      const big = race.mods.giant ? 2 : 1;
      if (r.emote && sx > -20 && sx < WW + 10) { try { PX.blit(lx, PX.emote(r.emote), sx + 8 * big, y0 + y - 12 * big - (big - 1) * 14 - (r.animal ? 6 * big : 0), false, 0, 13); } catch (e) { /* optional */ } }
      lx.restore();
      if (r === race.player) { px(lx, 0, y0, WW, 1, '#fbf236'); px(lx, 0, y0 + LH - 1, WW, 1, '#fbf236'); px(lx, 0, y0, 1, LH, '#fbf236'); px(lx, WW - 1, y0, 1, LH, '#fbf236'); }
      else if (i > 0 && race.lanes[i - 1] !== race.player) px(lx, 0, y0, WW, 1, INK);
      const my = y0 + (LH >> 1) - 2;
      if (!r.none) { if (sx > WW + 4) arrow(WW - 5, my, 1, r.color); else if (sx < -6) arrow(4, my, -1, r.color); }
    }
    if (race.ring || race.pflash > 0) {
      const rg = race.ring, r = race.player, y0 = r.lane * LH, { y } = feetY(r), big = race.mods.giant ? 2 : 1, cy = y0 + y - 12 * big;
      if (rg) {
        const cx = PSX + (rg.wob > 0 ? ((rg.wob * 30) | 0) % 2 * 2 - 1 : 0), rr = Math.round(rg.r), k = judge(rg.r, rg.good);
        if (k === 'early' || k === 'late') { // closing in (dotted target) / too late (grey ring)
          drawCircle(lx, cx, cy, T.ring.target, '#ffffff', true);
          drawCircle(lx, cx, cy, rr + 1, INK); drawCircle(lx, cx, cy, rr - 1, INK); drawCircle(lx, cx, cy, rr, k === 'late' ? '#a0a6ba' : '#ffcc44');
        } else { // TAP NOW: the target turns solid and the ring glows and pulses (plus "TAP!" in the text layer)
          const hot = k === 'perfect', glow = hot ? '#ffffff' : '#fff27a', pulse = ((rg.cueT * 10) | 0) % 2;
          lx.globalAlpha = 0.5; drawCircle(lx, cx, cy, rr + 2 + pulse, glow); drawCircle(lx, cx, cy, rr - 2 - pulse, glow); lx.globalAlpha = 1;
          drawCircle(lx, cx, cy, rr + 1, INK); drawCircle(lx, cx, cy, rr - 1, INK);
          drawCircle(lx, cx, cy, T.ring.target, hot ? '#ffffff' : '#99e550');
          drawCircle(lx, cx, cy, rr, glow);
        }
      }
      if (race.pflash > 0) { const q = 1 - race.pflash / 0.3; drawCircle(lx, PSX, cy, Math.round(T.ring.target + q * 12), '#ffffff', q > 0.5); } // PERFECT flash
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, cv.width, cv.height);
    if (race.mirror) ctx.setTransform(-1, 0, 0, 1, cv.width, 0);
    ctx.drawImage(lo, 0, 0, WW * DS, WH * DS); // whole-number scale only
    // text layer (css px)
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const S = DS / dpr, order = standings(), mx = x => (race.mirror ? cssW - x : x);
    for (let i = 0; i < race.lanes.length; i++) {
      const r = race.lanes[i], pl = order.indexOf(r);
      let label;
      if (r.isGhost) label = r.none ? 'No ghost yet' : `Ghost · ${race.ghostData.best.toFixed(1)}s`;
      else label = (race.state === 'count' || race.mode === 'trial' ? '' : ORD[pl] + ' ') + (r.isPlayer ? r.name + ' (you)' : r.name);
      chip(6, i * LH * S + 5, label, r.isPlayer, r.color, !r.isPlayer && r.item);
      const sx = Math.round(r.x) - camX, my = (i * LH + (LH >> 1)) * S;
      const dm = Math.max(1, Math.round(Math.abs(r.x - race.player.x) / 10)) + 'm';
      if (!r.none) {
        if (sx > WW + 4) tag(mx((WW - 8) * S), my, '+' + dm, race.mirror ? 'left' : 'right');
        else if (sx < -6) tag(mx(8 * S), my, '−' + dm, race.mirror ? 'right' : 'left');
      }
    }
    if (race.mode === 'trial') medalBoard(S);
    const big = race.mods.giant ? 2 : 1;
    const pY = (race.player.lane * LH + feetY(race.player).y - 30 * big) * S;
    const laneTop = race.player.lane * LH * S, showTired = race.player.tired && race.state === 'run' && !race.player.finished;
    for (const p of race.pops) {
      const k = p.t / p.life, a = k > 0.7 ? 1 - (k - 0.7) / 0.3 : 1;
      ctx.globalAlpha = a;
      if (p.side) bigText(p.text, cssW * 0.7, laneTop + 12 * S + 14 - k * 8, p.size, p.color);
      else bigText(p.text, mx(PSX * S), Math.max(laneTop + 52, pY - k * 26), p.size, p.color); // stays below the lane's name tag
      ctx.globalAlpha = 1;
    }
    const rg = race.ring, rk = rg && judge(rg.r, rg.good);
    if (rk === 'perfect' || rk === 'good') { // big "TAP!" over the ring while it's in the window (pops in, then pulses): no reading needed
      const ringTop = race.player.lane * LH + feetY(race.player).y - 12 * big - Math.round(rg.r) - 3;
      const size = Math.round(30 + 14 * Math.max(0, 1 - rg.cueT / 0.12) + (((rg.cueT * 10) | 0) % 2) * 3);
      bigText('TAP!', mx(PSX * S), Math.max(laneTop + 50, ringTop * S), size, rk === 'perfect' ? '#ffffff' : '#fff27a');
    }
    const laneMid = (race.player.lane * LH + LH / 2) * S;
    if (race.state === 'count') {
      const n = Math.ceil(race.countT);
      if (n >= 4) { bigText(race.title, cssW / 2, race.player.lane * LH * S + 48, 28, '#ffcc44'); bigText(race.sub, cssW / 2, race.player.lane * LH * S + 76, 20, '#ffffff'); }
      else bigText(n >= 1 ? String(n) : 'GO!', cssW * 0.68, laneMid + 26, 72, n >= 1 ? '#ffcc44' : '#99e550');
    } else if (race.goFlash > 0 && !race.goBanner) {
      ctx.globalAlpha = Math.min(1, race.goFlash * 2); bigText('GO!', cssW * 0.68, laneMid + 26, 72, '#99e550'); ctx.globalAlpha = 1;
    }
    if (showTired && Math.floor(race.t * 2) % 3) { ctx.font = `700 15px ${F_UI}`; const tw = Math.min(cssW - 16, ctx.measureText('Tired… a PERFECT cheer wakes it up!').width + 20); note(Math.round(cssW - tw - 8), laneTop + LH * S - 20, 'Tired… a PERFECT cheer wakes it up!'); } // bottom-right of your lane: clear of the name tag, pops and your plant
    if (race.freezeT > 0) { ctx.fillStyle = `rgba(255,255,255,${(Math.min(0.4, race.freezeT) / 0.4 * 0.6).toFixed(3)})`; ctx.fillRect(0, 0, cssW, cssH); }
    if (race.stamp) drawStamp();
  }
  // the finish-line stamp ("1st!" in gold, "2nd!" silver, "3rd!" bronze): thumps down onto your lane and stays
  function drawStamp() {
    const s = race.stamp, k = RM ? 1 : Math.min(1, s.t / 0.22), sc = 1 + 0.8 * (1 - k) * (1 - k);
    const x = Math.round(race.mirror ? cssW * 0.38 : cssW * 0.62), y = Math.round((race.player.lane * LH + LH * 0.5) * DS / dpr);
    ctx.save(); ctx.translate(x, y); ctx.rotate(-0.14); ctx.scale(sc, sc); ctx.globalAlpha = Math.min(1, 0.3 + k);
    ctx.font = `900 46px ${F_UI}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const w = Math.ceil(ctx.measureText(s.text).width) + 36, h = 66;
    roundRect(-w / 2, -h / 2, w, h, 14); ctx.fillStyle = 'rgba(26,27,31,0.62)'; ctx.fill(); ctx.lineWidth = 5; ctx.strokeStyle = s.col; ctx.stroke();
    ctx.lineJoin = 'round'; ctx.lineWidth = 9; ctx.strokeStyle = INK; ctx.strokeText(s.text, 0, 3); ctx.fillStyle = s.col; ctx.fillText(s.text, 0, 3);
    ctx.restore();
  }
  function medalBoard(S) {
    const tr = trialRec(race.R, race.tier), mt = medalTimes(race.ri, race.tier), have = Math.min(3, tr.m || 0);
    const tm = race.player.finished ? race.player.time : race.t, pace = medalOf(mt, tm);
    ctx.font = '800 13px "Nunito", sans-serif'; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    let x = Math.round(cssW) - 8 - 3 * 64; const y = 8;
    for (let k = 0; k < 3; k++) {
      const alive = tm <= mt[k], ic = icon('medal' + (k < have || alive ? k : 'x'));
      ctx.globalAlpha = alive || k < have ? 1 : 0.55;
      ctx.drawImage(ic, x, y, 11 * 2, 14 * 2);
      tag(x + 25, y + 15, mt[k].toFixed(1) + 's', 'left');
      x += 64;
    }
    ctx.globalAlpha = 1; void pace;
  }
  function roundRect(x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }
  // Canvas text for young readers: Nunito (round, clear) for names, numbers and sentences; the pixel font only for
  // big short shouts (countdown, PERFECT!). Solid label backgrounds, outlines thin enough to keep letter holes open.
  const F_UI = '"Nunito", ui-rounded, "SF Pro Rounded", system-ui, sans-serif', F_PX = '"Luckiest Guy", sans-serif';
  function chip(x, y, text, me, col, item) {
    ctx.font = `700 14px ${F_UI}`; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    const w = Math.ceil(ctx.measureText(text).width) + 26 + (item ? 19 : 0), h = 22;
    roundRect(x, y, w, h, 8); ctx.fillStyle = me ? '#ffcc44' : '#fff8e6'; ctx.fill();
    ctx.lineWidth = 2; ctx.strokeStyle = me ? '#b8740f' : '#8a7550'; ctx.stroke();
    ctx.fillStyle = col; ctx.fillRect(x + 7, y + 7, 8, 8); ctx.strokeStyle = INK; ctx.lineWidth = 1.5; ctx.strokeRect(x + 7, y + 7, 8, 8);
    ctx.fillStyle = me ? '#3a2408' : '#3a2a18'; ctx.fillText(text, x + 20, y + h / 2 + 1);
    if (item) { ctx.imageSmoothingEnabled = false; ctx.drawImage(icon(item), x + w - 20, y + 3, 15, 15); }
  }
  function tag(x, y, text, align) { // short outlined labels over the world ("+12m", medal times)
    ctx.font = `700 14px ${F_UI}`; ctx.textBaseline = 'middle'; ctx.textAlign = align;
    ctx.lineJoin = 'round'; ctx.lineWidth = 3.5; ctx.strokeStyle = INK; ctx.strokeText(text, x, y); ctx.fillStyle = '#ffffff'; ctx.fillText(text, x, y);
  }
  function note(x, y, text) { // a sentence on a solid pill (e.g. the "Tired" tip)
    ctx.font = `700 15px ${F_UI}`; ctx.textBaseline = 'middle'; ctx.textAlign = 'left';
    const w = Math.min(cssW - x - 8, Math.ceil(ctx.measureText(text).width) + 20), h = 26;
    roundRect(x, y - h / 2, w, h, 9); ctx.fillStyle = '#fff8e6'; ctx.fill(); ctx.lineWidth = 2; ctx.strokeStyle = '#d24552'; ctx.stroke();
    ctx.fillStyle = '#8a2433'; ctx.fillText(text, x + 10, y + 1, w - 20);
  }
  function bigText(text, x, y, size, col) {
    const pixel = size >= 24 && String(text).length <= 9, sz = pixel ? size : Math.max(18, size);
    ctx.font = `${pixel ? 400 : 800} ${sz}px ${pixel ? F_PX : F_UI}`; ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
    ctx.lineJoin = 'round'; ctx.lineWidth = pixel ? Math.max(4, sz / 7) : Math.max(3.5, sz / 7.5); ctx.strokeStyle = INK;
    const maxW = cssW - 16; ctx.strokeText(text, x, y, maxW); ctx.fillStyle = col; ctx.fillText(text, x, y, maxW);
  }

  PS.scenes = PS.scenes || {};
  // unlockAll(): parent tools "Unlock all races" (see the comment on the function)
  PS.scenes.race = { mount, show, hide, frame, unlockAll };

  // debug / balance hook
  window.__race = {
    TUNING, DBG, ITEMS, MODS, EXTRA_RACES, ALL, buildCourse, simRace, simMany, flat, mulOf, tap, startRace, startTrial, startCup, skipToEnd, useItem,
    medalTimes, dailyInfo, dayKey, extraRivals, extra: () => xsRead(), judge, goodOf, unlockAll, matchOf, rivalRacers,
    pause: () => { if (race) pauseRace(); }, resume, settle: () => race && settle(),
    get race() { return race; },
    giveItem(kind) { if (race && ITEMS[kind]) race.player.item = kind; },
    ff: sec => { for (let i = 0; i < sec * 60 && race; i++) update(1 / 60); },
    courseInfo() { return ALL.map((R, ri) => D.RACE_TIERS.map((Tr, ti) => { const C = buildCourse(ri, ti); return `${R.id}/${Tr.name}: ${C.LEN}px ${C.segs.map(s => s.type[0] + s.len).join(' ')}`; })).flat(); },
  };
})();
