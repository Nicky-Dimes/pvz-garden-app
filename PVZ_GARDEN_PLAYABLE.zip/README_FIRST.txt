PVZ GARDEN — FROZEN CHECKPOINT
1,975drawnframes:36plantfamilies,19zombies,12bosses. Fullartpass remains unfinished.
Extract and open pvz-garden/index.html, or serve that folder with python3 -m http.server 8770.
For Claude continuation use PVZ_GARDEN_CLAUDE_HANDOFF.zip, not this playable-only archive.
